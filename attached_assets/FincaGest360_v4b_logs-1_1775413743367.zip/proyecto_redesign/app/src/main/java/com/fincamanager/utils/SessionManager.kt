package com.fincamanager.utils

import android.content.Context
import android.content.SharedPreferences

object SessionManager {
    private const val PREFS = "finca_session_v5"
    private const val KEY_USER_ID      = "user_id"
    private const val KEY_USER_NAME    = "user_name"
    private const val KEY_EMAIL        = "email"
    private const val KEY_FINCA_ID     = "finca_activa_id"
    private const val KEY_FINCA_NOMBRE = "finca_activa_nombre"
    private const val KEY_LOGGED_IN    = "logged_in"

    private fun prefs(ctx: Context): SharedPreferences =
        ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE)

    fun saveSession(ctx: Context, userId: Int, userName: String, email: String) {
        prefs(ctx).edit()
            .putInt(KEY_USER_ID, userId)
            .putString(KEY_USER_NAME, userName)
            .putString(KEY_EMAIL, email)
            .putBoolean(KEY_LOGGED_IN, true)
            .apply()
    }

    fun setFincaActiva(ctx: Context, fincaId: Int, fincaNombre: String) {
        prefs(ctx).edit()
            .putInt(KEY_FINCA_ID, fincaId)
            .putString(KEY_FINCA_NOMBRE, fincaNombre)
            .apply()
    }

    fun isLoggedIn(ctx: Context) = prefs(ctx).getBoolean(KEY_LOGGED_IN, false)
    fun getUserId(ctx: Context)   = prefs(ctx).getInt(KEY_USER_ID, -1)
    fun getUserName(ctx: Context) = prefs(ctx).getString(KEY_USER_NAME, "") ?: ""
    fun getEmail(ctx: Context)    = prefs(ctx).getString(KEY_EMAIL, "") ?: ""
    fun getFincaId(ctx: Context)  = prefs(ctx).getInt(KEY_FINCA_ID, 0)
    fun getFincaNombre(ctx: Context) = prefs(ctx).getString(KEY_FINCA_NOMBRE, "Mi Finca") ?: "Mi Finca"

    fun logout(ctx: Context) = prefs(ctx).edit().clear().apply()
}
