package com.fincamanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.LaborHistory
import kotlinx.coroutines.launch

class LaborHistoryViewModel(app: Application) : AndroidViewModel(app) {

    private val dao = AppDatabase.getInstance(app).laborHistoryDao()

    private val _loteId = MutableLiveData<Int>()
    val historialLote: LiveData<List<LaborHistory>> = _loteId.switchMap { dao.getByLote(it) }

    private val _fincaId = MutableLiveData<Int>()
    val historialFinca: LiveData<List<LaborHistory>> = _fincaId.switchMap { dao.getByFinca(it) }

    fun setLote(loteId: Int) { _loteId.value = loteId }
    fun setFinca(fincaId: Int) { _fincaId.value = fincaId }

    fun registrarLabor(labor: LaborHistory) = viewModelScope.launch {
        if (labor.id == 0) dao.insert(labor)
        else dao.update(labor)
    }

    fun eliminar(id: Int) = viewModelScope.launch { dao.delete(id) }
}
