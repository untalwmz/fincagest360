package com.fincamanager.ui.production

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.data.model.Production
import com.fincamanager.databinding.ItemProductionBinding
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils

class ProductionAdapter(
    private val onClick: (Production) -> Unit
) : ListAdapter<Production, ProductionAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemProductionBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(p: Production) {
            b.tvLote.text     = p.loteNombre
            b.tvCultivo.text  = p.cultivo
            b.tvFecha.text    = DateUtils.toShow(p.fecha)
            b.tvCantidad.text = "${String.format("%.1f", p.cantidad)} ${p.unidad}"
            b.tvVenta.text    = if (p.totalVenta > 0) CurrencyUtils.format(p.totalVenta) else ""
            b.root.setOnClickListener { onClick(p) }
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) =
        VH(ItemProductionBinding.inflate(LayoutInflater.from(parent.context), parent, false))

    override fun onBindViewHolder(holder: VH, position: Int) = holder.bind(getItem(position))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Production>() {
            override fun areItemsTheSame(a: Production, b: Production) = a.id == b.id
            override fun areContentsTheSame(a: Production, b: Production) = a == b
        }
    }
}
