package com.fincamanager.firebase

import com.fincamanager.data.model.*
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

object FirebaseSyncManager {

    // ══════════════════════════════════════════════════
    // UPLOAD — Sube registros locales a Firestore
    // ══════════════════════════════════════════════════

    suspend fun syncFinca(f: Finca) {
        FirebaseManager.fincasRef()?.document(f.id.toString())?.set(
            mapOf("id" to f.id, "nombre" to f.nombre, "ubicacion" to f.ubicacion,
                  "areaTotal" to f.areaTotal, "cultivo" to f.cultivo,
                  "descripcion" to f.descripcion, "fechaCreacion" to f.fechaCreacion,
                  "activa" to f.activa), SetOptions.merge()
        )?.await()
    }

    suspend fun syncEmpleado(e: Employee, fincaId: String) {
        FirebaseManager.empleadosRef(fincaId)?.document(e.id.toString())?.set(
            mapOf("id" to e.id, "nombre" to e.nombre, "documento" to e.documento,
                  "telefono" to e.telefono, "direccion" to e.direccion,
                  "precioJornal" to e.precioJornal, "activo" to e.activo,
                  "fechaIngreso" to e.fechaIngreso, "notas" to e.notas), SetOptions.merge()
        )?.await()
    }

    suspend fun syncLote(l: Lot, fincaId: String) {
        FirebaseManager.lotesRef(fincaId)?.document(l.id.toString())?.set(
            mapOf("id" to l.id, "nombre" to l.nombre, "area" to l.area,
                  "cultivo" to l.cultivo, "variedad" to l.variedad,
                  "fechaSiembra" to l.fechaSiembra, "estado" to l.estado,
                  "descripcion" to l.descripcion), SetOptions.merge()
        )?.await()
    }

    suspend fun syncJornal(wd: WorkDay, fincaId: String) {
        FirebaseManager.jornalesRef(fincaId)?.document(wd.id.toString())?.set(
            mapOf("id" to wd.id, "trabajadorId" to wd.trabajadorId,
                  "trabajadorNombre" to wd.trabajadorNombre, "loteId" to wd.loteId,
                  "loteNombre" to wd.loteNombre, "fecha" to wd.fecha,
                  "horasTrabajadas" to wd.horasTrabajadas, "pago" to wd.pago,
                  "actividad" to wd.actividad, "pagado" to wd.pagado, "notas" to wd.notas),
            SetOptions.merge()
        )?.await()
    }

    suspend fun syncProduccion(p: Production, fincaId: String) {
        FirebaseManager.produccionRef(fincaId)?.document(p.id.toString())?.set(
            mapOf("id" to p.id, "loteId" to p.loteId, "loteNombre" to p.loteNombre,
                  "cultivo" to p.cultivo, "fecha" to p.fecha, "cantidad" to p.cantidad,
                  "unidad" to p.unidad, "precioUnitario" to p.precioUnitario,
                  "totalVenta" to p.totalVenta, "comprador" to p.comprador, "notas" to p.notas),
            SetOptions.merge()
        )?.await()
    }

    suspend fun syncIngreso(i: Income, fincaId: String) {
        FirebaseManager.ingresosRef(fincaId)?.document(i.id.toString())?.set(
            mapOf("id" to i.id, "descripcion" to i.descripcion, "categoria" to i.categoria,
                  "monto" to i.monto, "fecha" to i.fecha, "cliente" to i.cliente,
                  "notas" to i.notas), SetOptions.merge()
        )?.await()
    }

    suspend fun syncInversion(inv: Investment, fincaId: String) {
        FirebaseManager.inversionesRef(fincaId)?.document(inv.id.toString())?.set(
            mapOf("id" to inv.id, "descripcion" to inv.descripcion, "categoria" to inv.categoria,
                  "monto" to inv.monto, "fecha" to inv.fecha, "proveedor" to inv.proveedor,
                  "notas" to inv.notas), SetOptions.merge()
        )?.await()
    }

    suspend fun syncInsumo(inp: Input, fincaId: String) {
        FirebaseManager.insumosRef(fincaId)?.document(inp.id.toString())?.set(
            mapOf("id" to inp.id, "nombre" to inp.nombre, "tipo" to inp.tipo,
                  "cantidad" to inp.cantidad, "unidad" to inp.unidad,
                  "costoUnitario" to inp.costoUnitario, "costoTotal" to inp.costoTotal,
                  "loteId" to inp.loteId, "loteNombre" to inp.loteNombre,
                  "fecha" to inp.fecha, "proveedor" to inp.proveedor,
                  "stockActual" to inp.stockActual, "stockMinimo" to inp.stockMinimo),
            SetOptions.merge()
        )?.await()
    }

    suspend fun syncCosecha(c: CosechaRegistro, fincaId: String) {
        FirebaseManager.cosechaRef(fincaId)?.document("${c.semanaInicio}_${c.trabajadorId}")?.set(
            mapOf("id" to c.id, "semanaInicio" to c.semanaInicio,
                  "trabajadorId" to c.trabajadorId, "trabajadorNombre" to c.trabajadorNombre,
                  "lunes" to c.lunes, "martes" to c.martes, "miercoles" to c.miercoles,
                  "jueves" to c.jueves, "viernes" to c.viernes, "sabado" to c.sabado,
                  "precioPorKg" to c.precioPorKg), SetOptions.merge()
        )?.await()
    }

    suspend fun syncActividad(a: ActivityEvent, fincaId: String) {
        FirebaseManager.actividadesRef(fincaId)?.document(a.id.toString())?.set(
            mapOf("id" to a.id, "loteId" to a.loteId, "loteNombre" to a.loteNombre,
                  "titulo" to a.titulo, "descripcion" to a.descripcion,
                  "fecha" to a.fecha, "hora" to a.hora, "tipo" to a.tipo,
                  "completada" to a.completada), SetOptions.merge()
        )?.await()
    }

    // ── Fase 1+2 nuevas entidades ─────────────────────
    suspend fun syncLaborHistory(l: LaborHistory, fincaId: String) {
        FirebaseManager.laborHistoryRef(fincaId)?.document(l.id.toString())?.set(
            mapOf("id" to l.id, "loteId" to l.loteId, "loteNombre" to l.loteNombre,
                  "fecha" to l.fecha, "tipo" to l.tipo, "descripcion" to l.descripcion,
                  "responsable" to l.responsable, "cantidad" to l.cantidad,
                  "unidad" to l.unidad, "costo" to l.costo, "notas" to l.notas),
            SetOptions.merge()
        )?.await()
    }

    suspend fun syncInventarioMov(m: InventarioMovimiento, fincaId: String) {
        FirebaseManager.inventarioMovRef(fincaId)?.document(m.id.toString())?.set(
            mapOf("id" to m.id, "insumoId" to m.insumoId, "insumoNombre" to m.insumoNombre,
                  "tipo" to m.tipo, "cantidad" to m.cantidad, "unidad" to m.unidad,
                  "costoUnitario" to m.costoUnitario, "costoTotal" to m.costoTotal,
                  "motivo" to m.motivo, "loteId" to m.loteId, "loteNombre" to m.loteNombre,
                  "fecha" to m.fecha, "notas" to m.notas), SetOptions.merge()
        )?.await()
    }

    suspend fun syncNominaLiq(n: NominaLiquidacion, fincaId: String) {
        FirebaseManager.nominaLiqRef(fincaId)?.document(n.id.toString())?.set(
            mapOf("id" to n.id, "empleadoId" to n.empleadoId, "empleadoNombre" to n.empleadoNombre,
                  "fechaInicio" to n.fechaInicio, "fechaFin" to n.fechaFin,
                  "totalDias" to n.totalDias, "totalHoras" to n.totalHoras,
                  "totalBruto" to n.totalBruto, "deducciones" to n.deducciones,
                  "totalNeto" to n.totalNeto, "pagado" to n.pagado,
                  "fechaPago" to n.fechaPago, "notas" to n.notas), SetOptions.merge()
        )?.await()
    }

    // ══════════════════════════════════════════════════
    // BACKUP — Registra metadata del último backup
    // ══════════════════════════════════════════════════
    suspend fun registrarBackup(fincaId: String, timestamp: String, totalRegistros: Int) {
        FirebaseManager.backupMetaRef(fincaId)?.document(timestamp)?.set(
            mapOf("timestamp" to timestamp, "totalRegistros" to totalRegistros,
                  "version" to "1.0", "plataforma" to "android")
        )?.await()
    }
}
