package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.InventarioMovimiento

@Dao
interface InventarioMovimientoDao {

    @Query("SELECT * FROM inventario_movimientos WHERE fincaId = :fincaId ORDER BY fecha DESC")
    fun getByFinca(fincaId: Int): LiveData<List<InventarioMovimiento>>

    @Query("SELECT * FROM inventario_movimientos WHERE insumoId = :insumoId ORDER BY fecha DESC")
    fun getByInsumo(insumoId: Int): LiveData<List<InventarioMovimiento>>

    @Query("SELECT * FROM inventario_movimientos WHERE insumoId = :insumoId AND fecha BETWEEN :ini AND :fin ORDER BY fecha DESC")
    suspend fun getByInsumoEnPeriodo(insumoId: Int, ini: String, fin: String): List<InventarioMovimiento>

    @Query("SELECT SUM(CASE WHEN tipo = 'ENTRADA' THEN cantidad WHEN tipo = 'SALIDA' THEN -cantidad ELSE cantidad END) FROM inventario_movimientos WHERE insumoId = :insumoId")
    suspend fun getStockCalculado(insumoId: Int): Double?

    @Query("SELECT SUM(costoTotal) FROM inventario_movimientos WHERE fincaId = :fincaId AND tipo = 'ENTRADA' AND fecha BETWEEN :ini AND :fin")
    suspend fun getTotalComprasEnPeriodo(fincaId: Int, ini: String, fin: String): Double?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(mov: InventarioMovimiento): Long

    @Update
    suspend fun update(mov: InventarioMovimiento)

    @Query("DELETE FROM inventario_movimientos WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT * FROM inventario_movimientos WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<InventarioMovimiento>

    @Query("UPDATE inventario_movimientos SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)

}