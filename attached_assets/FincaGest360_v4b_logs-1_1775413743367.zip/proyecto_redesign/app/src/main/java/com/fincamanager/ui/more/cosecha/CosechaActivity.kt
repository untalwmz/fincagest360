package com.fincamanager.ui.more.cosecha

import com.fincamanager.ui.base.BaseActivity
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.R
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.CosechaRegistro
import com.fincamanager.data.model.Employee
import com.fincamanager.databinding.ActivityCosechaBinding
import com.fincamanager.databinding.ItemCosechaBinding
import com.fincamanager.utils.AppLogger
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.CosechaViewModel
import kotlinx.coroutines.launch

class CosechaActivity : BaseActivity() {
    private lateinit var b: ActivityCosechaBinding
    private val vm: CosechaViewModel by viewModels()
    private lateinit var adapter: CosechaAdapter
    private var fincaId = 0

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        try {
            b = ActivityCosechaBinding.inflate(layoutInflater)
            setContentView(b.root)
            applySystemInsets(b.root)
            supportActionBar?.setDisplayHomeAsUpEnabled(true)
            title = "Recolección de Café"

            fincaId = SessionManager.getFincaId(this)
            AppLogger.i("CosechaActivity", "Iniciando con fincaId=$fincaId")
            vm.setFinca(fincaId)

            adapter = CosechaAdapter(
                onPagar = { reg ->
                    AlertDialog.Builder(this)
                        .setTitle("💰 Confirmar pago")
                        .setMessage("¿Marcar como pagado a ${reg.trabajadorNombre}?\nTotal: ${CurrencyUtils.format(reg.totalEfectivo)}")
                        .setPositiveButton("Confirmar pago") { _, _ ->
                            AppLogger.i("CosechaActivity", "Marcando pagado id=${reg.id}")
                            vm.marcarPagado(reg.id)
                        }
                        .setNegativeButton("Cancelar", null).show()
                },
                onEdit   = { reg -> abrirDialogRegistro(reg) },
                onDelete = { reg ->
                    AlertDialog.Builder(this)
                        .setTitle("Eliminar registro")
                        .setMessage("¿Eliminar el registro de ${reg.trabajadorNombre}?")
                        .setPositiveButton("Eliminar") { _, _ ->
                            AppLogger.i("CosechaActivity", "Eliminando registro id=${reg.id}")
                            vm.delete(reg.id)
                        }
                        .setNegativeButton("Cancelar", null).show()
                }
            )
            b.rv.layoutManager = LinearLayoutManager(this)
            b.rv.adapter = adapter

            vm.registros.observe(this) { list ->
                AppLogger.d("CosechaActivity", "Registros cargados: ${list.size}")
                adapter.submitList(list)
                val totalKg   = list.sumOf { it.totalKg }
                val totalPend = list.filter { !it.pagado }.sumOf { it.totalEfectivo }
                b.tvTotalKg.text        = "${String.format("%.1f", totalKg)} kg"
                b.tvTotalPendiente.text = CurrencyUtils.format(totalPend)
                b.tvEmpty.visibility    = if (list.isEmpty()) View.VISIBLE else View.GONE
            }

            b.fab.setOnClickListener { abrirDialogRegistro(null) }

        } catch (e: Exception) {
            AppLogger.e("CosechaActivity", "Error en onCreate", e)
            Toast.makeText(this, "Error al abrir Recolección: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun abrirDialogRegistro(editando: CosechaRegistro?) {
        lifecycleScope.launch {
            try {
                val db   = AppDatabase.getInstance(this@CosechaActivity)
                val emps = db.employeeDao().getByFincaSync(fincaId)
                AppLogger.d("CosechaActivity", "Empleados disponibles: ${emps.size}")
                if (emps.isEmpty()) {
                    Toast.makeText(this@CosechaActivity,
                        "Primero registra empleados en el módulo Empleados",
                        Toast.LENGTH_LONG).show()
                    return@launch
                }
                mostrarDialog(editando, emps)
            } catch (e: Exception) {
                AppLogger.e("CosechaActivity", "Error al cargar empleados para dialog", e)
                Toast.makeText(this@CosechaActivity, "Error al cargar empleados", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun mostrarDialog(editando: CosechaRegistro?, emps: List<Employee>) {
        try {
            val dv      = layoutInflater.inflate(R.layout.dialog_cosecha_registro, null)
            val spinner = dv.findViewById<Spinner>(R.id.spinner_empleado)
            val etL     = dv.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_lunes)
            val etMa    = dv.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_martes)
            val etMi    = dv.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_miercoles)
            val etJ     = dv.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_jueves)
            val etV     = dv.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_viernes)
            val etS     = dv.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_sabado)
            val etP     = dv.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_precio_kg)

            val empAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, emps.map { it.nombre })
            empAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            spinner.adapter = empAdapter

            editando?.let { r ->
                emps.indexOfFirst { it.id == r.trabajadorId }.takeIf { it >= 0 }?.let { spinner.setSelection(it) }
                fun d(v: Double) = if (v > 0) v.toString() else ""
                etL.setText(d(r.lunes));  etMa.setText(d(r.martes)); etMi.setText(d(r.miercoles))
                etJ.setText(d(r.jueves)); etV.setText(d(r.viernes)); etS.setText(d(r.sabado))
                etP.setText(if (r.precioPorKg > 0) r.precioPorKg.toString() else "")
            }

            AlertDialog.Builder(this)
                .setTitle(if (editando == null) "☕ Nuevo registro" else "✏️ Editar registro")
                .setView(dv)
                .setPositiveButton(if (editando == null) "Guardar" else "Actualizar") { _, _ ->
                    try {
                        val emp = emps[spinner.selectedItemPosition]
                        val registro = CosechaRegistro(
                            id               = editando?.id ?: 0,
                            fincaId          = fincaId,
                            semanaInicio     = editando?.semanaInicio ?: DateUtils.inicioSemanaActual(),
                            trabajadorId     = emp.id,
                            trabajadorNombre = emp.nombre,
                            lunes            = etL.text.toString().toDoubleOrNull()  ?: 0.0,
                            martes           = etMa.text.toString().toDoubleOrNull() ?: 0.0,
                            miercoles        = etMi.text.toString().toDoubleOrNull() ?: 0.0,
                            jueves           = etJ.text.toString().toDoubleOrNull()  ?: 0.0,
                            viernes          = etV.text.toString().toDoubleOrNull()  ?: 0.0,
                            sabado           = etS.text.toString().toDoubleOrNull()  ?: 0.0,
                            precioPorKg      = etP.text.toString().toDoubleOrNull()  ?: 0.0,
                            pagado           = editando?.pagado ?: false
                        )
                        AppLogger.i("CosechaActivity", "Guardando registro para ${emp.nombre}, kg=${registro.totalKg}")
                        vm.save(registro)
                        Toast.makeText(this, if (editando == null) "Registro guardado ✓" else "Actualizado ✓", Toast.LENGTH_SHORT).show()
                    } catch (e: Exception) {
                        AppLogger.e("CosechaActivity", "Error al guardar registro de cosecha", e)
                        Toast.makeText(this, "Error al guardar: ${e.message}", Toast.LENGTH_LONG).show()
                    }
                }
                .setNegativeButton("Cancelar", null).show()
        } catch (e: Exception) {
            AppLogger.e("CosechaActivity", "Error al mostrar dialog de cosecha", e)
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class CosechaAdapter(
    private val onPagar: (CosechaRegistro) -> Unit,
    private val onEdit: (CosechaRegistro) -> Unit,
    private val onDelete: (CosechaRegistro) -> Unit
) : ListAdapter<CosechaRegistro, CosechaAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemCosechaBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(c: CosechaRegistro) {
            try {
                val partes = c.trabajadorNombre.trim().split(" ")
                b.tvIniciales.text = buildString {
                    append(partes.getOrNull(0)?.firstOrNull() ?: "")
                    append(partes.getOrNull(1)?.firstOrNull() ?: "")
                }.uppercase()
                b.tvTrabajador.text = c.trabajadorNombre
                b.tvSemana.text     = "Semana del ${DateUtils.toShow(c.semanaInicio)}"
                fun fmt(v: Double) = if (v > 0) String.format("%.1f", v) else "—"
                b.tvLunes.text     = fmt(c.lunes);   b.tvMartes.text    = fmt(c.martes)
                b.tvMiercoles.text = fmt(c.miercoles); b.tvJueves.text  = fmt(c.jueves)
                b.tvViernes.text   = fmt(c.viernes); b.tvSabado.text    = fmt(c.sabado)
                b.tvTotalKg.text       = "${String.format("%.1f", c.totalKg)} kg"
                b.tvTotalEfectivo.text = CurrencyUtils.format(c.totalEfectivo)

                // FIX: usar ContextCompat.getColor() en lugar de resources.getColor()
                // evita ResourcesNotFoundException en API 36
                if (c.pagado) {
                    b.tvEstadoPago.text = "✓ Pagado"
                    b.tvEstadoPago.setTextColor(
                        ContextCompat.getColor(b.root.context, R.color.success)
                    )
                    b.btnPagar.visibility = View.GONE
                } else {
                    b.tvEstadoPago.text = "Pendiente"
                    b.tvEstadoPago.setTextColor(
                        ContextCompat.getColor(b.root.context, R.color.warning)
                    )
                    b.btnPagar.visibility = View.VISIBLE
                    b.btnPagar.setOnClickListener { onPagar(c) }
                }
                b.root.setOnClickListener { onEdit(c) }
                b.root.setOnLongClickListener { onDelete(c); true }
            } catch (e: Exception) {
                AppLogger.e("CosechaAdapter", "Error al bindear registro id=${c.id}", e)
            }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemCosechaBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<CosechaRegistro>() {
            override fun areItemsTheSame(a: CosechaRegistro, b: CosechaRegistro) = a.id == b.id
            override fun areContentsTheSame(a: CosechaRegistro, b: CosechaRegistro) = a == b
        }
    }
}
