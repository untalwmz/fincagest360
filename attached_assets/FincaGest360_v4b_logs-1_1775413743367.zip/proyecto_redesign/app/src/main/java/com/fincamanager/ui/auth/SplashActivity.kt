package com.fincamanager.ui.auth

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fincamanager.R
import com.fincamanager.firebase.FirebaseManager
import com.fincamanager.ui.main.MainActivity
import com.fincamanager.utils.AppLogger
import com.fincamanager.utils.SessionManager
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class SplashActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_splash)

        window.statusBarColor    = android.graphics.Color.parseColor("#0D2B1F")
        window.navigationBarColor = android.graphics.Color.parseColor("#0D2B1F")
        window.decorView.post {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                window.insetsController?.setSystemBarsAppearance(
                    0,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                )
            }
        }

        // AppLogger ya está inicializado en FincaApp.onCreate()
        AppLogger.seccion("SPLASH — inicio de sesión")
        AppLogger.i("SplashActivity", "Verificando autenticación…")

        lifecycleScope.launch {
            delay(2000)

            val loggedIn = FirebaseManager.isLoggedIn && SessionManager.isLoggedIn(this@SplashActivity)
            AppLogger.i("SplashActivity", "isLoggedIn=$loggedIn → navegando a ${if (loggedIn) "MainActivity" else "LoginActivity"}")

            val dest = if (loggedIn) MainActivity::class.java else LoginActivity::class.java
            startActivity(Intent(this@SplashActivity, dest))
            finish()
        }
    }
}
