package com.fincamanager.ui.more

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.fincamanager.databinding.FragmentMoreBinding
import com.fincamanager.firebase.FirebaseManager
import com.fincamanager.firebase.SyncWorker
import com.fincamanager.ui.auth.LoginActivity
import com.fincamanager.ui.more.calendar.CalendarActivity
import com.fincamanager.ui.more.cosecha.CosechaActivity
import com.fincamanager.ui.more.employees.EmployeesActivity
import com.fincamanager.ui.more.fincas.FincasActivity
import com.fincamanager.ui.more.inputs.InputsActivity
import com.fincamanager.ui.more.lots.LotsActivity
import com.fincamanager.ui.more.workdays.WorkDayActivity
import com.fincamanager.ui.nomina.NominaActivity
import com.fincamanager.ui.settings.SettingsActivity
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.InputViewModel

class MoreFragment : Fragment() {

    private var _b: FragmentMoreBinding? = null
    private val b get() = _b!!
    private val inputVm: InputViewModel by viewModels()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentMoreBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)

        val fincaId = SessionManager.getFincaId(requireContext())
        inputVm.setFinca(fincaId)

        // Alertas de stock en el badge
        inputVm.countAlertas.observe(viewLifecycleOwner) { count ->
            if (count > 0) {
                b.badgeAlertas.visibility = View.VISIBLE
                b.badgeAlertas.text = count.toString()
            } else {
                b.badgeAlertas.visibility = View.GONE
            }
        }

        b.cardFincas.setOnClickListener     { startActivity(Intent(requireContext(), FincasActivity::class.java)) }
        b.cardEmpleados.setOnClickListener  { startActivity(Intent(requireContext(), EmployeesActivity::class.java)) }
        b.cardLotes.setOnClickListener      { startActivity(Intent(requireContext(), LotsActivity::class.java)) }
        b.cardInsumos.setOnClickListener    { startActivity(Intent(requireContext(), InputsActivity::class.java)) }
        b.cardNomina.setOnClickListener     { startActivity(Intent(requireContext(), NominaActivity::class.java)) }
        b.cardCalendario.setOnClickListener { startActivity(Intent(requireContext(), CalendarActivity::class.java)) }
        b.cardCosecha.setOnClickListener    { startActivity(Intent(requireContext(), CosechaActivity::class.java)) }
        b.cardAnalisis.setOnClickListener   {
            val navController = androidx.navigation.Navigation.findNavController(requireActivity(), com.fincamanager.R.id.nav_host_fragment)
            navController.navigate(com.fincamanager.R.id.analisisFragment)
        }

        b.cardAjustes.setOnClickListener   { startActivity(Intent(requireContext(), SettingsActivity::class.java)) }

        b.btnLogout.setOnClickListener {
            SyncWorker.cancelAll(requireContext())
                FirebaseManager.logout()
            SessionManager.logout(requireContext())
            startActivity(Intent(requireContext(), LoginActivity::class.java).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
            })
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
