package com.fincamanager

import android.app.Application
import com.fincamanager.utils.AppLogger

/**
 * FincaApp — Application principal de FincaGest 360
 *
 * Registrar en AndroidManifest.xml:
 *   <application android:name=".FincaApp" ...>
 *
 * Aquí se inicializa AppLogger antes que cualquier Activity,
 * garantizando que todos los eventos queden registrados desde
 * el primer instante de vida de la app.
 */
class FincaApp : Application() {

    override fun onCreate() {
        super.onCreate()

        // ── Inicializar logger (PRIMERO que todo) ─────────────────────────
        AppLogger.init(this)
        AppLogger.i("FincaApp", "✅ Aplicación iniciada correctamente")
        AppLogger.i("FincaApp", "Ruta de logs: ${AppLogger.getRutaArchivo()}")
    }

    override fun onTerminate() {
        AppLogger.i("FincaApp", "⛔ Aplicación terminada")
        AppLogger.cerrar()
        super.onTerminate()
    }

    override fun onLowMemory() {
        super.onLowMemory()
        AppLogger.w("FincaApp", "⚠️ Sistema con memoria baja — onLowMemory()")
    }

    override fun onTrimMemory(level: Int) {
        super.onTrimMemory(level)
        if (level >= TRIM_MEMORY_MODERATE) {
            AppLogger.w("FincaApp", "⚠️ Recorte de memoria solicitado (nivel $level)")
        }
    }
}
