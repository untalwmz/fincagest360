package com.fincamanager.ui.auth

import com.fincamanager.ui.base.BaseActivity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fincamanager.databinding.ActivityLoginBinding
import com.fincamanager.firebase.FirebaseManager
import com.fincamanager.ui.main.MainActivity
import com.fincamanager.utils.SessionManager
import kotlinx.coroutines.launch

class LoginActivity : BaseActivity() {

    private lateinit var b: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)

        b.btnLogin.setOnClickListener { doLogin() }
        b.btnRegister.setOnClickListener {
            startActivity(Intent(this, RegisterActivity::class.java))
        }
        b.tvForgot.setOnClickListener {
            startActivity(Intent(this, ForgotPasswordActivity::class.java))
        }
    }

    private fun doLogin() {
        val email    = b.etEmail.text.toString().trim()
        val password = b.etPassword.text.toString()

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
            return
        }

        setLoading(true)
        lifecycleScope.launch {
            val result = FirebaseManager.login(email, password)
            setLoading(false)
            result.onSuccess { user ->
                SessionManager.saveSession(this@LoginActivity, 0, user.displayName ?: email, email)
                startActivity(Intent(this@LoginActivity, MainActivity::class.java))
                finish()
            }.onFailure {
                Toast.makeText(this@LoginActivity, "Credenciales incorrectas", Toast.LENGTH_SHORT).show()
            }
        }
    }

    private fun setLoading(loading: Boolean) {
        b.progress.visibility = if (loading) View.VISIBLE else View.GONE
        b.btnLogin.isEnabled = !loading
    }
}
