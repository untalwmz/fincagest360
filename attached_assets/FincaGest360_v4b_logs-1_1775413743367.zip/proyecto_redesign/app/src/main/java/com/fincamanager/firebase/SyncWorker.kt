package com.fincamanager.firebase

import android.content.Context
import androidx.work.*
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.utils.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.concurrent.TimeUnit

class SyncWorker(context: Context, params: WorkerParameters) : CoroutineWorker(context, params) {

    override suspend fun doWork(): Result = withContext(Dispatchers.IO) {
        if (!FirebaseManager.isLoggedIn) return@withContext Result.success()

        val db         = AppDatabase.getInstance(applicationContext)
        val fincaId    = inputData.getInt(KEY_FINCA_ID, 0)
        val fincaIdStr = fincaId.toString()
        val isBackup   = inputData.getBoolean(KEY_IS_BACKUP, false)

        try {
            var totalSynced = 0

            // ── Fincas ────────────────────────────────
            db.fincaDao().getPendientesSync().forEach { f ->
                FirebaseSyncManager.syncFinca(f)
                db.fincaDao().marcarSincronizado(f.id)
                totalSynced++
            }

            if (fincaId > 0) {
                // ── Empleados ──────────────────────────
                db.employeeDao().getPendientesSync().forEach { e ->
                    FirebaseSyncManager.syncEmpleado(e, fincaIdStr)
                    db.employeeDao().marcarSincronizado(e.id)
                    totalSynced++
                }
                // ── Lotes ─────────────────────────────
                db.lotDao().getPendientesSync().forEach { l ->
                    FirebaseSyncManager.syncLote(l, fincaIdStr)
                    db.lotDao().marcarSincronizado(l.id)
                    totalSynced++
                }
                // ── Jornales ──────────────────────────
                db.workDayDao().getPendientesSync().forEach { wd ->
                    FirebaseSyncManager.syncJornal(wd, fincaIdStr)
                    db.workDayDao().marcarSincronizado(wd.id)
                    totalSynced++
                }
                // ── Producción ────────────────────────
                db.productionDao().getPendientesSync().forEach { p ->
                    FirebaseSyncManager.syncProduccion(p, fincaIdStr)
                    db.productionDao().marcarSincronizado(p.id)
                    totalSynced++
                }
                // ── Ingresos ──────────────────────────
                db.incomeDao().getPendientesSync().forEach { i ->
                    FirebaseSyncManager.syncIngreso(i, fincaIdStr)
                    db.incomeDao().marcarSincronizado(i.id)
                    totalSynced++
                }
                // ── Inversiones ───────────────────────
                db.investmentDao().getPendientesSync().forEach { inv ->
                    FirebaseSyncManager.syncInversion(inv, fincaIdStr)
                    db.investmentDao().marcarSincronizado(inv.id)
                    totalSynced++
                }
                // ── Insumos ───────────────────────────
                db.inputDao().getPendientesSync().forEach { inp ->
                    FirebaseSyncManager.syncInsumo(inp, fincaIdStr)
                    db.inputDao().marcarSincronizado(inp.id)
                    totalSynced++
                }
                // ── Cosecha ───────────────────────────
                db.cosechaDao().getPendientesSync().forEach { c ->
                    FirebaseSyncManager.syncCosecha(c, fincaIdStr)
                    db.cosechaDao().marcarSincronizado(c.id)
                    totalSynced++
                }
                // ── Actividades ───────────────────────
                db.activityEventDao().getPendientesSync().forEach { a ->
                    FirebaseSyncManager.syncActividad(a, fincaIdStr)
                    db.activityEventDao().marcarSincronizado(a.id)
                    totalSynced++
                }
                // ── Labor History (Fase 1) ─────────────
                db.laborHistoryDao().getPendientesSync().forEach { l ->
                    FirebaseSyncManager.syncLaborHistory(l, fincaIdStr)
                    db.laborHistoryDao().marcarSincronizado(l.id)
                    totalSynced++
                }
                // ── Inventario Movimientos (Fase 2) ────
                db.inventarioMovimientoDao().getPendientesSync().forEach { m ->
                    FirebaseSyncManager.syncInventarioMov(m, fincaIdStr)
                    db.inventarioMovimientoDao().marcarSincronizado(m.id)
                    totalSynced++
                }
                // ── Nómina Liquidaciones (Fase 2) ──────
                db.nominaLiquidacionDao().getPendientesSync().forEach { n ->
                    FirebaseSyncManager.syncNominaLiq(n, fincaIdStr)
                    db.nominaLiquidacionDao().marcarSincronizado(n.id)
                    totalSynced++
                }
            }

            // Registrar metadata de backup si fue un backup manual/diario
            if (isBackup && totalSynced >= 0) {
                FirebaseSyncManager.registrarBackup(
                    fincaIdStr,
                    DateUtils.today(),
                    totalSynced
                )
            }

            Result.success(workDataOf(KEY_SYNCED_COUNT to totalSynced))

        } catch (e: Exception) {
            if (runAttemptCount < 3) Result.retry() else Result.failure()
        }
    }

    companion object {
        const val KEY_FINCA_ID     = "finca_id"
        const val KEY_IS_BACKUP    = "is_backup"
        const val KEY_SYNCED_COUNT = "synced_count"
        private const val WORK_NAME          = "finca_sync"
        private const val WORK_NAME_PERIODIC = "finca_sync_periodic"
        private const val WORK_NAME_BACKUP   = "finca_backup_daily"

        /** Sync inmediato al crear/editar un registro */
        fun schedule(context: Context, fincaId: Int) {
            val request = OneTimeWorkRequestBuilder<SyncWorker>()
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setInputData(workDataOf(KEY_FINCA_ID to fincaId))
                .setBackoffCriteria(BackoffPolicy.EXPONENTIAL, 15, TimeUnit.SECONDS)
                .build()
            WorkManager.getInstance(context)
                .enqueueUniqueWork(WORK_NAME, ExistingWorkPolicy.REPLACE, request)
        }

        /** Sync periódico cada 6 horas */
        fun schedulePeriodic(context: Context, fincaId: Int) {
            val request = PeriodicWorkRequestBuilder<SyncWorker>(6, TimeUnit.HOURS)
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setInputData(workDataOf(KEY_FINCA_ID to fincaId))
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME_PERIODIC, ExistingPeriodicWorkPolicy.KEEP, request)
        }

        /** Backup diario completo a las 2am */
        fun scheduleBackupDiario(context: Context, fincaId: Int) {
            val now = System.currentTimeMillis()
            val cal = java.util.Calendar.getInstance().apply {
                timeInMillis = now
                set(java.util.Calendar.HOUR_OF_DAY, 2)
                set(java.util.Calendar.MINUTE, 0)
                set(java.util.Calendar.SECOND, 0)
                if (timeInMillis <= now) add(java.util.Calendar.DAY_OF_YEAR, 1)
            }
            val delay = cal.timeInMillis - now

            val request = PeriodicWorkRequestBuilder<SyncWorker>(24, TimeUnit.HOURS)
                .setInitialDelay(delay, TimeUnit.MILLISECONDS)
                .setConstraints(Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED).build())
                .setInputData(workDataOf(KEY_FINCA_ID to fincaId, KEY_IS_BACKUP to true))
                .build()
            WorkManager.getInstance(context).enqueueUniquePeriodicWork(
                WORK_NAME_BACKUP, ExistingPeriodicWorkPolicy.KEEP, request)
        }

        /** Sync inmediato manual (alias de schedule, usado desde Settings) */
        fun runNow(context: Context, fincaId: Int) = schedule(context, fincaId)

        /** Cancela todos los trabajos de sync */
        fun cancelAll(context: Context) {
            WorkManager.getInstance(context).apply {
                cancelUniqueWork(WORK_NAME)
                cancelUniqueWork(WORK_NAME_PERIODIC)
                cancelUniqueWork(WORK_NAME_BACKUP)
            }
        }
    }
}
