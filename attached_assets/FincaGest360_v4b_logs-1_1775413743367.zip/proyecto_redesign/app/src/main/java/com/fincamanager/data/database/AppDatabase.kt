package com.fincamanager.data.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase
import com.fincamanager.data.dao.*
import com.fincamanager.data.model.*

@Database(
    entities = [
        User::class, Finca::class, Employee::class, Lot::class,
        WorkDay::class, Production::class, Input::class,
        Investment::class, Income::class, CosechaRegistro::class,
        ActivityEvent::class, LaborHistory::class,
        InventarioMovimiento::class, NominaLiquidacion::class
    ],
    version = 4,
    exportSchema = false
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun userDao(): UserDao
    abstract fun fincaDao(): FincaDao
    abstract fun employeeDao(): EmployeeDao
    abstract fun lotDao(): LotDao
    abstract fun workDayDao(): WorkDayDao
    abstract fun productionDao(): ProductionDao
    abstract fun inputDao(): InputDao
    abstract fun investmentDao(): InvestmentDao
    abstract fun incomeDao(): IncomeDao
    abstract fun cosechaDao(): CosechaDao
    abstract fun activityEventDao(): ActivityEventDao
    abstract fun laborHistoryDao(): LaborHistoryDao
    abstract fun inventarioMovimientoDao(): InventarioMovimientoDao
    abstract fun nominaLiquidacionDao(): NominaLiquidacionDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        val MIGRATION_1_2 = object : Migration(1, 2) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS labor_history (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    fincaId INTEGER NOT NULL DEFAULT 0, loteId INTEGER NOT NULL DEFAULT 0,
                    loteNombre TEXT NOT NULL DEFAULT '', fecha TEXT NOT NULL, tipo TEXT NOT NULL,
                    descripcion TEXT NOT NULL DEFAULT '', responsable TEXT NOT NULL DEFAULT '',
                    cantidad REAL NOT NULL DEFAULT 0.0, unidad TEXT NOT NULL DEFAULT '',
                    costo REAL NOT NULL DEFAULT 0.0, notas TEXT NOT NULL DEFAULT '',
                    pendienteSync INTEGER NOT NULL DEFAULT 0)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_labor_history_fincaId ON labor_history(fincaId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_labor_history_loteId ON labor_history(loteId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_labor_history_fecha ON labor_history(fecha)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_labor_history_tipo ON labor_history(tipo)")
            }
        }

        val MIGRATION_2_3 = object : Migration(2, 3) {
            override fun migrate(db: SupportSQLiteDatabase) {
                db.execSQL("""CREATE TABLE IF NOT EXISTS inventario_movimientos (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    fincaId INTEGER NOT NULL DEFAULT 0, insumoId INTEGER NOT NULL,
                    insumoNombre TEXT NOT NULL DEFAULT '', tipo TEXT NOT NULL,
                    cantidad REAL NOT NULL, unidad TEXT NOT NULL DEFAULT '',
                    costoUnitario REAL NOT NULL DEFAULT 0.0, costoTotal REAL NOT NULL DEFAULT 0.0,
                    motivo TEXT NOT NULL DEFAULT '', loteId INTEGER NOT NULL DEFAULT 0,
                    loteNombre TEXT NOT NULL DEFAULT '', fecha TEXT NOT NULL,
                    notas TEXT NOT NULL DEFAULT '', pendienteSync INTEGER NOT NULL DEFAULT 0)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_inv_mov_fincaId ON inventario_movimientos(fincaId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_inv_mov_insumoId ON inventario_movimientos(insumoId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_inv_mov_fecha ON inventario_movimientos(fecha)")
                db.execSQL("""CREATE TABLE IF NOT EXISTS nomina_liquidaciones (
                    id INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                    fincaId INTEGER NOT NULL DEFAULT 0, empleadoId INTEGER NOT NULL,
                    empleadoNombre TEXT NOT NULL DEFAULT '', fechaInicio TEXT NOT NULL,
                    fechaFin TEXT NOT NULL, totalDias INTEGER NOT NULL DEFAULT 0,
                    totalHoras REAL NOT NULL DEFAULT 0.0, totalBruto REAL NOT NULL DEFAULT 0.0,
                    deducciones REAL NOT NULL DEFAULT 0.0, totalNeto REAL NOT NULL DEFAULT 0.0,
                    pagado INTEGER NOT NULL DEFAULT 0, fechaPago TEXT NOT NULL DEFAULT '',
                    notas TEXT NOT NULL DEFAULT '', pendienteSync INTEGER NOT NULL DEFAULT 0)""")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_nomina_fincaId ON nomina_liquidaciones(fincaId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_nomina_empleadoId ON nomina_liquidaciones(empleadoId)")
                db.execSQL("CREATE INDEX IF NOT EXISTS index_nomina_fechaInicio ON nomina_liquidaciones(fechaInicio)")
            }
        }

        val MIGRATION_3_4 = object : Migration(3, 4) {
            override fun migrate(db: SupportSQLiteDatabase) {
                // Add pagado column to cosecha_registros
                db.execSQL("ALTER TABLE cosecha_registros ADD COLUMN pagado INTEGER NOT NULL DEFAULT 0")
            }
        }

        fun getInstance(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                Room.databaseBuilder(context.applicationContext, AppDatabase::class.java, "finca_manager_v5.db")
                    .addMigrations(MIGRATION_1_2, MIGRATION_2_3, MIGRATION_3_4)
                    .fallbackToDestructiveMigration()
                    .build().also { INSTANCE = it }
            }
        }
    }
}
