package com.fincamanager.ui.analisis

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.R
import com.fincamanager.data.model.RentabilidadLote
import com.fincamanager.databinding.ItemRentabilidadBinding
import com.fincamanager.utils.CurrencyUtils

class RentabilidadAdapter(private val items: List<RentabilidadLote>) :
    RecyclerView.Adapter<RentabilidadAdapter.VH>() {

    inner class VH(val b: ItemRentabilidadBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemRentabilidadBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        with(h.b) {
            tvLoteNombre.text   = item.loteNombre
            tvKg.text           = String.format("%.0f kg", item.totalKg)
            tvVentas.text       = CurrencyUtils.format(item.totalVentas)
            tvCostos.text       = CurrencyUtils.format(item.totalCostos)
            tvRentabilidad.text = CurrencyUtils.format(item.rentabilidad)
            val color = root.context.resources.getColor(
                if (item.rentabilidad >= 0) R.color.success else R.color.error, null
            )
            tvRentabilidad.setTextColor(color)
        }
    }
}
