package com.fincamanager.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.utils.DateUtils
import kotlinx.coroutines.launch

data class DashboardKpis(
    val totalIngresos: Double = 0.0,
    val totalEgresos: Double = 0.0,
    val ganancia: Double = 0.0,
    val totalProduccionKg: Double = 0.0,
    val empleadosActivos: Int = 0,
    val lotesActivos: Int = 0,
    val alertasInsumos: Int = 0,
    val nominaPendiente: Double = 0.0,
    val costoPorKg: Double = 0.0,       // NUEVO: costo de producción por kg
    val margenPct: Double = 0.0          // NUEVO: margen del mes
)

class HomeViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val _kpis = MutableLiveData<DashboardKpis>()
    val kpis: LiveData<DashboardKpis> = _kpis

    fun cargar(fincaId: Int) = viewModelScope.launch {
        val ini = DateUtils.mesActualInicio()
        val fin = DateUtils.mesActualFin()

        val ingresos    = db.incomeDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
        val inversiones = db.investmentDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
        val nomina      = db.workDayDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
        val insumos     = db.inputDao().getTotalCostoEnPeriodo(fincaId, ini, fin) ?: 0.0
        val labores     = db.laborHistoryDao().getCostoTotalFinca(fincaId, ini, fin) ?: 0.0
        val egresos     = inversiones + nomina + insumos + labores
        val produccion  = db.productionDao().getTotalKgEnPeriodo(fincaId, ini, fin) ?: 0.0
        val empleados   = db.employeeDao().countActivos(fincaId)
        val lotes       = db.lotDao().countActivos(fincaId)
        val alertas     = db.inputDao().countAlertasStockSync(fincaId)

        // Costo por kg: total egresos / kg producidos
        val costoPorKg = if (produccion > 0) egresos / produccion else 0.0
        val margen     = if (ingresos > 0) ((ingresos - egresos) / ingresos) * 100.0 else 0.0

        _kpis.postValue(DashboardKpis(
            totalIngresos     = ingresos,
            totalEgresos      = egresos,
            ganancia          = ingresos - egresos,
            totalProduccionKg = produccion,
            empleadosActivos  = empleados,
            lotesActivos      = lotes,
            alertasInsumos    = alertas,
            nominaPendiente   = nomina,
            costoPorKg        = costoPorKg,
            margenPct         = margen
        ))
    }
}
