package com.fincamanager.ui.production

import com.fincamanager.ui.base.BaseActivity

import android.os.Bundle
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fincamanager.R
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.Production
import com.fincamanager.databinding.ActivityAddProductionBinding
import com.fincamanager.utils.Constants
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.LotViewModel
import com.fincamanager.viewmodel.ProductionViewModel
import kotlinx.coroutines.launch

class AddProductionActivity : BaseActivity() {

    private lateinit var b: ActivityAddProductionBinding
    private val prodVm: ProductionViewModel by viewModels()
    private val lotVm: LotViewModel by viewModels()
    private var produccionId = 0
    private var fincaId = 0
    private var loteSeleccionadoId = 0
    private var loteSeleccionadoNombre = ""

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityAddProductionBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        fincaId = SessionManager.getFincaId(this)
        produccionId = intent.getIntExtra("produccion_id", 0)
        prodVm.setFinca(fincaId)
        lotVm.setFinca(fincaId)

        b.etFecha.setText(DateUtils.today())
        setupUnidadSpinner()
        setupLoteSpinner()

        if (produccionId != 0) cargarEdicion()

        b.btnSave.setOnClickListener { guardar() }
        b.btnCancel.setOnClickListener { finish() }
    }

    private fun setupUnidadSpinner() {
        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Constants.UNIDADES)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        b.spinnerUnidad.adapter = adapter
    }

    private fun setupLoteSpinner() {
        lotVm.lots.observe(this) { lotes ->
            val nombres = lotes.map { it.nombre }
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, nombres)
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            b.spinnerLote.adapter = adapter
            b.spinnerLote.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: android.view.View?, pos: Int, id: Long) {
                    loteSeleccionadoId = lotes[pos].id
                    loteSeleccionadoNombre = lotes[pos].nombre
                    b.etCultivo.setText(lotes[pos].cultivo)
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }
    }

    private fun cargarEdicion() {
        title = "Editar producción"
        lifecycleScope.launch {
            val db = AppDatabase.getInstance(this@AddProductionActivity)
            val prod = db.productionDao().getByFincaSync(fincaId).firstOrNull { it.id == produccionId } ?: return@launch
            b.etCultivo.setText(prod.cultivo)
            b.etFecha.setText(prod.fecha)
            b.etCantidad.setText(prod.cantidad.toString())
            b.etPrecio.setText(prod.precioUnitario.toString())
            b.etComprador.setText(prod.comprador)
            b.etNotas.setText(prod.notas)
            val unidadIdx = Constants.UNIDADES.indexOf(prod.unidad)
            if (unidadIdx >= 0) b.spinnerUnidad.setSelection(unidadIdx)
        }
    }

    private fun guardar() {
        val cultivo   = b.etCultivo.text.toString().trim()
        val fecha     = b.etFecha.text.toString().trim()
        val cantidadS = b.etCantidad.text.toString().trim()
        val precioS   = b.etPrecio.text.toString().trim()

        if (cultivo.isEmpty() || fecha.isEmpty() || cantidadS.isEmpty()) {
            Toast.makeText(this, "Completa cultivo, fecha y cantidad", Toast.LENGTH_SHORT).show()
            return
        }

        val cantidad = cantidadS.toDoubleOrNull() ?: 0.0
        val precio   = precioS.toDoubleOrNull() ?: 0.0
        val unidad   = b.spinnerUnidad.selectedItem?.toString() ?: "Kg"

        val prod = Production(
            id            = produccionId,
            fincaId       = fincaId,
            loteId        = loteSeleccionadoId,
            loteNombre    = loteSeleccionadoNombre,
            cultivo       = cultivo,
            fecha         = fecha,
            cantidad      = cantidad,
            unidad        = unidad,
            precioUnitario = precio,
            totalVenta    = cantidad * precio,
            comprador     = b.etComprador.text.toString().trim(),
            notas         = b.etNotas.text.toString().trim()
        )
        prodVm.save(prod)
        Toast.makeText(this, "Producción guardada", Toast.LENGTH_SHORT).show()
        finish()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
