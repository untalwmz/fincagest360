package com.fincamanager.ui.settings

import android.content.Intent
import android.os.Bundle
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.lifecycle.lifecycleScope
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.databinding.ActivitySettingsBinding
import com.fincamanager.firebase.FirebaseManager
import com.fincamanager.firebase.SyncWorker
import com.fincamanager.ui.auth.ForgotPasswordActivity
import com.fincamanager.ui.auth.LoginActivity
import com.fincamanager.ui.base.BaseActivity
import com.fincamanager.ui.more.fincas.FincasActivity
import com.fincamanager.utils.AppLogger
import com.fincamanager.utils.LogExporter
import com.fincamanager.utils.PdfExporter
import com.fincamanager.utils.SessionManager
import kotlinx.coroutines.launch

class SettingsActivity : BaseActivity() {

    private lateinit var b: ActivitySettingsBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        try {
            b = ActivitySettingsBinding.inflate(layoutInflater)
            setContentView(b.root)
            applySystemInsets(b.root)

            cargarDatos()

            b.btnBack.setOnClickListener { finish() }

            b.cardPerfil.setOnClickListener { mostrarEditarNombre() }

            b.cardChangePassword.setOnClickListener {
                startActivity(Intent(this, ForgotPasswordActivity::class.java))
            }

            b.cardFincaActiva.setOnClickListener {
                startActivity(Intent(this, FincasActivity::class.java))
            }

            b.cardSync.setOnClickListener {
                val fincaId = SessionManager.getFincaId(this)
                if (fincaId > 0) {
                    AppLogger.i("SettingsActivity", "Sincronización manual iniciada, fincaId=$fincaId")
                    SyncWorker.runNow(this, fincaId)
                    Toast.makeText(this, "Sincronizando…", Toast.LENGTH_SHORT).show()
                } else {
                    Toast.makeText(this, "Selecciona una finca primero", Toast.LENGTH_SHORT).show()
                }
            }

            b.cardExport.setOnClickListener {
                AppLogger.i("SettingsActivity", "Exportando PDF")
                PdfExporter.exportarResumenMes(this, SessionManager.getFincaId(this))
            }

            b.cardLog.setOnClickListener {
                AppLogger.i("SettingsActivity", "Exportando log")
                LogExporter.exportarLog(this)
            }

            b.btnLogout.setOnClickListener {
                AlertDialog.Builder(this)
                    .setTitle("Cerrar sesión")
                    .setMessage("¿Seguro que deseas cerrar sesión?")
                    .setPositiveButton("Cerrar sesión") { _, _ ->
                        AppLogger.i("SettingsActivity", "Cerrando sesión")
                        SyncWorker.cancelAll(this)
                        FirebaseManager.logout()
                        SessionManager.logout(this)
                        startActivity(Intent(this, LoginActivity::class.java).apply {
                            flags = Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_CLEAR_TASK
                        })
                    }
                    .setNegativeButton("Cancelar", null).show()
            }

        } catch (e: Exception) {
            AppLogger.e("SettingsActivity", "Error en onCreate", e)
            Toast.makeText(this, "Error al abrir Ajustes: ${e.message}", Toast.LENGTH_LONG).show()
            finish()
        }
    }

    private fun cargarDatos() {
        try {
            b.tvUserEmail.text   = FirebaseManager.currentUserEmail ?: "Sin correo"
            b.tvUserName.text    = SessionManager.getUserName(this).ifEmpty { "Usuario" }
            b.tvFincaNombre.text = SessionManager.getFincaNombre(this).ifEmpty { "Sin finca activa" }
            try {
                val v = packageManager.getPackageInfo(packageName, 0).versionName
                b.tvVersion.text = "Versión $v"
            } catch (_: Exception) { }
        } catch (e: Exception) {
            AppLogger.e("SettingsActivity", "Error al cargar datos del perfil", e)
        }
    }

    private fun mostrarEditarNombre() {
        val etNombre = EditText(this).apply {
            hint = "Tu nombre"
            setText(SessionManager.getUserName(this@SettingsActivity))
        }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(56, 16, 56, 0)
            addView(etNombre)
        }
        AlertDialog.Builder(this)
            .setTitle("Editar nombre")
            .setView(layout)
            .setPositiveButton("Guardar") { _, _ ->
                val nombre = etNombre.text.toString().trim()
                if (nombre.isEmpty()) {
                    Toast.makeText(this, "El nombre no puede estar vacío", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                // FIX: guardar sesión y actualizar Room de forma segura en corrutina
                SessionManager.saveSession(this, SessionManager.getUserId(this), nombre, SessionManager.getEmail(this))
                FirebaseManager.currentUser?.updateProfile(
                    com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(nombre).build()
                )
                lifecycleScope.launch {
                    try {
                        val db     = AppDatabase.getInstance(this@SettingsActivity)
                        val userId = SessionManager.getUserId(this@SettingsActivity)
                        if (userId > 0) {
                            db.userDao().getById(userId)?.let { user ->
                                db.userDao().update(user.copy(nombre = nombre))
                                AppLogger.i("SettingsActivity", "Nombre actualizado en Room para userId=$userId")
                            }
                        }
                    } catch (e: Exception) {
                        AppLogger.e("SettingsActivity", "Error al actualizar nombre en Room", e)
                    }
                }
                b.tvUserName.text = nombre
                Toast.makeText(this, "Nombre actualizado ✓", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    override fun onResume() {
        super.onResume()
        cargarDatos()
    }
}
