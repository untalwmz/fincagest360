package com.fincamanager.viewmodel

import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import android.app.Application
import androidx.lifecycle.*
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.Input
import com.fincamanager.data.model.InventarioMovimiento
import com.fincamanager.utils.DateUtils
import kotlinx.coroutines.launch

class InventarioViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val movDao = db.inventarioMovimientoDao()
    private val inputDao = db.inputDao()

    private val _insumoId = MutableLiveData<Int>()
    val movimientos: LiveData<List<InventarioMovimiento>> =
        _insumoId.switchMap { movDao.getByInsumo(it) }

    private val _fincaId = MutableLiveData<Int>()
    val movimientosFinca: LiveData<List<InventarioMovimiento>> =
        _fincaId.switchMap { movDao.getByFinca(it) }

    fun setInsumo(id: Int) { _insumoId.value = id }
    fun setFinca(id: Int)  { _fincaId.value = id }

    /** Registra una ENTRADA (compra) y actualiza el stock del insumo */
    fun registrarEntrada(
        insumoId: Int, insumoNombre: String, fincaId: Int,
        cantidad: Double, unidad: String, costoUnitario: Double,
        motivo: String = "Compra", notas: String = ""
    ) = viewModelScope.launch {
        val mov = InventarioMovimiento(
            fincaId       = fincaId,
            insumoId      = insumoId,
            insumoNombre  = insumoNombre,
            tipo          = "ENTRADA",
            cantidad      = cantidad,
            unidad        = unidad,
            costoUnitario = costoUnitario,
            costoTotal    = cantidad * costoUnitario,
            motivo        = motivo,
            fecha         = DateUtils.today(),
            notas         = notas
        )
        movDao.insert(mov)
        actualizarStock(insumoId)
    }

    /** Registra una SALIDA (aplicación, consumo) y actualiza el stock */
    fun registrarSalida(
        insumoId: Int, insumoNombre: String, fincaId: Int,
        cantidad: Double, unidad: String,
        loteId: Int = 0, loteNombre: String = "",
        motivo: String = "Aplicación", notas: String = ""
    ) = viewModelScope.launch {
        val mov = InventarioMovimiento(
            fincaId      = fincaId,
            insumoId     = insumoId,
            insumoNombre = insumoNombre,
            tipo         = "SALIDA",
            cantidad     = cantidad,
            unidad       = unidad,
            motivo       = motivo,
            loteId       = loteId,
            loteNombre   = loteNombre,
            fecha        = DateUtils.today(),
            notas        = notas
        )
        movDao.insert(mov)
        actualizarStock(insumoId)
    }

    fun registrarMovimiento(mov: InventarioMovimiento) = viewModelScope.launch {
        movDao.insert(mov)
        actualizarStock(mov.insumoId)
    }

    fun eliminarMovimiento(id: Int, insumoId: Int) = viewModelScope.launch {
        movDao.delete(id)
        actualizarStock(insumoId)
    }

    /** Recalcula el stock actual del insumo sumando entradas y restando salidas */
    private suspend fun actualizarStock(insumoId: Int) {
        val stockCalculado = movDao.getStockCalculado(insumoId) ?: 0.0
        val insumo = inputDao.getById(insumoId) ?: return
        inputDao.update(insumo.copy(
            stockActual    = stockCalculado.coerceAtLeast(0.0),
            pendienteSync  = true
        ))
    }
}
