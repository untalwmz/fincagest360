package com.fincamanager.utils

import android.content.Context
import android.content.Intent
import android.os.Environment
import androidx.core.content.FileProvider
import com.fincamanager.data.model.*
import com.itextpdf.text.*
import com.itextpdf.text.pdf.*
import java.io.File
import java.io.FileOutputStream
import java.text.SimpleDateFormat
import java.util.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

object PdfExporter {

    private val VERDE       = BaseColor(46, 125, 50)
    private val VERDE_CLARO = BaseColor(232, 245, 233)
    private val ROJO        = BaseColor(198, 40, 40)
    private val GRIS        = BaseColor(107, 114, 128)

    data class ResumenFinanciero(
        val fincaNombre: String,
        val periodo: String,
        val totalIngresos: Double,
        val totalEgresos: Double,
        val totalNomina: Double,
        val totalInsumos: Double,
        val gananciaNetat: Double,
        val producciones: List<Production>,
        val ingresos: List<Income>,
        val inversiones: List<Investment>
    )

    fun exportarReporte(ctx: Context, resumen: ResumenFinanciero): File {
        val dir = ctx.getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS) ?: ctx.filesDir
        dir.mkdirs()
        val fileName = "reporte_${resumen.fincaNombre.replace(" ", "_")}_${
            SimpleDateFormat("yyyyMMdd", Locale.getDefault()).format(Date())
        }.pdf"
        val file = File(dir, fileName)

        val doc = Document(PageSize.A4, 36f, 36f, 54f, 36f)
        PdfWriter.getInstance(doc, FileOutputStream(file))
        doc.open()

        val fontBold   = Font(Font.FontFamily.HELVETICA, 11f, Font.BOLD, BaseColor.WHITE)
        val fontTitle  = Font(Font.FontFamily.HELVETICA, 20f, Font.BOLD, VERDE)
        val fontSub    = Font(Font.FontFamily.HELVETICA, 13f, Font.BOLD, BaseColor.DARK_GRAY)
        val fontNormal = Font(Font.FontFamily.HELVETICA, 10f, Font.NORMAL, BaseColor.DARK_GRAY)
        val fontSmall  = Font(Font.FontFamily.HELVETICA, 9f,  Font.NORMAL, GRIS)

        doc.add(Paragraph("FincaGest 360", fontTitle).apply { alignment = Element.ALIGN_CENTER })
        doc.add(Paragraph(resumen.fincaNombre, Font(Font.FontFamily.HELVETICA, 14f, Font.BOLD)).apply { alignment = Element.ALIGN_CENTER })
        doc.add(Paragraph("Reporte financiero — ${resumen.periodo}", fontSmall).apply { alignment = Element.ALIGN_CENTER })
        doc.add(Chunk.NEWLINE)

        // KPIs
        val kpiTable = PdfPTable(3).apply { widthPercentage = 100f }
        kpiTable.addCell(kpiCell("Ingresos", CurrencyUtils.format(resumen.totalIngresos), VERDE))
        kpiTable.addCell(kpiCell("Egresos",  CurrencyUtils.format(resumen.totalEgresos),  ROJO))
        kpiTable.addCell(kpiCell("Ganancia", CurrencyUtils.format(resumen.gananciaNetat),
            if (resumen.gananciaNetat >= 0) VERDE else ROJO))
        doc.add(kpiTable)
        doc.add(Chunk.NEWLINE)

        // Desglose
        doc.add(Paragraph("Desglose de egresos", fontSub))
        val egTable = PdfPTable(2).apply { widthPercentage = 100f }
        egTable.addCell(headerCell("Concepto", fontBold)); egTable.addCell(headerCell("Monto", fontBold))
        listOf(
            "Nomina / Jornales" to CurrencyUtils.format(resumen.totalNomina),
            "Insumos"           to CurrencyUtils.format(resumen.totalInsumos),
            "Inversiones"       to CurrencyUtils.format(resumen.inversiones.sumOf { it.monto })
        ).forEach { (l, v) ->
            egTable.addCell(dataCell(l, fontNormal))
            egTable.addCell(dataCell(v, fontNormal))
        }
        doc.add(egTable)
        doc.add(Chunk.NEWLINE)

        if (resumen.producciones.isNotEmpty()) {
            doc.add(Paragraph("Produccion del periodo", fontSub))
            val pTable = PdfPTable(5).apply { widthPercentage = 100f; setWidths(floatArrayOf(2f,1.5f,1.5f,1f,1.5f)) }
            listOf("Lote","Cultivo","Fecha","Cantidad","Venta").forEach { pTable.addCell(headerCell(it, fontBold)) }
            resumen.producciones.forEach { p ->
                listOf(p.loteNombre, p.cultivo, DateUtils.toShow(p.fecha), "${p.cantidad} ${p.unidad}", CurrencyUtils.format(p.totalVenta))
                    .forEach { pTable.addCell(dataCell(it, fontNormal)) }
            }
            doc.add(pTable)
            doc.add(Chunk.NEWLINE)
        }

        if (resumen.ingresos.isNotEmpty()) {
            doc.add(Paragraph("Ingresos", fontSub))
            val iTable = PdfPTable(4).apply { widthPercentage = 100f; setWidths(floatArrayOf(2.5f,1.5f,1.5f,1.5f)) }
            listOf("Descripcion","Categoria","Fecha","Monto").forEach { iTable.addCell(headerCell(it, fontBold)) }
            resumen.ingresos.forEach { i ->
                listOf(i.descripcion, i.categoria, DateUtils.toShow(i.fecha), CurrencyUtils.format(i.monto))
                    .forEach { iTable.addCell(dataCell(it, fontNormal)) }
            }
            doc.add(iTable)
        }

        doc.add(Chunk.NEWLINE)
        doc.add(Paragraph("Generado por FincaGest 360  ${DateUtils.toFull(DateUtils.today())}", fontSmall).apply {
            alignment = Element.ALIGN_CENTER
        })
        doc.close()
        return file
    }

    /**
     * Genera y comparte un reporte PDF del mes actual para una finca.
     * Se llama desde SettingsActivity.
     */
    fun exportarResumenMes(ctx: Context, fincaId: Int) {
        android.os.Handler(android.os.Looper.getMainLooper()).post {
            android.widget.Toast.makeText(ctx, "Generando reporte…", android.widget.Toast.LENGTH_SHORT).show()
        }
        // Lanzar en coroutine de IO para no bloquear el main thread
        GlobalScope.launch(Dispatchers.IO) {
            try {
                val db = com.fincamanager.data.database.AppDatabase.getInstance(ctx)
                val ini = DateUtils.mesActualInicio()
                val fin = DateUtils.mesActualFin()
                val ing  = db.incomeDao().getEnPeriodo(fincaId, ini, fin)
                val inv  = db.investmentDao().getEnPeriodo(fincaId, ini, fin)
                val prod = db.productionDao().getEnPeriodo(fincaId, ini, fin)
                val nom  = db.workDayDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
                val ins  = db.inputDao().getTotalCostoEnPeriodo(fincaId, ini, fin) ?: 0.0
                val totalIng = ing.sumOf { it.monto }
                val totalEgr = inv.sumOf { it.monto } + nom + ins
                val fincaNombre = com.fincamanager.utils.SessionManager.getFincaNombre(ctx)
                val resumen = ResumenFinanciero(
                    fincaNombre   = fincaNombre,
                    periodo       = "${DateUtils.toShow(ini)} – ${DateUtils.toShow(fin)}",
                    totalIngresos = totalIng,
                    totalEgresos  = totalEgr,
                    totalNomina   = nom,
                    totalInsumos  = ins,
                    gananciaNetat = totalIng - totalEgr,
                    producciones  = prod,
                    ingresos      = ing,
                    inversiones   = inv
                )
                val file = exportarReporte(ctx, resumen)
                withContext(Dispatchers.Main) {
                    compartirPdf(ctx, file)
                }
            } catch (e: Exception) {
                withContext(Dispatchers.Main) {
                    android.widget.Toast.makeText(ctx, "Error: ${e.message}", android.widget.Toast.LENGTH_LONG).show()
                }
            }
        }
    }

    fun compartirPdf(ctx: Context, file: File) {
        val uri = FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Compartir reporte"))
    }

    private fun kpiCell(label: String, value: String, color: BaseColor) =
        PdfPCell(Phrase().apply {
            add(Chunk("$label\n", Font(Font.FontFamily.HELVETICA, 9f, Font.NORMAL, GRIS)))
            add(Chunk(value, Font(Font.FontFamily.HELVETICA, 14f, Font.BOLD, color)))
        }).apply { backgroundColor = VERDE_CLARO; setPadding(10f); borderColor = BaseColor.LIGHT_GRAY }

    private fun headerCell(text: String, font: Font) =
        PdfPCell(Phrase(text, font)).apply { backgroundColor = VERDE; setPadding(6f); borderColor = VERDE }

    private fun dataCell(text: String, font: Font) =
        PdfPCell(Phrase(text, font)).apply { setPadding(5f); borderColor = BaseColor.LIGHT_GRAY }
}
