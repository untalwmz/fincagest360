package com.fincamanager.ui.production

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fincamanager.databinding.FragmentProductionBinding
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.ProductionViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import com.fincamanager.R

class ProductionFragment : Fragment() {

    private var _b: FragmentProductionBinding? = null
    private val b get() = _b!!
    private val vm: ProductionViewModel by viewModels()
    private lateinit var adapter: ProductionAdapter

    override fun onCreateView(inflater: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentProductionBinding.inflate(inflater, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        val fincaId = SessionManager.getFincaId(requireContext())
        vm.setFinca(fincaId)

        // RecyclerView
        adapter = ProductionAdapter { prod ->
            val intent = Intent(requireContext(), AddProductionActivity::class.java)
            intent.putExtra("produccion_id", prod.id)
            startActivity(intent)
        }
        b.rvProductions.layoutManager = LinearLayoutManager(requireContext())
        b.rvProductions.adapter = adapter

        // Botón agregar
        b.btnAddProduccion.setOnClickListener {
            startActivity(Intent(requireContext(), AddProductionActivity::class.java))
        }

        // Observadores
        vm.productions.observe(viewLifecycleOwner) { list ->
            adapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        vm.comparativa.observe(viewLifecycleOwner) { mapa ->
            setupBarChartLotes(mapa)
        }

        vm.cargarComparativaAnual().observe(viewLifecycleOwner) { datos ->
            setupLineChartMensual(datos)
        }

        vm.cargarComparativaLotes()
        setupCharts()
    }

    private fun setupCharts() {
        with(b.chartLotes) {
            description.isEnabled = false; legend.isEnabled = false
            setDrawGridBackground(false); setPinchZoom(false); isDoubleTapToZoomEnabled = false
            xAxis.position = XAxis.XAxisPosition.BOTTOM; xAxis.setDrawGridLines(false)
            axisLeft.axisMinimum = 0f; axisRight.isEnabled = false
        }
        with(b.chartMensual) {
            description.isEnabled = false; legend.isEnabled = false
            setDrawGridBackground(false); setPinchZoom(false); isDoubleTapToZoomEnabled = false
            xAxis.position = XAxis.XAxisPosition.BOTTOM; xAxis.setDrawGridLines(false)
            axisLeft.axisMinimum = 0f; axisRight.isEnabled = false
        }
    }

    private fun setupBarChartLotes(mapa: Map<String, Double>) {
        val color = resources.getColor(R.color.primary, null)
        val labels = mapa.keys.toList()
        val entries = labels.mapIndexed { i, k -> BarEntry(i.toFloat(), mapa[k]!!.toFloat()) }
        val ds = BarDataSet(entries, "kg").apply { this.color = color; valueTextSize = 10f }
        b.chartLotes.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        b.chartLotes.data = BarData(ds)
        b.chartLotes.animateY(600)
        b.chartLotes.invalidate()
    }

    private fun setupLineChartMensual(datos: List<Pair<String, Double>>) {
        val color = resources.getColor(R.color.primary, null)
        val entries = datos.mapIndexed { i, (_, kg) -> Entry(i.toFloat(), kg.toFloat()) }
        val ds = LineDataSet(entries, "kg").apply {
            this.color = color; setCircleColor(color)
            lineWidth = 2f; circleRadius = 4f; valueTextSize = 10f
            mode = LineDataSet.Mode.CUBIC_BEZIER
            setDrawFilled(true)
            fillColor = resources.getColor(R.color.primary_surface, null)
        }
        b.chartMensual.xAxis.valueFormatter = IndexAxisValueFormatter(datos.map { it.first })
        b.chartMensual.data = LineData(ds)
        b.chartMensual.animateY(600)
        b.chartMensual.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
