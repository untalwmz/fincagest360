package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.NominaLiquidacion

@Dao
interface NominaLiquidacionDao {

    @Query("SELECT * FROM nomina_liquidaciones WHERE fincaId = :fincaId ORDER BY fechaInicio DESC")
    fun getByFinca(fincaId: Int): LiveData<List<NominaLiquidacion>>

    @Query("SELECT * FROM nomina_liquidaciones WHERE empleadoId = :empleadoId ORDER BY fechaInicio DESC")
    fun getByEmpleado(empleadoId: Int): LiveData<List<NominaLiquidacion>>

    @Query("SELECT * FROM nomina_liquidaciones WHERE fincaId = :fincaId AND pagado = 0 ORDER BY fechaInicio DESC")
    fun getPendientesPago(fincaId: Int): LiveData<List<NominaLiquidacion>>

    @Query("SELECT SUM(totalNeto) FROM nomina_liquidaciones WHERE fincaId = :fincaId AND pagado = 0")
    fun getTotalPendiente(fincaId: Int): LiveData<Double?>

    @Query("SELECT * FROM nomina_liquidaciones WHERE id = :id")
    suspend fun getById(id: Int): NominaLiquidacion?

    @Query("SELECT SUM(totalNeto) FROM nomina_liquidaciones WHERE fincaId = :fincaId AND fechaInicio BETWEEN :ini AND :fin")
    suspend fun getTotalEnPeriodo(fincaId: Int, ini: String, fin: String): Double?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(liq: NominaLiquidacion): Long

    @Update
    suspend fun update(liq: NominaLiquidacion)

    @Query("UPDATE nomina_liquidaciones SET pagado = 1, fechaPago = :fecha WHERE id = :id")
    suspend fun marcarPagada(id: Int, fecha: String)

    @Query("DELETE FROM nomina_liquidaciones WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT * FROM nomina_liquidaciones WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<NominaLiquidacion>

    @Query("UPDATE nomina_liquidaciones SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)

}