package com.fincamanager.ui.finance

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.data.model.Income
import com.fincamanager.data.model.Investment
import com.fincamanager.databinding.ItemIncomeBinding
import com.fincamanager.databinding.ItemInvestmentBinding
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils

// ── Income ────────────────────────────────────────────────
class IncomeAdapter(
    private val onDelete: (Income) -> Unit
) : ListAdapter<Income, IncomeAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemIncomeBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(i: Income) {
            b.tvDescripcion.text = i.descripcion
            b.tvCategoria.text   = i.categoria
            b.tvFecha.text       = DateUtils.toShow(i.fecha)
            b.tvMonto.text       = "+ ${CurrencyUtils.format(i.monto)}"
            b.root.setOnLongClickListener {
                AlertDialog.Builder(b.root.context)
                    .setTitle("Eliminar")
                    .setMessage("¿Eliminar este ingreso?")
                    .setPositiveButton("Eliminar") { _, _ -> onDelete(i) }
                    .setNegativeButton("Cancelar", null)
                    .show()
                true
            }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemIncomeBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Income>() {
            override fun areItemsTheSame(a: Income, b: Income) = a.id == b.id
            override fun areContentsTheSame(a: Income, b: Income) = a == b
        }
    }
}

// ── Investment ────────────────────────────────────────────
class InvestmentAdapter(
    private val onDelete: (Investment) -> Unit
) : ListAdapter<Investment, InvestmentAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemInvestmentBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(i: Investment) {
            b.tvDescripcion.text = i.descripcion
            b.tvCategoria.text   = i.categoria
            b.tvFecha.text       = DateUtils.toShow(i.fecha)
            b.tvMonto.text       = "- ${CurrencyUtils.format(i.monto)}"
            b.root.setOnLongClickListener {
                AlertDialog.Builder(b.root.context)
                    .setTitle("Eliminar")
                    .setMessage("¿Eliminar este egreso?")
                    .setPositiveButton("Eliminar") { _, _ -> onDelete(i) }
                    .setNegativeButton("Cancelar", null)
                    .show()
                true
            }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemInvestmentBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Investment>() {
            override fun areItemsTheSame(a: Investment, b: Investment) = a.id == b.id
            override fun areContentsTheSame(a: Investment, b: Investment) = a == b
        }
    }
}
