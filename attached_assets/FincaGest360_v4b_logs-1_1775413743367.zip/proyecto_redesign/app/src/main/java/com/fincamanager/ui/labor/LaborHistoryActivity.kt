package com.fincamanager.ui.labor

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.databinding.ActivityLaborHistoryBinding
import com.fincamanager.databinding.ItemLaborHistoryBinding
import com.fincamanager.data.model.LaborHistory
import com.fincamanager.ui.base.BaseActivity
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils
import com.fincamanager.viewmodel.LaborHistoryViewModel
import com.google.android.material.floatingactionbutton.FloatingActionButton

class LaborHistoryActivity : BaseActivity() {

    private lateinit var b: ActivityLaborHistoryBinding
    private val vm: LaborHistoryViewModel by viewModels()
    private var loteId = 0
    private var loteNombre = ""
    private var fincaId = 0
    private var tipoFiltro = "Todos"

    companion object {
        fun start(ctx: Context, loteId: Int, loteNombre: String, fincaId: Int) {
            ctx.startActivity(Intent(ctx, LaborHistoryActivity::class.java).apply {
                putExtra("loteId", loteId)
                putExtra("loteNombre", loteNombre)
                putExtra("fincaId", fincaId)
            })
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityLaborHistoryBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)

        loteId     = intent.getIntExtra("loteId", 0)
        loteNombre = intent.getStringExtra("loteNombre") ?: "Lote"
        fincaId    = intent.getIntExtra("fincaId", 0)

        b.tvLoteTitulo.text     = "📋 $loteNombre"
        b.tvLoteSubtitulo.text  = "Historial de labores"

        b.rv.layoutManager = LinearLayoutManager(this)
        vm.setLote(loteId)

        vm.historialLote.observe(this) { lista ->
            val filtrada = if (tipoFiltro == "Todos") lista
                           else lista.filter { it.tipo == tipoFiltro }
            b.tvEmpty.visibility = if (filtrada.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            b.rv.adapter = LaborAdapter(filtrada) { labor ->
                AddLaborActivity.start(this, loteId, loteNombre, fincaId, labor)
            }
        }

        // Chips de filtro
        listOf(
            b.chipTodos to "Todos", b.chipFertilizacion to "Fertilización",
            b.chipFumigacion to "Fumigación", b.chipCosecha to "Cosecha",
            b.chipPoda to "Poda", b.chipRiego to "Riego"
        ).forEach { (chip, tipo) ->
            chip.setOnClickListener {
                tipoFiltro = tipo
                vm.historialLote.value?.let { lista ->
                    val filtrada = if (tipo == "Todos") lista else lista.filter { it.tipo == tipo }
                    b.rv.adapter = LaborAdapter(filtrada) { labor ->
                        AddLaborActivity.start(this, loteId, loteNombre, fincaId, labor)
                    }
                }
            }
        }

        b.fab.setOnClickListener {
            AddLaborActivity.start(this, loteId, loteNombre, fincaId, null)
        }
    }
}

class LaborAdapter(
    private val items: List<LaborHistory>,
    private val onClick: (LaborHistory) -> Unit
) : RecyclerView.Adapter<LaborAdapter.VH>() {

    inner class VH(val b: ItemLaborHistoryBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemLaborHistoryBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        with(h.b) {
            tvTipo.text        = item.tipo
            tvDescripcion.text = item.descripcion.ifEmpty { item.tipo }
            tvFecha.text       = DateUtils.toShow(item.fecha)
            tvResponsable.text = if (item.responsable.isNotEmpty()) "• ${item.responsable}" else ""
            tvCantidad.text    = if (item.cantidad > 0) "${String.format("%.1f", item.cantidad)} ${item.unidad}" else ""
            tvCosto.text       = if (item.costo > 0) CurrencyUtils.format(item.costo) else ""
            root.setOnClickListener { onClick(item) }
        }
    }
}
