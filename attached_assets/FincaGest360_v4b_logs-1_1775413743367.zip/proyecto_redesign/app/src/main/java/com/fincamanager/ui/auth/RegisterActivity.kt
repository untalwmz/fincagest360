package com.fincamanager.ui.auth

import com.fincamanager.ui.base.BaseActivity

import android.content.Intent
import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.Finca
import com.fincamanager.data.model.User
import com.fincamanager.databinding.ActivityRegisterBinding
import com.fincamanager.firebase.FirebaseManager
import com.fincamanager.firebase.FirebaseSyncManager
import com.fincamanager.ui.main.MainActivity
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import kotlinx.coroutines.launch

class RegisterActivity : BaseActivity() {

    private lateinit var b: ActivityRegisterBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        b = ActivityRegisterBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)

        b.btnRegister.setOnClickListener { doRegister() }
        b.btnLogin.setOnClickListener { finish() }
    }

    private fun doRegister() {
        val nombre   = b.etNombre.text.toString().trim()
        val email    = b.etEmail.text.toString().trim()
        val password = b.etPassword.text.toString()
        val finca    = b.etFinca.text.toString().trim()

        if (nombre.isEmpty() || email.isEmpty() || password.length < 6 || finca.isEmpty()) {
            Toast.makeText(this, "Completa todos los campos (mín. 6 caracteres contraseña)", Toast.LENGTH_SHORT).show()
            return
        }

        b.progress.visibility = View.VISIBLE
        b.btnRegister.isEnabled = false

        lifecycleScope.launch {
            val result = FirebaseManager.register(email, password)
            result.onSuccess { fbUser ->
                val db = AppDatabase.getInstance(this@RegisterActivity)

                // Crear usuario local
                val userId = db.userDao().insert(
                    User(nombre = nombre, email = email, password = "", fechaCreacion = DateUtils.today())
                ).toInt()

                // Crear primera finca
                val fincaId = db.fincaDao().insert(
                    Finca(nombre = finca, firebaseUid = fbUser.uid, fechaCreacion = DateUtils.today())
                ).toInt()
                db.userDao().setFincaActiva(userId, fincaId)

                // Sync a Firestore
                db.fincaDao().getById(fincaId)?.let { f ->
                    FirebaseSyncManager.syncFinca(f)
                }

                SessionManager.saveSession(this@RegisterActivity, userId, nombre, email)
                SessionManager.setFincaActiva(this@RegisterActivity, fincaId, finca)

                startActivity(Intent(this@RegisterActivity, MainActivity::class.java))
                finish()
            }.onFailure {
                b.progress.visibility = View.GONE
                b.btnRegister.isEnabled = true
                Toast.makeText(this@RegisterActivity, "Error: ${it.message}", Toast.LENGTH_LONG).show()
            }
        }
    }
}
