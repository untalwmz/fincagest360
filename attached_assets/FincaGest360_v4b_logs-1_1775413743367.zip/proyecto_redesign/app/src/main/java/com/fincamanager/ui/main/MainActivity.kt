package com.fincamanager.ui.main

import android.content.Intent
import android.os.Bundle
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import androidx.navigation.fragment.NavHostFragment
import androidx.navigation.ui.setupWithNavController
import com.fincamanager.R
import com.fincamanager.databinding.ActivityMainBinding
import com.fincamanager.firebase.FirebaseManager
import com.fincamanager.firebase.SyncWorker
import com.fincamanager.ui.auth.LoginActivity
import com.fincamanager.utils.SessionManager

class MainActivity : AppCompatActivity() {

    private lateinit var b: ActivityMainBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        // Set colors before super — safe, DecorView not needed for these
        window.statusBarColor = android.graphics.Color.parseColor("#0D2B1F")
        window.navigationBarColor = android.graphics.Color.parseColor("#1B4332")
        // InsetsController needs DecorView attached — defer with post{}
        window.decorView.post {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                window.insetsController?.setSystemBarsAppearance(
                    0,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                )
            }
        }
        super.onCreate(savedInstanceState)

        b = ActivityMainBinding.inflate(layoutInflater)
        setContentView(b.root)

        ViewCompat.setOnApplyWindowInsetsListener(b.root) { _, insets ->
            val systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            b.navHostFragment.updatePadding(top = systemBars.top)
            b.bottomNav.updatePadding(bottom = systemBars.bottom)
            insets
        }

        if (!FirebaseManager.isLoggedIn) {
            startActivity(Intent(this, LoginActivity::class.java))
            finish()
            return
        }

        val navHostFragment = supportFragmentManager
            .findFragmentById(R.id.nav_host_fragment) as NavHostFragment
        b.bottomNav.setupWithNavController(navHostFragment.navController)

        val fincaId = SessionManager.getFincaId(this)
        if (fincaId > 0) {
            SyncWorker.schedulePeriodic(this, fincaId)
            SyncWorker.scheduleBackupDiario(this, fincaId)
        }
    }
}
