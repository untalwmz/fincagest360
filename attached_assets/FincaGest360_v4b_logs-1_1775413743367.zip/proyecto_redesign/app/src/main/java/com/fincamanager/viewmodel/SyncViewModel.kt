package com.fincamanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import androidx.work.WorkInfo
import androidx.work.WorkManager
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.firebase.FirebaseManager
import com.fincamanager.firebase.SyncWorker
import com.fincamanager.utils.DateUtils
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

enum class SyncStatus { IDLE, SYNCING, SUCCESS, ERROR, OFFLINE }

data class SyncState(
    val status: SyncStatus   = SyncStatus.IDLE,
    val mensaje: String      = "",
    val ultimoSync: String   = "",
    val pendientes: Int      = 0
)

class SyncViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val _state = MutableLiveData(SyncState())
    val state: LiveData<SyncState> = _state

    /** Cuenta cuántos registros locales están pendientes de sync */
    fun contarPendientes(fincaId: Int) = viewModelScope.launch {
        val count = withContext(Dispatchers.IO) {
            listOf(
                db.fincaDao().getPendientesSync(),
                db.employeeDao().getPendientesSync(),
                db.lotDao().getPendientesSync(),
                db.workDayDao().getPendientesSync(),
                db.productionDao().getPendientesSync(),
                db.incomeDao().getPendientesSync(),
                db.investmentDao().getPendientesSync(),
                db.inputDao().getPendientesSync(),
                db.cosechaDao().getPendientesSync(),
                db.activityEventDao().getPendientesSync(),
                db.laborHistoryDao().getPendientesSync(),
                db.inventarioMovimientoDao().getPendientesSync(),
                db.nominaLiquidacionDao().getPendientesSync()
            ).sumOf { it.size }
        }
        val cur = _state.value ?: SyncState()
        _state.value = cur.copy(pendientes = count)
    }

    /** Observa el estado del WorkManager para mostrar en UI */
    fun observarSync(context: android.content.Context) {
        WorkManager.getInstance(context)
            .getWorkInfosForUniqueWorkLiveData("finca_sync")
            .observeForever { infos ->
                val info = infos?.firstOrNull() ?: return@observeForever
                val nuevo = when (info.state) {
                    WorkInfo.State.RUNNING   -> SyncState(SyncStatus.SYNCING, "Sincronizando…")
                    WorkInfo.State.SUCCEEDED -> SyncState(SyncStatus.SUCCESS, "Sincronizado ✓",
                        ultimoSync = DateUtils.today())
                    WorkInfo.State.FAILED    -> SyncState(SyncStatus.ERROR, "Error de sincronización")
                    WorkInfo.State.ENQUEUED  -> SyncState(SyncStatus.IDLE, "En cola…")
                    else -> _state.value ?: SyncState()
                }
                _state.value = nuevo
            }
    }

    /** Lanza sync manual */
    fun sincronizarAhora(context: android.content.Context, fincaId: Int) {
        if (!FirebaseManager.isLoggedIn) {
            _state.value = SyncState(SyncStatus.OFFLINE, "Sin sesión activa")
            return
        }
        _state.value = SyncState(SyncStatus.SYNCING, "Sincronizando…")
        SyncWorker.schedule(context, fincaId)
    }
}
