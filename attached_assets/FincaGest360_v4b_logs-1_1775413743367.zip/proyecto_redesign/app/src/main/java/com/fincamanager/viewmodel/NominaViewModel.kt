package com.fincamanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.switchMap
import androidx.lifecycle.viewModelScope
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.NominaLiquidacion
import com.fincamanager.data.model.WorkDay
import com.fincamanager.utils.DateUtils
import kotlinx.coroutines.launch

data class ResumenEmpleado(
    val empleadoId: Int,
    val nombre: String,
    val jornadasPeriodo: Int,
    val horasTotales: Double,
    val totalBruto: Double,
    val pagado: Boolean
)

class NominaViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)
    private val nominaDao = db.nominaLiquidacionDao()
    private val workDayDao = db.workDayDao()
    private val employeeDao = db.employeeDao()

    private val _fincaId = MutableLiveData<Int>()
    val liquidaciones: LiveData<List<NominaLiquidacion>> =
        _fincaId.switchMap { nominaDao.getByFinca(it) }
    val pendientes: LiveData<List<NominaLiquidacion>> =
        _fincaId.switchMap { nominaDao.getPendientesPago(it) }
    val totalPendiente: LiveData<Double?> =
        _fincaId.switchMap { nominaDao.getTotalPendiente(it) }

    private val _resumenEmpleados = MutableLiveData<List<ResumenEmpleado>>()
    val resumenEmpleados: LiveData<List<ResumenEmpleado>> = _resumenEmpleados

    fun setFinca(id: Int) { _fincaId.value = id }

    /** Genera la liquidación de un empleado para un período dado */
    fun generarLiquidacion(
        fincaId: Int, empleadoId: Int, empleadoNombre: String,
        fechaInicio: String, fechaFin: String, deducciones: Double = 0.0,
        notas: String = ""
    ) = viewModelScope.launch {
        val jornales = workDayDao.getJornalesPorEmpleadoEnPeriodo(empleadoId, fechaInicio, fechaFin)
        if (jornales.isEmpty()) return@launch

        val totalBruto = jornales.sumOf { it.pago }
        val totalHoras = jornales.sumOf { it.horasTrabajadas }
        val totalNeto  = totalBruto - deducciones

        val liq = NominaLiquidacion(
            fincaId         = fincaId,
            empleadoId      = empleadoId,
            empleadoNombre  = empleadoNombre,
            fechaInicio     = fechaInicio,
            fechaFin        = fechaFin,
            totalDias       = jornales.size,
            totalHoras      = totalHoras,
            totalBruto      = totalBruto,
            deducciones     = deducciones,
            totalNeto       = totalNeto,
            notas           = notas
        )
        nominaDao.insert(liq)

        // Marcar jornales como pagados
        workDayDao.marcarPagado(empleadoId, fincaId)
    }

    fun marcarLiquidacionPagada(id: Int) = viewModelScope.launch {
        nominaDao.marcarPagada(id, DateUtils.today())
    }

    fun eliminarLiquidacion(id: Int) = viewModelScope.launch {
        nominaDao.delete(id)
    }

    /** Carga resumen de todos los empleados con sus jornales pendientes del mes */
    fun cargarResumenMes(fincaId: Int) = viewModelScope.launch {
        val ini = DateUtils.mesActualInicio()
        val fin = DateUtils.mesActualFin()
        val empleados = employeeDao.getByFincaSync(fincaId)

        val resumen = empleados.map { emp ->
            val jornales = workDayDao.getJornalesPorEmpleadoEnPeriodo(emp.id, ini, fin)
            ResumenEmpleado(
                empleadoId    = emp.id,
                nombre        = emp.nombre,
                jornadasPeriodo = jornales.size,
                horasTotales  = jornales.sumOf { it.horasTrabajadas },
                totalBruto    = jornales.sumOf { it.pago },
                pagado        = jornales.all { it.pagado }
            )
        }.filter { it.jornadasPeriodo > 0 }

        _resumenEmpleados.postValue(resumen)
    }
}
