package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.*

@Dao interface IncomeDao {
    @Query("SELECT * FROM ingresos WHERE fincaId = :fincaId ORDER BY fecha DESC") fun getByFinca(fincaId: Int): LiveData<List<Income>>
    @Query("SELECT * FROM ingresos WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin ORDER BY fecha DESC") suspend fun getEnPeriodo(fincaId: Int, inicio: String, fin: String): List<Income>
    @Query("SELECT SUM(monto) FROM ingresos WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin") suspend fun getTotalEnPeriodo(fincaId: Int, inicio: String, fin: String): Double?
    @Query("SELECT * FROM ingresos WHERE pendienteSync = 1") suspend fun getPendientesSync(): List<Income>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(i: Income): Long
    @Update suspend fun update(i: Income)
    @Query("DELETE FROM ingresos WHERE id = :id") suspend fun delete(id: Int)
    @Query("UPDATE ingresos SET pendienteSync = 0 WHERE id = :id") suspend fun marcarSincronizado(id: Int)
}

@Dao interface InvestmentDao {
    @Query("SELECT * FROM inversiones WHERE fincaId = :fincaId ORDER BY fecha DESC") fun getByFinca(fincaId: Int): LiveData<List<Investment>>
    @Query("SELECT * FROM inversiones WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin ORDER BY fecha DESC") suspend fun getEnPeriodo(fincaId: Int, inicio: String, fin: String): List<Investment>
    @Query("SELECT SUM(monto) FROM inversiones WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin") suspend fun getTotalEnPeriodo(fincaId: Int, inicio: String, fin: String): Double?
    @Query("SELECT * FROM inversiones WHERE pendienteSync = 1") suspend fun getPendientesSync(): List<Investment>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(i: Investment): Long
    @Update suspend fun update(i: Investment)
    @Query("DELETE FROM inversiones WHERE id = :id") suspend fun delete(id: Int)
    @Query("UPDATE inversiones SET pendienteSync = 0 WHERE id = :id") suspend fun marcarSincronizado(id: Int)
}

@Dao interface WorkDayDao {
    @Query("SELECT * FROM jornales WHERE fincaId = :fincaId ORDER BY fecha DESC") fun getByFinca(fincaId: Int): LiveData<List<WorkDay>>
    @Query("SELECT * FROM jornales WHERE trabajadorId = :empId ORDER BY fecha DESC") fun getByEmployee(empId: Int): LiveData<List<WorkDay>>
    @Query("SELECT * FROM jornales WHERE fincaId = :fincaId AND pagado = 0 ORDER BY fecha DESC") fun getPendientesPago(fincaId: Int): LiveData<List<WorkDay>>
    @Query("SELECT SUM(pago) FROM jornales WHERE fincaId = :fincaId AND pagado = 0") fun getTotalPendientePago(fincaId: Int): LiveData<Double?>
    @Query("SELECT SUM(pago) FROM jornales WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin") suspend fun getTotalEnPeriodo(fincaId: Int, inicio: String, fin: String): Double?
    @Query("SELECT SUM(pago) FROM jornales WHERE loteId = :loteId AND fecha BETWEEN :inicio AND :fin") suspend fun getTotalPorLote(loteId: Int, inicio: String, fin: String): Double?
    @Query("SELECT * FROM jornales WHERE pendienteSync = 1") suspend fun getPendientesSync(): List<WorkDay>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(wd: WorkDay): Long
    @Update suspend fun update(wd: WorkDay)
    @Query("DELETE FROM jornales WHERE id = :id") suspend fun delete(id: Int)
    @Query("SELECT * FROM jornales WHERE trabajadorId = :empId AND fecha BETWEEN :ini AND :fin ORDER BY fecha ASC") suspend fun getJornalesPorEmpleadoEnPeriodo(empId: Int, ini: String, fin: String): List<WorkDay>
    @Query("UPDATE jornales SET pagado = 1, pendienteSync = 1 WHERE trabajadorId = :empId AND pagado = 0 AND fincaId = :fincaId") suspend fun marcarPagado(empId: Int, fincaId: Int)
    @Query("UPDATE jornales SET pendienteSync = 0 WHERE id = :id") suspend fun marcarSincronizado(id: Int)
}

@Dao interface CosechaDao {
    @Query("SELECT * FROM cosecha_registros WHERE fincaId = :fincaId ORDER BY semanaInicio DESC") fun getByFinca(fincaId: Int): LiveData<List<CosechaRegistro>>
    @Query("SELECT * FROM cosecha_registros WHERE fincaId = :fincaId AND semanaInicio BETWEEN :inicio AND :fin") suspend fun getEnPeriodo(fincaId: Int, inicio: String, fin: String): List<CosechaRegistro>
    @Query("SELECT * FROM cosecha_registros WHERE pendienteSync = 1") suspend fun getPendientesSync(): List<CosechaRegistro>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(c: CosechaRegistro): Long
    @Update suspend fun update(c: CosechaRegistro)
    @Query("DELETE FROM cosecha_registros WHERE id = :id") suspend fun delete(id: Int)
    @Query("UPDATE cosecha_registros SET pagado = 1, pendienteSync = 1 WHERE id = :id") suspend fun marcarPagado(id: Int)
    @Query("UPDATE cosecha_registros SET pendienteSync = 0 WHERE id = :id") suspend fun marcarSincronizado(id: Int)
}

@Dao interface UserDao {
    @Query("SELECT * FROM usuarios WHERE email = :email LIMIT 1") suspend fun getByEmail(email: String): User?
    @Query("SELECT * FROM usuarios WHERE id = :id") suspend fun getById(id: Int): User?
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(user: User): Long
    @Update suspend fun update(user: User)
    @Query("UPDATE usuarios SET fincaActivaId = :fincaId WHERE id = :userId") suspend fun setFincaActiva(userId: Int, fincaId: Int)
}

@Dao interface ActivityEventDao {
    @Query("SELECT * FROM actividades WHERE fincaId = :fincaId ORDER BY fecha ASC") fun getByFinca(fincaId: Int): LiveData<List<ActivityEvent>>
    @Query("SELECT * FROM actividades WHERE fincaId = :fincaId AND fecha = :fecha ORDER BY hora ASC") suspend fun getByFecha(fincaId: Int, fecha: String): List<ActivityEvent>
    @Query("SELECT * FROM actividades WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin ORDER BY fecha ASC, hora ASC") suspend fun getEnPeriodo(fincaId: Int, inicio: String, fin: String): List<ActivityEvent>
    @Query("SELECT DISTINCT fecha FROM actividades WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin AND completada = 0") suspend fun getFechasConActividades(fincaId: Int, inicio: String, fin: String): List<String>
    @Query("SELECT * FROM actividades WHERE pendienteSync = 1") suspend fun getPendientesSync(): List<ActivityEvent>
    @Insert(onConflict = OnConflictStrategy.REPLACE) suspend fun insert(e: ActivityEvent): Long
    @Update suspend fun update(e: ActivityEvent)
    @Query("DELETE FROM actividades WHERE id = :id") suspend fun delete(id: Int)
    @Query("UPDATE actividades SET completada = 1, pendienteSync = 1 WHERE id = :id") suspend fun marcarCompletada(id: Int)
    @Query("UPDATE actividades SET pendienteSync = 0 WHERE id = :id") suspend fun marcarSincronizado(id: Int)
}
