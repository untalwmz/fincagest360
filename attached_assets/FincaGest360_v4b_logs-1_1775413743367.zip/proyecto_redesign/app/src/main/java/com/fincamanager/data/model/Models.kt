package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "ingresos", indices = [Index("fincaId"), Index("fecha")])
data class Income(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val descripcion: String,
    val categoria: String = "Venta",
    val monto: Double,
    val fecha: String,
    val cliente: String = "",
    val notas: String = "",
    val pendienteSync: Boolean = false
)

@Entity(tableName = "inversiones", indices = [Index("fincaId"), Index("fecha")])
data class Investment(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val descripcion: String,
    val categoria: String = "General",
    val monto: Double,
    val fecha: String,
    val proveedor: String = "",
    val notas: String = "",
    val pendienteSync: Boolean = false
)

@Entity(
    tableName = "jornales",
    indices = [Index("fecha"), Index("trabajadorId"), Index("loteId"), Index("pagado"), Index("fincaId")]
)
data class WorkDay(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val trabajadorId: Int,
    val trabajadorNombre: String = "",
    val loteId: Int,
    val loteNombre: String = "",
    val fecha: String,
    val horasTrabajadas: Double = 8.0,
    val pago: Double,
    val pagoHistorico: Double = 0.0,
    val actividad: String = "",
    val pagado: Boolean = false,
    val notas: String = "",
    val pendienteSync: Boolean = false
)

@Entity(tableName = "cosecha_registros", indices = [Index("fincaId"), Index("semanaInicio")])
data class CosechaRegistro(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val semanaInicio: String,
    val trabajadorId: Int,
    val trabajadorNombre: String,
    val lunes: Double = 0.0,
    val martes: Double = 0.0,
    val miercoles: Double = 0.0,
    val jueves: Double = 0.0,
    val viernes: Double = 0.0,
    val sabado: Double = 0.0,
    val precioPorKg: Double = 0.0,
    val pagado: Boolean = false,
    val pendienteSync: Boolean = false
) {
    val totalKg: Double get() = lunes + martes + miercoles + jueves + viernes + sabado
    val totalEfectivo: Double get() = totalKg * precioPorKg
}

@Entity(tableName = "usuarios")
data class User(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val email: String,
    val password: String,
    val fincaActivaId: Int = 0,
    val fechaCreacion: String = ""
)

// Nuevo: Calendario de actividades
@Entity(tableName = "actividades", indices = [Index("fincaId"), Index("fecha"), Index("loteId")])
data class ActivityEvent(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val loteId: Int = 0,
    val loteNombre: String = "",
    val titulo: String,
    val descripcion: String = "",
    val fecha: String,
    val hora: String = "",
    val tipo: String = "General", // Siembra, Cosecha, Fumigación, Riego, General
    val completada: Boolean = false,
    val pendienteSync: Boolean = false
)
