package com.fincamanager.ui.more.employees

import com.fincamanager.ui.base.BaseActivity

import android.os.Bundle
import android.widget.Toast
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.Employee
import com.fincamanager.databinding.ActivityAddEditEmployeeBinding
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.EmployeeViewModel
import kotlinx.coroutines.launch

class AddEditEmployeeActivity : BaseActivity() {
    private lateinit var b: ActivityAddEditEmployeeBinding
    private val vm: EmployeeViewModel by viewModels()
    private var employeeId = 0

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAddEditEmployeeBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val fincaId = SessionManager.getFincaId(this)
        vm.setFinca(fincaId)
        employeeId = intent.getIntExtra("employee_id", 0)
        title = if (employeeId == 0) "Nuevo empleado" else "Editar empleado"

        if (employeeId != 0) {
            lifecycleScope.launch {
                val db = AppDatabase.getInstance(this@AddEditEmployeeActivity)
                db.employeeDao().getById(employeeId)?.let { e ->
                    b.etNombre.setText(e.nombre)
                    b.etDocumento.setText(e.documento)
                    b.etTelefono.setText(e.telefono)
                    b.etDireccion.setText(e.direccion)
                    b.etJornal.setText(e.precioJornal.toString())
                    b.etNotas.setText(e.notas)
                }
            }
        }

        b.etFechaIngreso.setText(DateUtils.today())

        b.btnSave.setOnClickListener {
            val nombre = b.etNombre.text.toString().trim()
            val jornal = b.etJornal.text.toString().trim()
            if (nombre.isEmpty() || jornal.isEmpty()) {
                Toast.makeText(this, "Nombre y jornal son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.save(Employee(
                id           = employeeId,
                nombre       = nombre,
                documento    = b.etDocumento.text.toString().trim(),
                telefono     = b.etTelefono.text.toString().trim(),
                direccion    = b.etDireccion.text.toString().trim(),
                precioJornal = jornal.toDoubleOrNull() ?: 0.0,
                fechaIngreso = b.etFechaIngreso.text.toString().trim(),
                notas        = b.etNotas.text.toString().trim()
            ))
            finish()
        }
        b.btnCancel.setOnClickListener { finish() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
