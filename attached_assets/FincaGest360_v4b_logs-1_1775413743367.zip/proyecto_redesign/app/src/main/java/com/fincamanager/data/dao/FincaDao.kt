package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.Finca

@Dao
interface FincaDao {
    @Query("SELECT * FROM fincas WHERE activa = 1 ORDER BY nombre ASC")
    fun getAll(): LiveData<List<Finca>>

    @Query("SELECT * FROM fincas WHERE activa = 1 ORDER BY nombre ASC")
    suspend fun getAllSync(): List<Finca>

    @Query("SELECT * FROM fincas WHERE id = :id")
    suspend fun getById(id: Int): Finca?

    @Query("SELECT * FROM fincas WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<Finca>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(finca: Finca): Long

    @Update
    suspend fun update(finca: Finca)

    @Query("UPDATE fincas SET activa = 0 WHERE id = :id")
    suspend fun softDelete(id: Int)

    @Query("UPDATE fincas SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)
}
