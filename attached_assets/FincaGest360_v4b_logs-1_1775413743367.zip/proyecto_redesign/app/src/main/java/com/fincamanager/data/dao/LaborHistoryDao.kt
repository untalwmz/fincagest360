package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.LaborHistory

@Dao
interface LaborHistoryDao {

    @Query("SELECT * FROM labor_history WHERE loteId = :loteId ORDER BY fecha DESC")
    fun getByLote(loteId: Int): LiveData<List<LaborHistory>>

    @Query("SELECT * FROM labor_history WHERE fincaId = :fincaId ORDER BY fecha DESC")
    fun getByFinca(fincaId: Int): LiveData<List<LaborHistory>>

    @Query("SELECT * FROM labor_history WHERE loteId = :loteId AND fecha BETWEEN :inicio AND :fin ORDER BY fecha DESC")
    suspend fun getByLoteEnPeriodo(loteId: Int, inicio: String, fin: String): List<LaborHistory>

    @Query("SELECT * FROM labor_history WHERE fincaId = :fincaId AND tipo = :tipo ORDER BY fecha DESC")
    suspend fun getByTipo(fincaId: Int, tipo: String): List<LaborHistory>

    @Query("SELECT * FROM labor_history WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin ORDER BY fecha DESC")
    suspend fun getEnPeriodo(fincaId: Int, inicio: String, fin: String): List<LaborHistory>

    @Query("SELECT SUM(costo) FROM labor_history WHERE loteId = :loteId AND fecha BETWEEN :inicio AND :fin")
    suspend fun getCostoTotalLote(loteId: Int, inicio: String, fin: String): Double?

    @Query("SELECT SUM(costo) FROM labor_history WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin")
    suspend fun getCostoTotalFinca(fincaId: Int, inicio: String, fin: String): Double?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(labor: LaborHistory): Long

    @Update
    suspend fun update(labor: LaborHistory)

    @Query("DELETE FROM labor_history WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("SELECT * FROM labor_history WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<LaborHistory>

    @Query("UPDATE labor_history SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)

}