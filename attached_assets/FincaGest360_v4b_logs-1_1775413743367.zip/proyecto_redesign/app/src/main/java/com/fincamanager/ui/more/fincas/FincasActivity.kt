package com.fincamanager.ui.more.fincas

import com.fincamanager.ui.base.BaseActivity
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.data.model.Finca
import com.fincamanager.databinding.ActivityFincasBinding
import com.fincamanager.databinding.ItemFincaBinding
import com.fincamanager.firebase.SyncWorker
import com.fincamanager.ui.more.lots.LotsActivity
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.FincaViewModel

class FincasActivity : BaseActivity() {
    private lateinit var b: ActivityFincasBinding
    private val vm: FincaViewModel by viewModels()
    private lateinit var adapter: FincaAdapter
    private var fincaActivaId = 0

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityFincasBinding.inflate(layoutInflater)
        setContentView(b.root); applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Mis Fincas"

        fincaActivaId = SessionManager.getFincaId(this)

        adapter = FincaAdapter(
            fincaActivaId,
            onSelect = { finca ->
                SessionManager.setFincaActiva(this, finca.id, finca.nombre)
                fincaActivaId = finca.id
                SyncWorker.schedule(this, finca.id)
                adapter.setActiva(finca.id)
                Toast.makeText(this, "✓ Finca activa: ${finca.nombre}", Toast.LENGTH_SHORT).show()
            },
            onEdit = { finca -> mostrarDialogFinca(finca) },
            onVerLotes = { finca ->
                startActivity(Intent(this, LotsActivity::class.java).apply {
                    putExtra("finca_id", finca.id)
                    putExtra("finca_nombre", finca.nombre)
                })
            },
            onDelete = { finca ->
                AlertDialog.Builder(this)
                    .setTitle("Eliminar finca")
                    .setMessage("¿Eliminar '${finca.nombre}'? Se perderán todos los datos asociados.")
                    .setPositiveButton("Eliminar") { _, _ -> vm.delete(finca.id) }
                    .setNegativeButton("Cancelar", null).show()
            }
        )
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter

        vm.fincas.observe(this) { list ->
            adapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        b.fab.setOnClickListener { mostrarDialogFinca(null) }
    }

    private fun mostrarDialogFinca(editando: Finca?) {
        val etNombre    = EditText(this).apply { hint = "Nombre de la finca"; setText(editando?.nombre ?: "") }
        val etCultivo   = EditText(this).apply { hint = "Cultivo principal"; setText(editando?.cultivo ?: "") }
        val etUbicacion = EditText(this).apply { hint = "Ubicación / vereda"; setText(editando?.ubicacion ?: "") }
        val etArea      = EditText(this).apply { hint = "Área total (hectáreas)"; inputType = android.text.InputType.TYPE_CLASS_NUMBER or android.text.InputType.TYPE_NUMBER_FLAG_DECIMAL; setText(if ((editando?.areaTotal ?: 0.0) > 0) editando!!.areaTotal.toString() else "") }
        val layout = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(56, 16, 56, 0)
            addView(etNombre); addView(etCultivo); addView(etUbicacion); addView(etArea)
        }
        AlertDialog.Builder(this)
            .setTitle(if (editando == null) "Nueva finca" else "Editar finca")
            .setView(layout)
            .setPositiveButton(if (editando == null) "Crear" else "Guardar") { _, _ ->
                val nombre = etNombre.text.toString().trim()
                if (nombre.isEmpty()) { Toast.makeText(this, "El nombre es obligatorio", Toast.LENGTH_SHORT).show(); return@setPositiveButton }
                vm.save(Finca(
                    id           = editando?.id ?: 0,
                    nombre       = nombre,
                    cultivo      = etCultivo.text.toString().trim(),
                    ubicacion    = etUbicacion.text.toString().trim(),
                    areaTotal    = etArea.text.toString().toDoubleOrNull() ?: 0.0,
                    fechaCreacion = editando?.fechaCreacion ?: DateUtils.today(),
                    firebaseUid  = editando?.firebaseUid ?: ""
                ))
                Toast.makeText(this, if (editando == null) "Finca creada ✓" else "Finca actualizada ✓", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class FincaAdapter(
    private var fincaActivaId: Int,
    private val onSelect: (Finca) -> Unit,
    private val onEdit: (Finca) -> Unit,
    private val onVerLotes: (Finca) -> Unit,
    private val onDelete: (Finca) -> Unit
) : ListAdapter<Finca, FincaAdapter.VH>(DIFF) {

    fun setActiva(id: Int) { fincaActivaId = id; notifyDataSetChanged() }

    inner class VH(private val b: ItemFincaBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(f: Finca) {
            b.tvNombre.text  = f.nombre
            b.tvCultivo.text = f.cultivo.ifEmpty { "Sin cultivo definido" }
            b.tvArea.text    = buildString {
                if (f.areaTotal > 0) append("${f.areaTotal} ha  ")
                if (f.ubicacion.isNotEmpty()) append(f.ubicacion)
            }
            b.ivActiva.visibility = if (f.id == fincaActivaId) View.VISIBLE else View.GONE
            // Tap → select as active finca
            b.root.setOnClickListener { onSelect(f) }
            // Long press → edit
            b.root.setOnLongClickListener {
                AlertDialog.Builder(b.root.context)
                    .setTitle(f.nombre)
                    .setItems(arrayOf("✏️ Editar", "🌿 Ver lotes", "🗑 Eliminar")) { _, which ->
                        when (which) { 0 -> onEdit(f); 1 -> onVerLotes(f); 2 -> onDelete(f) }
                    }.show()
                true
            }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemFincaBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Finca>() {
            override fun areItemsTheSame(a: Finca, b: Finca) = a.id == b.id
            override fun areContentsTheSame(a: Finca, b: Finca) = a == b
        }
    }
}
