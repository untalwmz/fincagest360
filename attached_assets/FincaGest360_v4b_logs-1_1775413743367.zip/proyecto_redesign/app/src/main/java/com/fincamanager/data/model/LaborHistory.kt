package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "labor_history",
    indices = [Index("fincaId"), Index("loteId"), Index("fecha"), Index("tipo")]
)
data class LaborHistory(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val loteId: Int = 0,
    val loteNombre: String = "",
    val fecha: String,               // YYYY-MM-DD
    val tipo: String,                // Fertilización, Fumigación, Cosecha, Riego, Siembra, Poda, General
    val descripcion: String = "",
    val responsable: String = "",    // nombre del empleado o "Propio"
    val cantidad: Double = 0.0,      // kg cosechados, litros aplicados, etc.
    val unidad: String = "",         // kg, L, g, etc.
    val costo: Double = 0.0,
    val notas: String = "",
    val pendienteSync: Boolean = false
)

// Resumen de rentabilidad por lote (no es Entity, es un resultado de query)
data class RentabilidadLote(
    val loteId: Int,
    val loteNombre: String,
    val totalKg: Double,
    val totalVentas: Double,
    val totalCostos: Double,
    val rentabilidad: Double         // totalVentas - totalCostos
)
