package com.fincamanager.ui.base

import android.os.Bundle
import android.view.View
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.updatePadding
import com.fincamanager.utils.AppLogger

/**
 * BaseActivity — Clase base de todas las Activities.
 *
 * Añade logging automático del ciclo de vida (onCreate / onResume / onPause /
 * onDestroy) para que cada pantalla quede registrada en el archivo de log
 * sin necesidad de escribir nada en cada Activity individualmente.
 */
abstract class BaseActivity : AppCompatActivity() {

    // Nombre corto de la clase para los logs (p.ej. "LoginActivity")
    private val logTag get() = this::class.java.simpleName

    // ── Ciclo de vida con logging ─────────────────────────────────────────────

    override fun onCreate(savedInstanceState: Bundle?) {
        WindowCompat.setDecorFitsSystemWindows(window, false)
        window.statusBarColor    = android.graphics.Color.parseColor("#0D2B1F")
        window.navigationBarColor = android.graphics.Color.parseColor("#0D2B1F")
        window.decorView.post {
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.R) {
                window.insetsController?.setSystemBarsAppearance(
                    0,
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                    android.view.WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
                )
            }
        }
        super.onCreate(savedInstanceState)
        AppLogger.d(logTag, "onCreate()")
    }

    override fun onResume() {
        super.onResume()
        AppLogger.d(logTag, "onResume() — pantalla visible")
    }

    override fun onPause() {
        super.onPause()
        AppLogger.d(logTag, "onPause()")
    }

    override fun onDestroy() {
        super.onDestroy()
        AppLogger.d(logTag, "onDestroy()")
    }

    // ── Sistema de insets (sin cambios) ───────────────────────────────────────

    protected fun applySystemInsets(rootView: View, applyBottom: Boolean = true) {
        ViewCompat.setOnApplyWindowInsetsListener(rootView) { view, insets ->
            val bars = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            view.updatePadding(
                top    = bars.top,
                bottom = if (applyBottom) bars.bottom else 0
            )
            insets
        }
    }
}
