package com.fincamanager.ui.auth

import com.fincamanager.ui.base.BaseActivity

import android.os.Bundle
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import com.fincamanager.firebase.FirebaseManager
import com.google.android.material.textfield.TextInputEditText
import com.google.android.material.button.MaterialButton
import android.widget.ProgressBar
import com.fincamanager.R
import kotlinx.coroutines.launch

class ForgotPasswordActivity : BaseActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_forgot_password)
        applySystemInsets(findViewById(android.R.id.content))

        val etEmail  = findViewById<TextInputEditText>(R.id.et_email)
        val btnSend  = findViewById<MaterialButton>(R.id.btn_send)
        val progress = findViewById<ProgressBar>(R.id.progress)

        btnSend.setOnClickListener {
            val email = etEmail.text.toString().trim()
            if (email.isEmpty()) { Toast.makeText(this, "Ingresa tu correo", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            progress.visibility = View.VISIBLE
            btnSend.isEnabled = false
            lifecycleScope.launch {
                FirebaseManager.resetPassword(email)
                    .onSuccess { Toast.makeText(this@ForgotPasswordActivity, "Correo enviado. Revisa tu bandeja.", Toast.LENGTH_LONG).show(); finish() }
                    .onFailure { Toast.makeText(this@ForgotPasswordActivity, "Error enviando correo", Toast.LENGTH_SHORT).show() }
                progress.visibility = View.GONE
                btnSend.isEnabled = true
            }
        }
    }
}
