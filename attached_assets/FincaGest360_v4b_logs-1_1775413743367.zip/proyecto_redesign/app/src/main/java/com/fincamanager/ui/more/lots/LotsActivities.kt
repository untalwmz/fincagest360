package com.fincamanager.ui.more.lots

import com.fincamanager.ui.base.BaseActivity

import android.content.Intent
import android.os.Bundle
import android.view.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import android.widget.*
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.Lot
import com.fincamanager.databinding.ActivityLotsBinding
import com.fincamanager.databinding.ActivityAddEditLotBinding
import com.fincamanager.databinding.ItemLotBinding
import com.fincamanager.utils.Constants
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.LotViewModel
import com.fincamanager.ui.labor.LaborHistoryActivity
import kotlinx.coroutines.launch

// ─── LotsActivity ────────────────────────────────────────
class LotsActivity : BaseActivity() {
    private lateinit var b: ActivityLotsBinding
    private val vm: LotViewModel by viewModels()
    private lateinit var adapter: LotAdapter

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityLotsBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        // Accept finca_id from FincasActivity or use active finca
        val fincaId = intent.getIntExtra("finca_id", SessionManager.getFincaId(this))
        val fincaNombre = intent.getStringExtra("finca_nombre") ?: SessionManager.getFincaNombre(this)
        title = "Lotes — $fincaNombre"
        vm.setFinca(fincaId)
        adapter = LotAdapter(
            onClick = { lot -> startActivity(Intent(this, AddEditLotActivity::class.java).apply { putExtra("lot_id", lot.id) }) },
            onDelete = { lot -> AlertDialog.Builder(this).setTitle("Eliminar").setMessage("¿Eliminar lote ${lot.nombre}?")
                .setPositiveButton("Eliminar") { _, _ -> vm.delete(lot.id) }.setNegativeButton("Cancelar", null).show() }
        )
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter
        vm.lots.observe(this) { list ->
            adapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }
        b.fab.setOnClickListener { startActivity(Intent(this, AddEditLotActivity::class.java)) }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

// ─── LotAdapter ──────────────────────────────────────────
class LotAdapter(
    private val onClick: (Lot) -> Unit,
    private val onDelete: (Lot) -> Unit
) : ListAdapter<Lot, LotAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemLotBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(l: Lot) {
            b.tvNombre.text  = l.nombre
            b.tvCultivo.text = l.cultivo
            b.tvArea.text    = "${l.area} ha"
            b.tvEstado.text  = l.estado
            b.root.setOnClickListener { onClick(l) }
            b.root.setOnLongClickListener { onDelete(l); true }
            b.btnHistorial.setOnClickListener {
                LaborHistoryActivity.start(b.root.context, l.id, l.nombre,
                    SessionManager.getFincaId(b.root.context))
            }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemLotBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Lot>() {
            override fun areItemsTheSame(a: Lot, b: Lot) = a.id == b.id
            override fun areContentsTheSame(a: Lot, b: Lot) = a == b
        }
    }
}

// ─── AddEditLotActivity ───────────────────────────────────
class AddEditLotActivity : BaseActivity() {
    private lateinit var b: ActivityAddEditLotBinding
    private val vm: LotViewModel by viewModels()
    private var lotId = 0

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAddEditLotBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        vm.setFinca(SessionManager.getFincaId(this))
        lotId = intent.getIntExtra("lot_id", 0)
        title = if (lotId == 0) "Nuevo lote" else "Editar lote"

        val estadoAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Constants.ESTADOS_LOTE)
        estadoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        b.spinnerEstado.adapter = estadoAdapter
        b.etFechaSiembra.setText(DateUtils.today())

        if (lotId != 0) {
            lifecycleScope.launch {
                AppDatabase.getInstance(this@AddEditLotActivity).lotDao().getById(lotId)?.let { l ->
                    b.etNombre.setText(l.nombre)
                    b.etArea.setText(l.area.toString())
                    b.etCultivo.setText(l.cultivo)
                    b.etVariedad.setText(l.variedad)
                    b.etFechaSiembra.setText(l.fechaSiembra)
                    b.etDescripcion.setText(l.descripcion)
                    val idx = Constants.ESTADOS_LOTE.indexOf(l.estado)
                    if (idx >= 0) b.spinnerEstado.setSelection(idx)
                }
            }
        }

        b.btnSave.setOnClickListener {
            val nombre = b.etNombre.text.toString().trim()
            val area   = b.etArea.text.toString().trim()
            if (nombre.isEmpty() || area.isEmpty()) {
                Toast.makeText(this, "Nombre y área son obligatorios", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.save(Lot(
                id           = lotId,
                nombre       = nombre,
                area         = area.toDoubleOrNull() ?: 0.0,
                cultivo      = b.etCultivo.text.toString().trim(),
                variedad     = b.etVariedad.text.toString().trim(),
                fechaSiembra = b.etFechaSiembra.text.toString().trim(),
                estado       = b.spinnerEstado.selectedItem?.toString() ?: "Activo",
                descripcion  = b.etDescripcion.text.toString().trim()
            ))
            finish()
        }
        b.btnCancel.setOnClickListener { finish() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
