package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.Employee

@Dao
interface EmployeeDao {
    @Query("SELECT * FROM trabajadores WHERE fincaId = :fincaId AND activo = 1 ORDER BY nombre ASC")
    fun getByFinca(fincaId: Int): LiveData<List<Employee>>

    @Query("SELECT * FROM trabajadores WHERE fincaId = :fincaId AND activo = 1 ORDER BY nombre ASC")
    suspend fun getByFincaSync(fincaId: Int): List<Employee>

    @Query("SELECT * FROM trabajadores WHERE id = :id")
    suspend fun getById(id: Int): Employee?

    @Query("SELECT * FROM trabajadores WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<Employee>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(employee: Employee): Long

    @Update
    suspend fun update(employee: Employee)

    @Query("UPDATE trabajadores SET activo = 0, pendienteSync = 1 WHERE id = :id")
    suspend fun softDelete(id: Int)

    @Query("UPDATE trabajadores SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)

    @Query("SELECT COUNT(*) FROM trabajadores WHERE fincaId = :fincaId AND activo = 1")
    suspend fun countActivos(fincaId: Int): Int
}
