package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.Lot

@Dao
interface LotDao {
    @Query("SELECT * FROM lotes WHERE fincaId = :fincaId ORDER BY nombre ASC")
    fun getByFinca(fincaId: Int): LiveData<List<Lot>>

    @Query("SELECT * FROM lotes WHERE fincaId = :fincaId AND estado = 'Activo' ORDER BY nombre ASC")
    suspend fun getActivosByFincaSync(fincaId: Int): List<Lot>

    @Query("SELECT * FROM lotes WHERE fincaId = :fincaId ORDER BY nombre ASC")
    suspend fun getByFincaSync(fincaId: Int): List<Lot>

    @Query("SELECT * FROM lotes WHERE id = :id")
    suspend fun getById(id: Int): Lot?

    @Query("SELECT * FROM lotes WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<Lot>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(lot: Lot): Long

    @Update
    suspend fun update(lot: Lot)

    @Query("UPDATE lotes SET estado = 'Inactivo', pendienteSync = 1 WHERE id = :id")
    suspend fun softDelete(id: Int)

    @Query("UPDATE lotes SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)

    @Query("SELECT COUNT(*) FROM lotes WHERE fincaId = :fincaId AND estado = 'Activo'")
    suspend fun countActivos(fincaId: Int): Int
}
