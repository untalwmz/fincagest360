package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "inventario_movimientos",
    indices = [Index("fincaId"), Index("insumoId"), Index("fecha")]
)
data class InventarioMovimiento(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val insumoId: Int,
    val insumoNombre: String = "",
    val tipo: String,           // ENTRADA | SALIDA | AJUSTE
    val cantidad: Double,
    val unidad: String = "",
    val costoUnitario: Double = 0.0,
    val costoTotal: Double = 0.0,
    val motivo: String = "",    // Compra, Aplicación en lote, Ajuste, Vencimiento
    val loteId: Int = 0,
    val loteNombre: String = "",
    val fecha: String,
    val notas: String = "",
    val pendienteSync: Boolean = false
)

@Entity(
    tableName = "nomina_liquidaciones",
    indices = [Index("fincaId"), Index("empleadoId"), Index("fechaInicio")]
)
data class NominaLiquidacion(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val empleadoId: Int,
    val empleadoNombre: String = "",
    val fechaInicio: String,
    val fechaFin: String,
    val totalDias: Int = 0,
    val totalHoras: Double = 0.0,
    val totalBruto: Double = 0.0,
    val deducciones: Double = 0.0,
    val totalNeto: Double = 0.0,
    val pagado: Boolean = false,
    val fechaPago: String = "",
    val notas: String = "",
    val pendienteSync: Boolean = false
)
