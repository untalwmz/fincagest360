package com.fincamanager.utils

import java.text.NumberFormat
import java.text.SimpleDateFormat
import java.util.*

// ── Moneda ────────────────────────────────────────────────
object CurrencyUtils {
    private val fmt = NumberFormat.getCurrencyInstance(Locale("es", "CO")).apply {
        maximumFractionDigits = 0
    }
    fun format(amount: Double): String = fmt.format(amount)
    fun formatCompact(amount: Double): String = when {
        amount >= 1_000_000 -> "$ ${String.format("%.1f", amount / 1_000_000)}M"
        amount >= 1_000     -> "$ ${String.format("%.0f", amount / 1_000)}K"
        else                -> "$ ${amount.toInt()}"
    }
}

// ── Fechas ────────────────────────────────────────────────
object DateUtils {
    const val FORMAT_DB   = "yyyy-MM-dd"
    const val FORMAT_SHOW = "dd/MM/yyyy"
    const val FORMAT_FULL = "dd MMM yyyy"

    private val locale = Locale("es", "CO")

    fun today(): String = SimpleDateFormat(FORMAT_DB, locale).format(Date())

    fun toShow(dbDate: String): String = runCatching {
        val sdf = SimpleDateFormat(FORMAT_DB, locale)
        SimpleDateFormat(FORMAT_SHOW, locale).format(sdf.parse(dbDate)!!)
    }.getOrDefault(dbDate)

    fun toFull(dbDate: String): String = runCatching {
        val sdf = SimpleDateFormat(FORMAT_DB, locale)
        SimpleDateFormat(FORMAT_FULL, locale).format(sdf.parse(dbDate)!!)
    }.getOrDefault(dbDate)

    fun mesActualInicio(): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, 1)
        return SimpleDateFormat(FORMAT_DB, locale).format(cal.time)
    }

    fun mesActualFin(): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH))
        return SimpleDateFormat(FORMAT_DB, locale).format(cal.time)
    }

    fun anioActualInicio(): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_YEAR, 1)
        return SimpleDateFormat(FORMAT_DB, locale).format(cal.time)
    }

    fun anioActualFin(): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.MONTH, 11)
        cal.set(Calendar.DAY_OF_MONTH, 31)
        return SimpleDateFormat(FORMAT_DB, locale).format(cal.time)
    }

    fun inicioSemanaActual(): String {
        val cal = Calendar.getInstance()
        cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        return SimpleDateFormat(FORMAT_DB, locale).format(cal.time)
    }

    fun nombreMes(dbDate: String): String = runCatching {
        val sdf = SimpleDateFormat(FORMAT_DB, locale)
        SimpleDateFormat("MMMM", locale).format(sdf.parse(dbDate)!!)
            .replaceFirstChar { it.uppercase() }
    }.getOrDefault("")

    fun ultimosMeses(n: Int): List<Pair<String, String>> {
        val result = mutableListOf<Pair<String, String>>()
        val cal = Calendar.getInstance()
        val sdf = SimpleDateFormat(FORMAT_DB, locale)
        repeat(n) {
            val fin = Calendar.getInstance().apply {
                set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH),
                    cal.getActualMaximum(Calendar.DAY_OF_MONTH))
            }
            val ini = Calendar.getInstance().apply {
                set(cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), 1)
            }
            result.add(0, sdf.format(ini.time) to sdf.format(fin.time))
            cal.add(Calendar.MONTH, -1)
        }
        return result
    }
}

// ── Constantes ────────────────────────────────────────────
object Constants {
    val TIPOS_LABOR    = listOf("Abono", "Fumigación", "Siembra", "Resembrar", "Poda", "Riego", "Control de plagas", "Cosecha manual", "Deshierba", "Aplicación foliar", "General")
    val TIPOS_INSUMO   = listOf("Fertilizante", "Plaguicida", "Semilla", "Herramienta", "Combustible", "General")
    val TIPOS_ACTIVIDAD = listOf("Siembra", "Cosecha", "Fumigación", "Riego", "Poda", "Fertilización", "General")
    val CATEGORIAS_INGRESO = listOf("Venta cosecha", "Subsidio", "Otro ingreso")
    val CATEGORIAS_INVERSION = listOf("Insumos", "Maquinaria", "Infraestructura", "Mano de obra", "Transporte", "General")
    val UNIDADES = listOf("Kg", "g", "L", "mL", "Und", "Bulto", "Canasta", "Tonelada")
    val ESTADOS_LOTE = listOf("Activo", "En descanso", "En preparación", "Cosechado", "Inactivo")
}
