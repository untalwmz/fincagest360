package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "trabajadores",
    indices = [Index("nombre"), Index("activo"), Index("fincaId")]
)
data class Employee(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val nombre: String,
    val documento: String,
    val telefono: String,
    val direccion: String = "",
    val precioJornal: Double,
    val activo: Boolean = true,
    val fechaIngreso: String = "",
    val notas: String = "",
    val pendienteSync: Boolean = false
)
