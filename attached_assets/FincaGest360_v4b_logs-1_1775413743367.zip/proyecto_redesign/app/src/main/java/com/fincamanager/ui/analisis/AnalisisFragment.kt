package com.fincamanager.ui.analisis

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fincamanager.databinding.FragmentAnalisisBinding
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.AnalisisViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter

class AnalisisFragment : Fragment() {

    private var _b: FragmentAnalisisBinding? = null
    private val b get() = _b!!
    private val vm: AnalisisViewModel by viewModels()
    private var fincaId = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _b = FragmentAnalisisBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, saved: Bundle?) {
        super.onViewCreated(view, saved)
        fincaId = SessionManager.getFincaId(requireContext())

        setupCharts()
        setupObservers()
        vm.cargar(fincaId)
    }

    private fun setupObservers() {
        vm.estadoResultados.observe(viewLifecycleOwner) { e ->
            b.tvIngresos.text      = CurrencyUtils.format(e.ingresos)
            b.tvCostoInsumos.text  = "- ${CurrencyUtils.format(e.costoInsumos)}"
            b.tvCostoNomina.text   = "- ${CurrencyUtils.format(e.costoNomina)}"
            b.tvCostoLabores.text  = "- ${CurrencyUtils.format(e.costoLabores)}"
            b.tvOtrosEgresos.text  = "- ${CurrencyUtils.format(e.otrosEgresos)}"
            b.tvUtilidadNeta.text  = CurrencyUtils.format(e.utilidadNeta)
            b.tvMargen.text        = String.format("%.1f%%", e.margenPct)

            val colorUtilidad = resources.getColor(
                if (e.utilidadNeta >= 0) com.fincamanager.R.color.success
                else com.fincamanager.R.color.error, null
            )
            b.tvUtilidadNeta.setTextColor(colorUtilidad)
            b.tvMargen.setTextColor(colorUtilidad)
        }

        vm.flujoCaja.observe(viewLifecycleOwner) { flujo ->
            actualizarFlujoCaja(flujo.meses, flujo.ingresos, flujo.egresos)
        }

        vm.rentabilidadLotes.observe(viewLifecycleOwner) { lotes ->
            if (lotes.isNotEmpty()) {
                // Gráfica de barras de rentabilidad
                val entries = lotes.mapIndexed { i, l -> BarEntry(i.toFloat(), l.rentabilidad.toFloat()) }
                val dataSet = BarDataSet(entries, "Rentabilidad").apply {
                    colors = lotes.map { l ->
                        resources.getColor(
                            if (l.rentabilidad >= 0) com.fincamanager.R.color.success
                            else com.fincamanager.R.color.error, null
                        )
                    }
                    valueTextSize = 9f
                }
                b.chartLotes.xAxis.valueFormatter = IndexAxisValueFormatter(lotes.map { it.loteNombre })
                b.chartLotes.data = BarData(dataSet)
                b.chartLotes.invalidate()

                // Adapter de lista
                b.rvRentabilidad.layoutManager = LinearLayoutManager(requireContext())
                b.rvRentabilidad.adapter = RentabilidadAdapter(lotes)
            }
        }

        vm.produccionPorLote.observe(viewLifecycleOwner) { datos ->
            if (datos.isNotEmpty()) {
                val entries = datos.mapIndexed { i, (_, kg) -> BarEntry(i.toFloat(), kg.toFloat()) }
                val dataSet = BarDataSet(entries, "kg").apply {
                    color = resources.getColor(com.fincamanager.R.color.primary, null)
                    valueTextSize = 9f
                }
                b.chartProduccionLotes.xAxis.valueFormatter = IndexAxisValueFormatter(datos.map { it.first })
                b.chartProduccionLotes.data = BarData(dataSet)
                b.chartProduccionLotes.invalidate()
            }
        }
    }

    private fun setupCharts() {
        // Flujo de caja (líneas)
        with(b.chartFlujo) {
            description.isEnabled = false
            legend.isEnabled = false
            setDrawGridBackground(false)
            setPinchZoom(false)
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false)
            xAxis.granularity = 1f
            axisLeft.axisMinimum = 0f
            axisRight.isEnabled = false
            animateX(500)
        }
        // Rentabilidad por lote
        with(b.chartLotes) {
            description.isEnabled = false
            legend.isEnabled = false
            setDrawGridBackground(false)
            setPinchZoom(false)
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false)
            xAxis.granularity = 1f
            axisLeft.axisMinimum = 0f
            axisRight.isEnabled = false
        }
        // Producción horizontal
        with(b.chartProduccionLotes) {
            description.isEnabled = false
            legend.isEnabled = false
            setDrawGridBackground(false)
            setPinchZoom(false)
            xAxis.setDrawGridLines(false)
            xAxis.granularity = 1f
            axisLeft.axisMinimum = 0f
            axisRight.isEnabled = false
        }
    }

    private fun actualizarFlujoCaja(meses: List<String>, ingresos: List<Double>, egresos: List<Double>) {
        val colorVerde = resources.getColor(com.fincamanager.R.color.success, null)
        val colorRojo  = resources.getColor(com.fincamanager.R.color.error, null)

        val entriesIng = ingresos.mapIndexed { i, v -> Entry(i.toFloat(), v.toFloat()) }
        val entriesEgr = egresos.mapIndexed { i, v -> Entry(i.toFloat(), v.toFloat()) }

        val dsIng = LineDataSet(entriesIng, "Ingresos").apply {
            color = colorVerde; lineWidth = 2f; circleRadius = 4f
            setCircleColor(colorVerde); valueTextSize = 9f
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        val dsEgr = LineDataSet(entriesEgr, "Egresos").apply {
            color = colorRojo; lineWidth = 2f; circleRadius = 4f
            setCircleColor(colorRojo); valueTextSize = 9f
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }

        b.chartFlujo.xAxis.valueFormatter = IndexAxisValueFormatter(meses)
        b.chartFlujo.data = LineData(dsIng, dsEgr)
        b.chartFlujo.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
