package com.fincamanager.ui.labor

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Toast
import androidx.activity.viewModels
import com.fincamanager.databinding.ActivityAddLaborBinding
import com.fincamanager.data.model.LaborHistory
import com.fincamanager.ui.base.BaseActivity
import com.fincamanager.utils.DateUtils
import com.fincamanager.viewmodel.LaborHistoryViewModel

class AddLaborActivity : BaseActivity() {

    private lateinit var b: ActivityAddLaborBinding
    private val vm: LaborHistoryViewModel by viewModels()
    private var editando: LaborHistory? = null
    private var loteId = 0; private var loteNombre = ""; private var fincaId = 0

    companion object {
        fun start(ctx: Context, loteId: Int, loteNombre: String, fincaId: Int, labor: LaborHistory?) {
            ctx.startActivity(Intent(ctx, AddLaborActivity::class.java).apply {
                putExtra("loteId", loteId); putExtra("loteNombre", loteNombre)
                putExtra("fincaId", fincaId)
                labor?.let { putExtra("laborId", it.id); putExtra("laborTipo", it.tipo)
                    putExtra("laborDesc", it.descripcion); putExtra("laborResp", it.responsable)
                    putExtra("laborCantidad", it.cantidad); putExtra("laborUnidad", it.unidad)
                    putExtra("laborCosto", it.costo); putExtra("laborFecha", it.fecha)
                    putExtra("laborNotas", it.notas) }
            })
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAddLaborBinding.inflate(layoutInflater)
        setContentView(b.root); applySystemInsets(b.root)

        loteId = intent.getIntExtra("loteId", 0)
        loteNombre = intent.getStringExtra("loteNombre") ?: ""
        fincaId = intent.getIntExtra("fincaId", 0)

        b.tvTituloLote.text = "Lote: $loteNombre"

        // Spinner tipo labor
        val tipos = listOf("Fertilización", "Fumigación", "Cosecha", "Riego", "Poda", "Siembra", "General")
        b.spinnerTipo.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, tipos)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        // Cargar datos si es edición
        val laborId = intent.getIntExtra("laborId", 0)
        if (laborId > 0) {
            b.spinnerTipo.setSelection(tipos.indexOf(intent.getStringExtra("laborTipo") ?: "General").coerceAtLeast(0))
            b.etDescripcion.setText(intent.getStringExtra("laborDesc"))
            b.etResponsable.setText(intent.getStringExtra("laborResp"))
            b.etCantidad.setText(intent.getDoubleExtra("laborCantidad", 0.0).let { if (it > 0) it.toString() else "" })
            b.etUnidad.setText(intent.getStringExtra("laborUnidad"))
            b.etCosto.setText(intent.getDoubleExtra("laborCosto", 0.0).let { if (it > 0) it.toString() else "" })
            b.etFecha.setText(intent.getStringExtra("laborFecha"))
            b.etNotas.setText(intent.getStringExtra("laborNotas"))
            editando = LaborHistory(id = laborId, loteId = loteId, fincaId = fincaId,
                loteNombre = loteNombre, fecha = intent.getStringExtra("laborFecha") ?: "",
                tipo = intent.getStringExtra("laborTipo") ?: "General")
        } else {
            b.etFecha.setText(DateUtils.today())
        }

        b.btnGuardar.setOnClickListener { guardar(tipos) }
        b.btnCancelar.setOnClickListener { finish() }
    }

    private fun guardar(tipos: List<String>) {
        val tipo = tipos[b.spinnerTipo.selectedItemPosition]
        val desc = b.etDescripcion.text.toString().trim()
        val fecha = b.etFecha.text.toString().trim()
        if (fecha.isEmpty()) { Toast.makeText(this, "Ingresa la fecha", Toast.LENGTH_SHORT).show(); return }

        val labor = LaborHistory(
            id           = editando?.id ?: 0,
            fincaId      = fincaId,
            loteId       = loteId,
            loteNombre   = loteNombre,
            fecha        = fecha,
            tipo         = tipo,
            descripcion  = desc,
            responsable  = b.etResponsable.text.toString().trim(),
            cantidad     = b.etCantidad.text.toString().toDoubleOrNull() ?: 0.0,
            unidad       = b.etUnidad.text.toString().trim(),
            costo        = b.etCosto.text.toString().toDoubleOrNull() ?: 0.0,
            notas        = b.etNotas.text.toString().trim(),
            pendienteSync = true
        )
        vm.registrarLabor(labor)
        Toast.makeText(this, "Labor guardada ✓", Toast.LENGTH_SHORT).show()
        finish()
    }
}
