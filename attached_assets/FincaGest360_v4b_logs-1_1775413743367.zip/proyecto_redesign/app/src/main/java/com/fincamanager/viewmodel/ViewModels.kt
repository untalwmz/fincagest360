package com.fincamanager.viewmodel

import android.app.Application
import androidx.lifecycle.*
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.*
import com.fincamanager.firebase.SyncWorker
import com.fincamanager.utils.DateUtils
import kotlinx.coroutines.launch

class FincaViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).fincaDao()
    val fincas: LiveData<List<Finca>> = dao.getAll()
    fun save(f: Finca) = viewModelScope.launch {
        val id = if (f.id == 0) dao.insert(f.copy(pendienteSync = true)).toInt()
                 else { dao.update(f.copy(pendienteSync = true)); f.id }
        SyncWorker.schedule(getApplication(), id)
    }
    fun delete(id: Int) = viewModelScope.launch { dao.softDelete(id); SyncWorker.schedule(getApplication(), id) }
}

class EmployeeViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).employeeDao()
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val employees: LiveData<List<Employee>> = _fincaIdLive.switchMap { dao.getByFinca(it) }
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id }
    fun save(e: Employee) = viewModelScope.launch {
        val synced = e.copy(fincaId = _fincaId, pendienteSync = true)
        if (e.id == 0) dao.insert(synced) else dao.update(synced)
        SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun delete(id: Int) = viewModelScope.launch { dao.softDelete(id); SyncWorker.schedule(getApplication(), _fincaId) }
}

class LotViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).lotDao()
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val lots: LiveData<List<Lot>> = _fincaIdLive.switchMap { dao.getByFinca(it) }
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id }
    fun save(l: Lot) = viewModelScope.launch {
        val synced = l.copy(fincaId = _fincaId, pendienteSync = true)
        if (l.id == 0) dao.insert(synced) else dao.update(synced)
        SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun delete(id: Int) = viewModelScope.launch { dao.softDelete(id); SyncWorker.schedule(getApplication(), _fincaId) }
}

class ProductionViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).productionDao()
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val productions: LiveData<List<Production>> = _fincaIdLive.switchMap { dao.getByFinca(it) }
    private val _comparativa = MutableLiveData<Map<String, Double>>()
    val comparativa: LiveData<Map<String, Double>> = _comparativa
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id }
    fun save(p: Production) = viewModelScope.launch {
        val synced = p.copy(fincaId = _fincaId, pendienteSync = true)
        if (p.id == 0) dao.insert(synced) else dao.update(synced)
        SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun delete(id: Int) = viewModelScope.launch { dao.delete(id); SyncWorker.schedule(getApplication(), _fincaId) }
    fun cargarComparativaLotes() = viewModelScope.launch {
        val ini = DateUtils.anioActualInicio(); val fin = DateUtils.anioActualFin()
        val todos = dao.getEnPeriodo(_fincaId, ini, fin)
        _comparativa.postValue(todos.groupBy { it.loteNombre }.mapValues { (_, v) -> v.sumOf { it.cantidad } })
    }
    fun cargarComparativaAnual(): LiveData<List<Pair<String, Double>>> {
        val result = MutableLiveData<List<Pair<String, Double>>>()
        viewModelScope.launch {
            val datos = DateUtils.ultimosMeses(6).map { (ini, fin) ->
                DateUtils.nombreMes(ini) to (dao.getTotalKgEnPeriodo(_fincaId, ini, fin) ?: 0.0)
            }
            result.postValue(datos)
        }
        return result
    }
}

class FinanceViewModel(app: Application) : AndroidViewModel(app) {
    private val db = AppDatabase.getInstance(app)
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val incomes: LiveData<List<Income>> = _fincaIdLive.switchMap { db.incomeDao().getByFinca(it) }
    val investments: LiveData<List<Investment>> = _fincaIdLive.switchMap { db.investmentDao().getByFinca(it) }
    private val _resumen = MutableLiveData<Triple<Double, Double, Double>>()
    val resumen: LiveData<Triple<Double, Double, Double>> = _resumen
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id; cargarResumen() }
    fun saveIngreso(i: Income) = viewModelScope.launch {
        val s = i.copy(fincaId = _fincaId, pendienteSync = true)
        if (i.id == 0) db.incomeDao().insert(s) else db.incomeDao().update(s)
        SyncWorker.schedule(getApplication(), _fincaId); cargarResumen()
    }
    fun deleteIngreso(id: Int) = viewModelScope.launch { db.incomeDao().delete(id); cargarResumen() }
    fun saveInversion(inv: Investment) = viewModelScope.launch {
        val s = inv.copy(fincaId = _fincaId, pendienteSync = true)
        if (inv.id == 0) db.investmentDao().insert(s) else db.investmentDao().update(s)
        SyncWorker.schedule(getApplication(), _fincaId); cargarResumen()
    }
    fun deleteInversion(id: Int) = viewModelScope.launch { db.investmentDao().delete(id); cargarResumen() }
    private fun cargarResumen() = viewModelScope.launch {
        val ini = DateUtils.mesActualInicio(); val fin = DateUtils.mesActualFin()
        val ing = db.incomeDao().getTotalEnPeriodo(_fincaId, ini, fin) ?: 0.0
        val inv = db.investmentDao().getTotalEnPeriodo(_fincaId, ini, fin) ?: 0.0
        val nom = db.workDayDao().getTotalEnPeriodo(_fincaId, ini, fin) ?: 0.0
        val ins = db.inputDao().getTotalCostoEnPeriodo(_fincaId, ini, fin) ?: 0.0
        _resumen.postValue(Triple(ing, inv + nom + ins, ing - inv - nom - ins))
    }
}

class InputViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).inputDao()
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val inputs: LiveData<List<Input>> = _fincaIdLive.switchMap { dao.getByFinca(it) }
    val alertasStock: LiveData<List<Input>> = _fincaIdLive.switchMap { dao.getConAlertaStock(it) }
    val countAlertas: LiveData<Int> = _fincaIdLive.switchMap { dao.countAlertasStock(it) }
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id }
    fun save(i: Input) = viewModelScope.launch {
        val synced = i.copy(fincaId = _fincaId, pendienteSync = true, costoTotal = i.cantidad * i.costoUnitario)
        if (i.id == 0) dao.insert(synced) else dao.update(synced)
        SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun delete(id: Int) = viewModelScope.launch { dao.delete(id) }
}

class WorkDayViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).workDayDao()
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val workDays: LiveData<List<WorkDay>> = _fincaIdLive.switchMap { dao.getByFinca(it) }
    val pendientesPago: LiveData<List<WorkDay>> = _fincaIdLive.switchMap { dao.getPendientesPago(it) }
    val totalPendiente: LiveData<Double?> = _fincaIdLive.switchMap { dao.getTotalPendientePago(it) }
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id }
    fun save(wd: WorkDay) = viewModelScope.launch {
        val s = wd.copy(fincaId = _fincaId, pendienteSync = true)
        if (wd.id == 0) dao.insert(s) else dao.update(s)
        SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun marcarPagado(empId: Int) = viewModelScope.launch { dao.marcarPagado(empId, _fincaId); SyncWorker.schedule(getApplication(), _fincaId) }
    fun delete(id: Int) = viewModelScope.launch { dao.delete(id) }
}

class CosechaViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).cosechaDao()
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val registros: LiveData<List<CosechaRegistro>> = _fincaIdLive.switchMap { dao.getByFinca(it) }
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id }
    fun save(c: CosechaRegistro) = viewModelScope.launch {
        val s = c.copy(fincaId = _fincaId, pendienteSync = true)
        if (c.id == 0) dao.insert(s) else dao.update(s)
        SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun marcarPagado(id: Int) = viewModelScope.launch {
        dao.marcarPagado(id); SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun delete(id: Int) = viewModelScope.launch { dao.delete(id) }
}

class ActivityEventViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.getInstance(app).activityEventDao()
    private var _fincaId = 0
    private val _fincaIdLive = MutableLiveData<Int>()
    val events: LiveData<List<ActivityEvent>> = _fincaIdLive.switchMap { dao.getByFinca(it) }
    private val _fechasConActividades = MutableLiveData<Set<String>>()
    val fechasConActividades: LiveData<Set<String>> = _fechasConActividades
    fun setFinca(id: Int) { _fincaId = id; _fincaIdLive.value = id }
    fun save(e: ActivityEvent) = viewModelScope.launch {
        val s = e.copy(fincaId = _fincaId, pendienteSync = true)
        if (e.id == 0) dao.insert(s) else dao.update(s)
        SyncWorker.schedule(getApplication(), _fincaId)
    }
    fun marcarCompletada(id: Int) = viewModelScope.launch { dao.marcarCompletada(id); SyncWorker.schedule(getApplication(), _fincaId) }
    fun delete(id: Int) = viewModelScope.launch { dao.delete(id) }
    fun cargarFechasDelMes(ini: String, fin: String) = viewModelScope.launch {
        _fechasConActividades.postValue(dao.getFechasConActividades(_fincaId, ini, fin).toSet())
    }
}
