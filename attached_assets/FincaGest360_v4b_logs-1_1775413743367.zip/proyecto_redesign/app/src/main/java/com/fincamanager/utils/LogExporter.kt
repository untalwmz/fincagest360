package com.fincamanager.utils

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.widget.Toast
import androidx.core.content.FileProvider
import java.io.File
import java.io.FileWriter
import java.text.SimpleDateFormat
import java.util.*

/**
 * LogExporter — Comparte el archivo de log guardado en Downloads.
 *
 * El archivo ya existe porque AppLogger lo escribe automáticamente
 * desde el inicio de la app. Este objeto solo lo abre para compartir.
 */
object LogExporter {

    fun exportarLog(ctx: Context) {
        try {
            val fileActivo = AppLogger.getLogFile()
            if (fileActivo != null && fileActivo.exists()) {
                compartirArchivo(ctx, fileActivo)
                return
            }
            exportarDesdeLogcat(ctx)
        } catch (e: Exception) {
            Toast.makeText(ctx, "Error exportando log: ${e.message}", Toast.LENGTH_LONG).show()
            AppLogger.e("LogExporter", "Error en exportarLog", e)
        }
    }

    private fun compartirArchivo(ctx: Context, file: File) {
        AppLogger.i("LogExporter", "Compartiendo: ${file.absolutePath} (${file.length()} bytes)")

        val uri: Uri = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            FileProvider.getUriForFile(ctx, "${ctx.packageName}.provider", file)
        } else {
            Uri.fromFile(file)
        }

        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_STREAM, uri)
            putExtra(Intent.EXTRA_SUBJECT, "FincaGest 360 — Log ${file.nameWithoutExtension}")
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        ctx.startActivity(Intent.createChooser(intent, "Compartir log"))

        Toast.makeText(ctx, "Log guardado en:\nDescargas/${file.name}", Toast.LENGTH_LONG).show()
    }

    private fun exportarDesdeLogcat(ctx: Context) {
        val timestamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val fileName  = "FincaGest360_log_$timestamp.txt"
        val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
        dir.mkdirs()
        val file = File(dir, fileName)

        val header = buildString {
            appendLine("=== FincaGest 360 — Logcat export ===")
            appendLine("Fecha      : ${SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())}")
            appendLine("Dispositivo: ${Build.MANUFACTURER} ${Build.MODEL}")
            appendLine("Android    : ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
            appendLine("Paquete    : ${ctx.packageName}")
            appendLine("=====================================")
            appendLine()
        }
        val process = Runtime.getRuntime().exec(
            arrayOf("logcat", "-d", "-v", "time", "*:W", "${ctx.packageName}:V")
        )
        val logText = process.inputStream.bufferedReader().readText()
        process.destroy()

        FileWriter(file).use { fw ->
            fw.write(header)
            fw.write(logText.takeLast(200_000))
        }
        compartirArchivo(ctx, file)
    }
}
