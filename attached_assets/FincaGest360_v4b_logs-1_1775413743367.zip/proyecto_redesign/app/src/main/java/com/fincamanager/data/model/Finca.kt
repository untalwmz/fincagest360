package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "fincas")
data class Finca(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val nombre: String,
    val ubicacion: String = "",
    val areaTotal: Double = 0.0,
    val cultivo: String = "",
    val descripcion: String = "",
    val fechaCreacion: String = "",
    val activa: Boolean = true,
    val firebaseUid: String = "",   // owner uid
    val pendienteSync: Boolean = false
)
