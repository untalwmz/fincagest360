package com.fincamanager.ui.more.calendar

import com.fincamanager.ui.base.BaseActivity
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.R
import com.fincamanager.data.model.ActivityEvent
import com.fincamanager.databinding.ActivityCalendarBinding
import com.fincamanager.databinding.ItemActivityEventBinding
import com.fincamanager.utils.Constants
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.ActivityEventViewModel

class CalendarActivity : BaseActivity() {
    private lateinit var b: ActivityCalendarBinding
    private val vm: ActivityEventViewModel by viewModels()
    private lateinit var adapter: ActivityEventAdapter
    private var fincaId = 0
    private var filtro = "Todas"

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityCalendarBinding.inflate(layoutInflater)
        setContentView(b.root); applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Actividades"

        fincaId = SessionManager.getFincaId(this)
        vm.setFinca(fincaId)

        adapter = ActivityEventAdapter(
            onComplete = { ev ->
                if (!ev.completada) vm.marcarCompletada(ev.id)
            },
            onEdit = { ev -> mostrarDialogActividad(ev) },
            onDelete = { ev ->
                AlertDialog.Builder(this)
                    .setTitle("Eliminar actividad")
                    .setMessage("¿Eliminar '${ev.titulo}'?")
                    .setPositiveButton("Eliminar") { _, _ -> vm.delete(ev.id) }
                    .setNegativeButton("Cancelar", null).show()
            }
        )
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter

        vm.events.observe(this) { list -> aplicarFiltro(list) }

        // Chip filters
        b.chipTodos.setOnCheckedChangeListener { _, c -> if (c) { filtro = "Todas"; vm.events.value?.let { aplicarFiltro(it) } } }
        b.chipPendientes.setOnCheckedChangeListener { _, c -> if (c) { filtro = "Pendientes"; vm.events.value?.let { aplicarFiltro(it) } } }
        b.chipCompletadas.setOnCheckedChangeListener { _, c -> if (c) { filtro = "Completadas"; vm.events.value?.let { aplicarFiltro(it) } } }

        b.fab.setOnClickListener { mostrarDialogActividad(null) }
    }

    private fun aplicarFiltro(list: List<ActivityEvent>) {
        val filtrada = when (filtro) {
            "Pendientes"  -> list.filter { !it.completada }
            "Completadas" -> list.filter { it.completada }
            else -> list
        }
        adapter.submitList(filtrada)
        b.tvEmpty.visibility = if (filtrada.isEmpty()) View.VISIBLE else View.GONE
    }

    private fun mostrarDialogActividad(editando: ActivityEvent?) {
        val dialogView = layoutInflater.inflate(R.layout.dialog_nueva_actividad, null)
        val etTitulo    = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_titulo_act)
        val etFecha     = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_fecha_act)
        val etHora      = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_hora_act)
        val etDesc      = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(R.id.et_desc_act)
        val spinnerTipo = dialogView.findViewById<Spinner>(R.id.spinner_tipo_act)

        val tipoAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Constants.TIPOS_ACTIVIDAD)
        tipoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        spinnerTipo.adapter = tipoAdapter

        editando?.let { e ->
            etTitulo.setText(e.titulo)
            etFecha.setText(e.fecha)
            etHora.setText(e.hora)
            etDesc.setText(e.descripcion)
            val idx = Constants.TIPOS_ACTIVIDAD.indexOf(e.tipo)
            if (idx >= 0) spinnerTipo.setSelection(idx)
        } ?: run {
            etFecha.setText(DateUtils.today())
        }

        AlertDialog.Builder(this)
            .setTitle(if (editando == null) "📅 Nueva actividad" else "✏️ Editar actividad")
            .setView(dialogView)
            .setPositiveButton(if (editando == null) "Guardar" else "Actualizar") { _, _ ->
                val titulo = etTitulo.text.toString().trim()
                val fecha  = etFecha.text.toString().trim()
                if (titulo.isEmpty() || fecha.isEmpty()) {
                    Toast.makeText(this, "Título y fecha son obligatorios", Toast.LENGTH_SHORT).show()
                    return@setPositiveButton
                }
                vm.save(ActivityEvent(
                    id          = editando?.id ?: 0,
                    fincaId     = fincaId,
                    titulo      = titulo,
                    fecha       = fecha,
                    hora        = etHora.text.toString().trim(),
                    descripcion = etDesc.text.toString().trim(),
                    tipo        = spinnerTipo.selectedItem?.toString() ?: "General",
                    completada  = editando?.completada ?: false
                ))
                Toast.makeText(this, if (editando == null) "Actividad guardada ✓" else "Actualizada ✓", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null).show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class ActivityEventAdapter(
    private val onComplete: (ActivityEvent) -> Unit,
    private val onEdit: (ActivityEvent) -> Unit,
    private val onDelete: (ActivityEvent) -> Unit
) : ListAdapter<ActivityEvent, ActivityEventAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemActivityEventBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(e: ActivityEvent) {
            b.tvTitulo.text = e.titulo
            b.tvLote.text   = e.descripcion.ifEmpty { e.tipo }
            b.tvHora.text   = if (e.hora.isNotEmpty()) e.hora else DateUtils.toShow(e.fecha)
            b.tvTipo.text   = e.tipo

            val colorRes = when (e.tipo) {
                "Siembra"     -> R.color.tipo_siembra
                "Cosecha manual" -> R.color.tipo_cosecha
                "Fumigación"  -> R.color.tipo_fumigacion
                "Riego"       -> R.color.tipo_riego
                "Abono"       -> R.color.tipo_abono
                "Poda"        -> R.color.tipo_poda
                else          -> R.color.tipo_general
            }
            b.vTipoColor.setBackgroundColor(b.root.context.resources.getColor(colorRes, null))
            b.tvTipo.setTextColor(b.root.context.resources.getColor(colorRes, null))
            b.tvTipo.setBackgroundColor(b.root.context.resources.getColor(
                when (e.tipo) {
                    "Siembra" -> R.color.success_light
                    "Cosecha manual" -> R.color.warning_light
                    "Fumigación" -> R.color.info_light
                    else -> R.color.primary_surface
                }, null))

            b.tvCheck.text = if (e.completada) "✓" else "○"
            b.tvCheck.setTextColor(b.root.context.resources.getColor(
                if (e.completada) R.color.success else R.color.text_hint, null))

            if (e.completada) {
                b.tvTitulo.paintFlags = b.tvTitulo.paintFlags or android.graphics.Paint.STRIKE_THRU_TEXT_FLAG
                b.root.alpha = 0.6f
            } else {
                b.tvTitulo.paintFlags = 0
                b.root.alpha = 1f
            }

            b.btnCompletar.setOnClickListener { onComplete(e) }
            b.root.setOnClickListener { onEdit(e) }
            b.root.setOnLongClickListener { onDelete(e); true }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemActivityEventBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<ActivityEvent>() {
            override fun areItemsTheSame(a: ActivityEvent, b: ActivityEvent) = a.id == b.id
            override fun areContentsTheSame(a: ActivityEvent, b: ActivityEvent) = a == b
        }
    }
}
