package com.fincamanager.ui.nomina

import androidx.lifecycle.ViewModelProvider
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.fragment.app.Fragment
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import androidx.viewpager2.adapter.FragmentStateAdapter
import com.google.android.material.tabs.TabLayoutMediator
import com.fincamanager.R
import com.fincamanager.data.model.NominaLiquidacion
import com.fincamanager.databinding.ActivityNominaBinding
import com.fincamanager.databinding.ItemLiquidacionBinding
import com.fincamanager.databinding.ItemResumenEmpleadoBinding
import com.fincamanager.ui.base.BaseActivity
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.NominaViewModel
import com.fincamanager.viewmodel.ResumenEmpleado

class NominaActivity : BaseActivity() {

    private lateinit var b: ActivityNominaBinding
    private val vm: NominaViewModel by viewModels()
    private var fincaId = 0

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityNominaBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Nómina"

        fincaId = SessionManager.getFincaId(this)
        vm.setFinca(fincaId)
        vm.cargarResumenMes(fincaId)

        vm.totalPendiente.observe(this) { total ->
            b.tvTotalPendiente.text = CurrencyUtils.format(total ?: 0.0)
        }

        // ViewPager con 2 tabs
        b.viewPager.adapter = NominaPagerAdapter(this, fincaId)
        TabLayoutMediator(b.tabLayout, b.viewPager) { tab, pos ->
            tab.text = if (pos == 0) "Resumen del mes" else "Historial"
        }.attach()

        b.btnNuevaLiquidacion.setOnClickListener { mostrarDialogoLiquidacion() }
    }

    private fun mostrarDialogoLiquidacion() {
        val view = layoutInflater.inflate(R.layout.dialog_nueva_liquidacion, null)
        AlertDialog.Builder(this)
            .setTitle("Nueva Liquidación")
            .setView(view)
            .setPositiveButton("Generar") { _, _ ->
                // La lógica real se maneja en el ResumenFragment
                vm.cargarResumenMes(fincaId)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

// ─── PagerAdapter ─────────────────────────────────────────
class NominaPagerAdapter(activity: NominaActivity, private val fincaId: Int) :
    FragmentStateAdapter(activity) {
    override fun getItemCount() = 2
    override fun createFragment(pos: Int): Fragment =
        if (pos == 0) ResumenMesFragment.newInstance(fincaId)
        else HistorialLiquidacionesFragment.newInstance(fincaId)
}

// ─── ResumenMesFragment ───────────────────────────────────
class ResumenMesFragment : Fragment() {

    companion object {
        fun newInstance(fincaId: Int) = ResumenMesFragment().apply {
            arguments = Bundle().apply { putInt("fincaId", fincaId) }
        }
    }

    private val vm: NominaViewModel by lazy {
        androidx.lifecycle.ViewModelProvider(requireActivity())[NominaViewModel::class.java]
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_resumen_mes, c, false)

    override fun onViewCreated(view: android.view.View, s: Bundle?) {
        super.onViewCreated(view, s)
        val fincaId = arguments?.getInt("fincaId") ?: 0
        val rv = view.findViewById<RecyclerView>(R.id.rv_resumen)
        val tvEmpty = view.findViewById<TextView>(R.id.tv_empty_nomina)
        rv.layoutManager = LinearLayoutManager(requireContext())

        vm.resumenEmpleados.observe(viewLifecycleOwner) { lista ->
            tvEmpty.visibility = if (lista.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            rv.adapter = ResumenEmpleadoAdapter(lista) { resumen ->
                // Generar liquidación
                AlertDialog.Builder(requireContext())
                    .setTitle("Liquidar a ${resumen.nombre}")
                    .setMessage(
                        "Período: ${DateUtils.mesActualInicio()} al ${DateUtils.mesActualFin()}\n" +
                        "Jornadas: ${resumen.jornadasPeriodo}\n" +
                        "Total bruto: ${CurrencyUtils.format(resumen.totalBruto)}\n\n" +
                        "¿Confirmar liquidación?"
                    )
                    .setPositiveButton("Liquidar") { _, _ ->
                        vm.generarLiquidacion(
                            fincaId        = fincaId,
                            empleadoId     = resumen.empleadoId,
                            empleadoNombre = resumen.nombre,
                            fechaInicio    = DateUtils.mesActualInicio(),
                            fechaFin       = DateUtils.mesActualFin()
                        )
                        Toast.makeText(requireContext(), "Liquidación generada ✓", Toast.LENGTH_SHORT).show()
                        vm.cargarResumenMes(fincaId)
                    }
                    .setNegativeButton("Cancelar", null)
                    .show()
            }
        }
    }
}

// ─── HistorialLiquidacionesFragment ──────────────────────
class HistorialLiquidacionesFragment : Fragment() {

    companion object {
        fun newInstance(fincaId: Int) = HistorialLiquidacionesFragment().apply {
            arguments = Bundle().apply { putInt("fincaId", fincaId) }
        }
    }

    private val vm: NominaViewModel by lazy {
        androidx.lifecycle.ViewModelProvider(requireActivity())[NominaViewModel::class.java]
    }

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?) =
        i.inflate(R.layout.fragment_historial_liquidaciones, c, false)

    override fun onViewCreated(view: android.view.View, s: Bundle?) {
        super.onViewCreated(view, s)
        val rv = view.findViewById<RecyclerView>(R.id.rv_liquidaciones)
        val tvEmpty = view.findViewById<TextView>(R.id.tv_empty_historial)
        rv.layoutManager = LinearLayoutManager(requireContext())

        vm.liquidaciones.observe(viewLifecycleOwner) { lista ->
            tvEmpty.visibility = if (lista.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
            rv.adapter = LiquidacionAdapter(lista) { liq ->
                if (!liq.pagado) {
                    AlertDialog.Builder(requireContext())
                        .setTitle("Marcar como pagada")
                        .setMessage("¿Confirmar pago de ${CurrencyUtils.format(liq.totalNeto)} a ${liq.empleadoNombre}?")
                        .setPositiveButton("Confirmar pago") { _, _ ->
                            vm.marcarLiquidacionPagada(liq.id)
                            Toast.makeText(requireContext(), "Pago registrado ✓", Toast.LENGTH_SHORT).show()
                        }
                        .setNegativeButton("Cancelar", null)
                        .show()
                }
            }
        }
    }
}

// ─── Adapters ────────────────────────────────────────────
class ResumenEmpleadoAdapter(
    private val items: List<ResumenEmpleado>,
    private val onLiquidar: (ResumenEmpleado) -> Unit
) : RecyclerView.Adapter<ResumenEmpleadoAdapter.VH>() {
    inner class VH(val b: ItemResumenEmpleadoBinding) : RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemResumenEmpleadoBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        with(h.b) {
            tvNombreEmp.text  = item.nombre
            tvJornadas.text   = "${item.jornadasPeriodo} jornadas · ${String.format("%.0f", item.horasTotales)}h"
            tvTotalEmp.text   = CurrencyUtils.format(item.totalBruto)
            tvEstadoEmp.text  = if (item.pagado) "✓ Pagado" else "Pendiente"
            tvEstadoEmp.setTextColor(root.context.resources.getColor(
                if (item.pagado) R.color.success else R.color.warning, null))
            btnLiquidar.visibility = if (item.pagado) android.view.View.GONE else android.view.View.VISIBLE
            btnLiquidar.setOnClickListener { onLiquidar(item) }
        }
    }
}

class LiquidacionAdapter(
    private val items: List<NominaLiquidacion>,
    private val onClick: (NominaLiquidacion) -> Unit
) : RecyclerView.Adapter<LiquidacionAdapter.VH>() {
    inner class VH(val b: ItemLiquidacionBinding) : RecyclerView.ViewHolder(b.root)
    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemLiquidacionBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun getItemCount() = items.size
    override fun onBindViewHolder(h: VH, i: Int) {
        val item = items[i]
        with(h.b) {
            tvNombreLiq.text  = item.empleadoNombre
            tvPeriodoLiq.text = "${DateUtils.toShow(item.fechaInicio)} → ${DateUtils.toShow(item.fechaFin)}"
            tvDiasLiq.text    = "${item.totalDias} jornadas · ${String.format("%.0f", item.totalHoras)}h"
            tvTotalLiq.text   = CurrencyUtils.format(item.totalNeto)
            tvTotalLiq.setTextColor(root.context.resources.getColor(R.color.primary, null))
            tvEstadoLiq.text  = if (item.pagado) "✓ Pagado" else "Pendiente"
            tvEstadoLiq.setTextColor(root.context.resources.getColor(
                if (item.pagado) R.color.success else R.color.warning, null))
            root.setOnClickListener { onClick(item) }
        }
    }
}
