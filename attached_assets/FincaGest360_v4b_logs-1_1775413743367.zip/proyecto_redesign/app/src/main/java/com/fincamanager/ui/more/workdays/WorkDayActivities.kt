package com.fincamanager.ui.more.workdays

import com.fincamanager.ui.base.BaseActivity

import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.R
import com.fincamanager.data.model.WorkDay
import com.fincamanager.databinding.ActivityWorkDayBinding
import com.fincamanager.databinding.ActivityAddWorkDayBinding
import com.fincamanager.databinding.ItemWorkdayBinding
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.EmployeeViewModel
import com.fincamanager.viewmodel.LotViewModel
import com.fincamanager.viewmodel.WorkDayViewModel

// ─── WorkDayActivity ──────────────────────────────────────
class WorkDayActivity : BaseActivity() {
    private lateinit var b: ActivityWorkDayBinding
    private val vm: WorkDayViewModel by viewModels()
    private lateinit var adapter: WorkDayAdapter

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityWorkDayBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Nómina y Jornales"

        val fincaId = SessionManager.getFincaId(this)
        vm.setFinca(fincaId)

        adapter = WorkDayAdapter { wd ->
            AlertDialog.Builder(this)
                .setTitle("Eliminar jornal")
                .setMessage("¿Eliminar este jornal de ${wd.trabajadorNombre}?")
                .setPositiveButton("Eliminar") { _, _ -> vm.delete(wd.id) }
                .setNegativeButton("Cancelar", null).show()
        }
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter

        vm.totalPendiente.observe(this) { total ->
            b.tvTotalPendiente.text = "Por pagar: ${CurrencyUtils.format(total ?: 0.0)}"
        }
        vm.workDays.observe(this) { list ->
            adapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        b.fab.setOnClickListener { startActivity(Intent(this, AddWorkDayActivity::class.java)) }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

// ─── WorkDayAdapter ───────────────────────────────────────
class WorkDayAdapter(
    private val onDelete: (WorkDay) -> Unit
) : ListAdapter<WorkDay, WorkDayAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemWorkdayBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(wd: WorkDay) {
            b.tvTrabajador.text = wd.trabajadorNombre
            b.tvLote.text       = "${wd.loteNombre} · ${wd.actividad}"
            b.tvFecha.text      = DateUtils.toShow(wd.fecha)
            b.tvPago.text       = CurrencyUtils.format(wd.pago)
            b.tvEstado.text     = if (wd.pagado) "✓ Pagado" else "Pendiente"
            b.tvEstado.setTextColor(b.root.context.resources.getColor(
                if (wd.pagado) R.color.success else R.color.warning, null))
            b.root.setOnLongClickListener { onDelete(wd); true }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemWorkdayBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<WorkDay>() {
            override fun areItemsTheSame(a: WorkDay, b: WorkDay) = a.id == b.id
            override fun areContentsTheSame(a: WorkDay, b: WorkDay) = a == b
        }
    }
}

// ─── AddWorkDayActivity ───────────────────────────────────
class AddWorkDayActivity : BaseActivity() {
    private lateinit var b: ActivityAddWorkDayBinding
    private val vm: WorkDayViewModel by viewModels()
    private val empVm: EmployeeViewModel by viewModels()
    private val lotVm: LotViewModel by viewModels()
    private var empId = 0; private var empNombre = ""
    private var lotId = 0; private var lotNombre = ""
    private var jornal = 0.0

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAddWorkDayBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Registrar jornal"

        val fincaId = SessionManager.getFincaId(this)
        vm.setFinca(fincaId); empVm.setFinca(fincaId); lotVm.setFinca(fincaId)

        b.etFecha.setText(DateUtils.today())
        b.etHoras.setText("8")

        empVm.employees.observe(this) { emps ->
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, emps.map { it.nombre })
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            b.spinnerEmpleado.adapter = adapter
            b.spinnerEmpleado.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    empId = emps[pos].id; empNombre = emps[pos].nombre; jornal = emps[pos].precioJornal
                    b.etPago.setText(jornal.toString())
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }

        lotVm.lots.observe(this) { lots ->
            val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, lots.map { it.nombre })
            adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            b.spinnerLote.adapter = adapter
            b.spinnerLote.onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
                override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) {
                    lotId = lots[pos].id; lotNombre = lots[pos].nombre
                }
                override fun onNothingSelected(p: AdapterView<*>?) {}
            }
        }

        b.btnSave.setOnClickListener {
            val pago = b.etPago.text.toString().toDoubleOrNull() ?: 0.0
            vm.save(WorkDay(
                trabajadorId     = empId,
                trabajadorNombre = empNombre,
                loteId           = lotId,
                loteNombre       = lotNombre,
                fecha            = b.etFecha.text.toString().trim(),
                horasTrabajadas  = b.etHoras.text.toString().toDoubleOrNull() ?: 8.0,
                pago             = pago,
                pagoHistorico    = pago,
                actividad        = b.etActividad.text.toString().trim(),
                notas            = b.etNotas.text.toString().trim()
            ))
            finish()
        }
        b.btnCancel.setOnClickListener { finish() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
