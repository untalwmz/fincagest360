package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.Input

@Dao
interface InputDao {
    @Query("SELECT * FROM insumos WHERE fincaId = :fincaId ORDER BY fecha DESC")
    fun getByFinca(fincaId: Int): LiveData<List<Input>>

    @Query("SELECT * FROM insumos WHERE fincaId = :fincaId ORDER BY fecha DESC")
    suspend fun getByFincaSync(fincaId: Int): List<Input>

    @Query("SELECT * FROM insumos WHERE fincaId = :fincaId AND stockMinimo > 0 AND stockActual <= stockMinimo")
    fun getConAlertaStock(fincaId: Int): LiveData<List<Input>>

    @Query("SELECT COUNT(*) FROM insumos WHERE fincaId = :fincaId AND stockMinimo > 0 AND stockActual <= stockMinimo")
    fun countAlertasStock(fincaId: Int): LiveData<Int>

    @Query("SELECT COUNT(*) FROM insumos WHERE fincaId = :fincaId AND stockMinimo > 0 AND stockActual <= stockMinimo")
    suspend fun countAlertasStockSync(fincaId: Int): Int

    @Query("SELECT * FROM insumos WHERE id = :id")
    suspend fun getById(id: Int): Input?

    @Query("SELECT * FROM insumos WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<Input>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(input: Input): Long

    @Update
    suspend fun update(input: Input)

    @Query("DELETE FROM insumos WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("UPDATE insumos SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)

    @Query("SELECT SUM(costoTotal) FROM insumos WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin")
    suspend fun getTotalCostoEnPeriodo(fincaId: Int, inicio: String, fin: String): Double?
}
