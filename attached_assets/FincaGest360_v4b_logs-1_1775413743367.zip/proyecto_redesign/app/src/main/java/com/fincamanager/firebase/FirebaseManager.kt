package com.fincamanager.firebase

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.MemoryCacheSettings
import com.google.firebase.firestore.PersistentCacheSettings
import com.google.firebase.firestore.firestoreSettings
import kotlinx.coroutines.tasks.await

object FirebaseManager {

    private val auth: FirebaseAuth by lazy { FirebaseAuth.getInstance() }

    val db: FirebaseFirestore by lazy {
        FirebaseFirestore.getInstance().also { fs ->
            fs.firestoreSettings = firestoreSettings {
                setLocalCacheSettings(PersistentCacheSettings.newBuilder().build())
            }
        }
    }

    val currentUser: FirebaseUser? get() = auth.currentUser
    val isLoggedIn: Boolean        get() = auth.currentUser != null
    val userId: String?            get() = auth.currentUser?.uid
    val currentUserEmail: String?  get() = auth.currentUser?.email

    suspend fun register(email: String, password: String): Result<FirebaseUser> = runCatching {
        auth.createUserWithEmailAndPassword(email, password).await().user!!
    }

    suspend fun login(email: String, password: String): Result<FirebaseUser> = runCatching {
        auth.signInWithEmailAndPassword(email, password).await().user!!
    }

    suspend fun resetPassword(email: String): Result<Unit> = runCatching {
        auth.sendPasswordResetEmail(email).await()
    }

    fun logout() = auth.signOut()

    private fun userDoc() = userId?.let { db.collection("users").document(it) }

    fun fincasRef()               = userDoc()?.collection("fincas")
    fun fincaDoc(fincaId: String) = fincasRef()?.document(fincaId)

    fun empleadosRef(fincaId: String)   = fincaDoc(fincaId)?.collection("empleados")
    fun lotesRef(fincaId: String)       = fincaDoc(fincaId)?.collection("lotes")
    fun jornalesRef(fincaId: String)    = fincaDoc(fincaId)?.collection("jornales")
    fun produccionRef(fincaId: String)  = fincaDoc(fincaId)?.collection("produccion")
    fun ingresosRef(fincaId: String)    = fincaDoc(fincaId)?.collection("ingresos")
    fun inversionesRef(fincaId: String) = fincaDoc(fincaId)?.collection("inversiones")
    fun insumosRef(fincaId: String)     = fincaDoc(fincaId)?.collection("insumos")
    fun cosechaRef(fincaId: String)     = fincaDoc(fincaId)?.collection("cosecha")
    fun actividadesRef(fincaId: String) = fincaDoc(fincaId)?.collection("actividades")
    fun laborHistoryRef(fincaId: String)    = fincaDoc(fincaId)?.collection("labor_history")
    fun inventarioMovRef(fincaId: String)   = fincaDoc(fincaId)?.collection("inventario_movimientos")
    fun nominaLiqRef(fincaId: String)       = fincaDoc(fincaId)?.collection("nomina_liquidaciones")
    fun backupMetaRef(fincaId: String)      = fincaDoc(fincaId)?.collection("backups")
}
