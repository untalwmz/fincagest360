package com.fincamanager.ui.finance

import android.content.Intent
import android.graphics.Color
import android.os.Bundle
import android.view.*
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import androidx.recyclerview.widget.LinearLayoutManager
import com.fincamanager.R
import com.fincamanager.databinding.FragmentFinanceBinding
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.FinanceViewModel
import com.github.mikephil.charting.data.*

class FinanceFragment : Fragment() {

    private var _b: FragmentFinanceBinding? = null
    private val b get() = _b!!
    private val vm: FinanceViewModel by viewModels()
    private lateinit var incomeAdapter: IncomeAdapter
    private lateinit var investmentAdapter: InvestmentAdapter
    private var showingIngresos = true

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentFinanceBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        val fincaId = SessionManager.getFincaId(requireContext())
        vm.setFinca(fincaId)

        // Adapters
        incomeAdapter = IncomeAdapter { income -> vm.deleteIngreso(income.id) }
        investmentAdapter = InvestmentAdapter { inv -> vm.deleteInversion(inv.id) }
        b.rvFinance.layoutManager = LinearLayoutManager(requireContext())
        b.rvFinance.adapter = incomeAdapter

        // Tabs
        b.tabLayout.addTab(b.tabLayout.newTab().setText("Ingresos"))
        b.tabLayout.addTab(b.tabLayout.newTab().setText("Egresos"))
        b.tabLayout.addOnTabSelectedListener(object : com.google.android.material.tabs.TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: com.google.android.material.tabs.TabLayout.Tab) {
                showingIngresos = tab.position == 0
                b.rvFinance.adapter = if (showingIngresos) incomeAdapter else investmentAdapter
            }
            override fun onTabUnselected(tab: com.google.android.material.tabs.TabLayout.Tab) {}
            override fun onTabReselected(tab: com.google.android.material.tabs.TabLayout.Tab) {}
        })

        b.btnAddIngreso.setOnClickListener {
            startActivity(Intent(requireContext(), AddIncomeActivity::class.java))
        }
        b.btnAddInversion.setOnClickListener {
            startActivity(Intent(requireContext(), AddInvestmentActivity::class.java))
        }

        setupPieChart()

        vm.incomes.observe(viewLifecycleOwner) { list ->
            incomeAdapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty() && showingIngresos) View.VISIBLE else View.GONE
        }
        vm.investments.observe(viewLifecycleOwner) { list ->
            investmentAdapter.submitList(list)
        }
        vm.resumen.observe(viewLifecycleOwner) { (ing, egr, gan) ->
            b.tvTotalIngresos.text = CurrencyUtils.format(ing)
            b.tvTotalEgresos.text  = CurrencyUtils.format(egr)
            b.tvGanancia.text      = CurrencyUtils.format(gan)
            b.tvGanancia.setTextColor(resources.getColor(if (gan >= 0) R.color.primary else R.color.error, null))
            actualizarPie(ing, egr)
        }
    }

    private fun setupPieChart() {
        with(b.chartPie) {
            description.isEnabled  = false
            isDrawHoleEnabled      = true
            holeRadius             = 50f
            setHoleColor(Color.WHITE)
            setDrawEntryLabels(false)
            legend.isEnabled       = true
            animateY(800)
        }
    }

    private fun actualizarPie(ingresos: Double, egresos: Double) {
        if (ingresos == 0.0 && egresos == 0.0) return
        val entries = listOf(
            PieEntry(ingresos.toFloat(), "Ingresos"),
            PieEntry(egresos.toFloat(),  "Egresos")
        )
        val colors = listOf(
            resources.getColor(R.color.primary, null),
            resources.getColor(R.color.error, null)
        )
        val ds = PieDataSet(entries, "").apply {
            this.colors = colors
            valueTextSize = 12f
            valueTextColor = Color.WHITE
        }
        b.chartPie.data = PieData(ds)
        b.chartPie.invalidate()
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
