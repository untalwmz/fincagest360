package com.fincamanager.data.dao

import androidx.lifecycle.LiveData
import androidx.room.*
import com.fincamanager.data.model.Production

@Dao
interface ProductionDao {
    @Query("SELECT * FROM produccion WHERE fincaId = :fincaId ORDER BY fecha DESC")
    fun getByFinca(fincaId: Int): LiveData<List<Production>>

    @Query("SELECT * FROM produccion WHERE fincaId = :fincaId ORDER BY fecha DESC")
    suspend fun getByFincaSync(fincaId: Int): List<Production>

    @Query("SELECT * FROM produccion WHERE loteId = :loteId ORDER BY fecha DESC")
    fun getByLote(loteId: Int): LiveData<List<Production>>

    @Query("SELECT * FROM produccion WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin ORDER BY fecha ASC")
    suspend fun getEnPeriodo(fincaId: Int, inicio: String, fin: String): List<Production>

    @Query("SELECT * FROM produccion WHERE loteId = :loteId AND fecha BETWEEN :inicio AND :fin ORDER BY fecha ASC")
    suspend fun getByLoteEnPeriodo(loteId: Int, inicio: String, fin: String): List<Production>

    // Por fincaId
    @Query("SELECT SUM(cantidad) FROM produccion WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin")
    suspend fun getTotalKgEnPeriodo(fincaId: Int, inicio: String, fin: String): Double?

    @Query("SELECT SUM(totalVenta) FROM produccion WHERE fincaId = :fincaId AND fecha BETWEEN :inicio AND :fin")
    suspend fun getTotalVentasEnPeriodo(fincaId: Int, inicio: String, fin: String): Double?

    // Por loteId (para análisis por lote)
    @Query("SELECT SUM(cantidad) FROM produccion WHERE loteId = :loteId AND fecha BETWEEN :inicio AND :fin")
    suspend fun getTotalKgPorLote(loteId: Int, inicio: String, fin: String): Double?

    @Query("SELECT SUM(totalVenta) FROM produccion WHERE loteId = :loteId AND fecha BETWEEN :inicio AND :fin")
    suspend fun getTotalVentasPorLote(loteId: Int, inicio: String, fin: String): Double?

    @Query("SELECT * FROM produccion WHERE pendienteSync = 1")
    suspend fun getPendientesSync(): List<Production>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insert(p: Production): Long

    @Update
    suspend fun update(p: Production)

    @Query("DELETE FROM produccion WHERE id = :id")
    suspend fun delete(id: Int)

    @Query("UPDATE produccion SET pendienteSync = 0 WHERE id = :id")
    suspend fun marcarSincronizado(id: Int)
}
