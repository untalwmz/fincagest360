package com.fincamanager.ui.finance

import com.fincamanager.ui.base.BaseActivity

import android.os.Bundle
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AppCompatActivity
import com.fincamanager.data.model.Income
import com.fincamanager.data.model.Investment
import com.fincamanager.databinding.ActivityAddIncomeBinding
import com.fincamanager.databinding.ActivityAddInvestmentBinding
import com.fincamanager.utils.Constants
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.FinanceViewModel

// ── Ingreso ───────────────────────────────────────────────
class AddIncomeActivity : BaseActivity() {
    private lateinit var b: ActivityAddIncomeBinding
    private val vm: FinanceViewModel by viewModels()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAddIncomeBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Nuevo ingreso"

        vm.setFinca(SessionManager.getFincaId(this))
        b.etFecha.setText(DateUtils.today())

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Constants.CATEGORIAS_INGRESO)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        b.spinnerCategoria.adapter = adapter

        b.btnSave.setOnClickListener {
            val desc   = b.etDescripcion.text.toString().trim()
            val montoS = b.etMonto.text.toString().trim()
            val fecha  = b.etFecha.text.toString().trim()
            if (desc.isEmpty() || montoS.isEmpty() || fecha.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.saveIngreso(Income(
                descripcion = desc,
                categoria   = b.spinnerCategoria.selectedItem?.toString() ?: "Venta",
                monto       = montoS.toDouble(),
                fecha       = fecha,
                cliente     = b.etCliente.text.toString().trim(),
                notas       = b.etNotas.text.toString().trim()
            ))
            finish()
        }
        b.btnCancel.setOnClickListener { finish() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

// ── Inversión ─────────────────────────────────────────────
class AddInvestmentActivity : BaseActivity() {
    private lateinit var b: ActivityAddInvestmentBinding
    private val vm: FinanceViewModel by viewModels()

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAddInvestmentBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Nuevo egreso"

        vm.setFinca(SessionManager.getFincaId(this))
        b.etFecha.setText(DateUtils.today())

        val adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Constants.CATEGORIAS_INVERSION)
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        b.spinnerCategoria.adapter = adapter

        b.btnSave.setOnClickListener {
            val desc   = b.etDescripcion.text.toString().trim()
            val montoS = b.etMonto.text.toString().trim()
            val fecha  = b.etFecha.text.toString().trim()
            if (desc.isEmpty() || montoS.isEmpty() || fecha.isEmpty()) {
                Toast.makeText(this, "Completa todos los campos", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }
            vm.saveInversion(Investment(
                descripcion = desc,
                categoria   = b.spinnerCategoria.selectedItem?.toString() ?: "General",
                monto       = montoS.toDouble(),
                fecha       = fecha,
                proveedor   = b.etProveedor.text.toString().trim(),
                notas       = b.etNotas.text.toString().trim()
            ))
            finish()
        }
        b.btnCancel.setOnClickListener { finish() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
