package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "lotes",
    indices = [Index("fincaId"), Index("estado")]
)
data class Lot(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val nombre: String,
    val area: Double,
    val cultivo: String,
    val variedad: String = "",
    val fechaSiembra: String = "",
    val estado: String = "Activo",
    val descripcion: String = "",
    val pendienteSync: Boolean = false
)
