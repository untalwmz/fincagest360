package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "produccion",
    indices = [Index("fecha"), Index("loteId"), Index("fincaId")]
)
data class Production(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val loteId: Int,
    val loteNombre: String = "",
    val cultivo: String = "",
    val fecha: String,
    val cantidad: Double,
    val unidad: String = "Kg",
    val precioUnitario: Double = 0.0,
    val totalVenta: Double = 0.0,
    val comprador: String = "",
    val notas: String = "",
    val pendienteSync: Boolean = false
)
