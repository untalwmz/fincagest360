package com.fincamanager.ui.inventario

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.widget.Toast
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.R
import com.fincamanager.data.model.Input
import com.fincamanager.data.model.InventarioMovimiento
import com.fincamanager.databinding.ActivityInventarioDetalleBinding
import com.fincamanager.databinding.ItemMovimientoBinding
import com.fincamanager.ui.base.BaseActivity
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.InventarioViewModel

class InventarioDetalleActivity : BaseActivity() {

    private lateinit var b: ActivityInventarioDetalleBinding
    private val vm: InventarioViewModel by viewModels()
    private var insumo: Input? = null
    private var fincaId = 0

    companion object {
        fun start(ctx: Context, insumoId: Int, insumoNombre: String, fincaId: Int) {
            ctx.startActivity(Intent(ctx, InventarioDetalleActivity::class.java).apply {
                putExtra("insumoId", insumoId)
                putExtra("insumoNombre", insumoNombre)
                putExtra("fincaId", fincaId)
            })
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityInventarioDetalleBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val insumoId   = intent.getIntExtra("insumoId", 0)
        val nombre     = intent.getStringExtra("insumoNombre") ?: "Insumo"
        fincaId        = intent.getIntExtra("fincaId", 0)

        title = nombre
        b.tvNombreInsumo.text = nombre
        vm.setInsumo(insumoId)
        vm.setFinca(fincaId)

        b.rvMovimientos.layoutManager = LinearLayoutManager(this)

        vm.movimientos.observe(this) { lista ->
            b.tvEmpty.visibility = if (lista.isEmpty()) View.VISIBLE else View.GONE
            b.rvMovimientos.adapter = MovimientoAdapter(lista) { mov ->
                AlertDialog.Builder(this)
                    .setTitle("Eliminar movimiento")
                    .setMessage("¿Eliminar este registro?")
                    .setPositiveButton("Eliminar") { _, _ -> vm.eliminarMovimiento(mov.id, insumoId) }
                    .setNegativeButton("Cancelar", null).show()
            }
        }

        // Stock en tiempo real desde DB via InputViewModel (observar en viewModels padre)
        // Actualizar stock badge cuando cambian movimientos
        vm.movimientos.observe(this) { _ ->
            // El stock se actualiza automáticamente en el ViewModel al insertar/eliminar
        }

        b.btnEntrada.setOnClickListener { mostrarDialogoMovimiento("ENTRADA", nombre, insumoId) }
        b.btnSalida.setOnClickListener  { mostrarDialogoMovimiento("SALIDA",  nombre, insumoId) }
    }

    private fun mostrarDialogoMovimiento(tipo: String, nombre: String, insumoId: Int) {
        val dialogView = layoutInflater.inflate(com.fincamanager.R.layout.dialog_movimiento, null)
        val tvTitulo  = dialogView.findViewById<TextView>(com.fincamanager.R.id.tv_titulo_dialog)
        val etCant    = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(com.fincamanager.R.id.et_cantidad_mov)
        val etCosto   = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(com.fincamanager.R.id.et_costo_mov)
        val spinnerMot = dialogView.findViewById<Spinner>(com.fincamanager.R.id.spinner_motivo)
        val etNotas   = dialogView.findViewById<com.google.android.material.textfield.TextInputEditText>(com.fincamanager.R.id.et_notas_mov)

        tvTitulo.text = if (tipo == "ENTRADA") "⬆ Registrar Entrada" else "⬇ Registrar Salida"

        val motivos = if (tipo == "ENTRADA")
            listOf("Compra", "Devolución", "Ajuste positivo")
        else
            listOf("Aplicación en lote", "Vencimiento", "Pérdida", "Ajuste negativo")

        spinnerMot.adapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, motivos)
            .also { it.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item) }

        if (tipo == "SALIDA") {
            etCosto.isEnabled = false
            etCosto.hint = "N/A para salidas"
        }

        AlertDialog.Builder(this)
            .setTitle(if (tipo == "ENTRADA") "Nueva entrada de stock" else "Nueva salida de stock")
            .setView(dialogView)
            .setPositiveButton("Guardar") { _, _ ->
                val cant  = etCant.text.toString().toDoubleOrNull() ?: return@setPositiveButton
                val costo = etCosto.text.toString().toDoubleOrNull() ?: 0.0
                val motivo = motivos[spinnerMot.selectedItemPosition]
                val notas  = etNotas.text.toString().trim()

                val mov = InventarioMovimiento(
                    fincaId      = fincaId,
                    insumoId     = insumoId,
                    insumoNombre = nombre,
                    tipo         = tipo,
                    cantidad     = cant,
                    costoUnitario = costo,
                    costoTotal   = cant * costo,
                    motivo       = motivo,
                    fecha        = DateUtils.today(),
                    notas        = notas
                )
                vm.registrarMovimiento(mov)
                Toast.makeText(this, "Movimiento registrado ✓", Toast.LENGTH_SHORT).show()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

// ─── MovimientoAdapter ────────────────────────────────────
class MovimientoAdapter(
    private val items: List<InventarioMovimiento>,
    private val onLongClick: (InventarioMovimiento) -> Unit
) : RecyclerView.Adapter<MovimientoAdapter.VH>() {

    inner class VH(val b: ItemMovimientoBinding) : RecyclerView.ViewHolder(b.root)

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemMovimientoBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun getItemCount() = items.size

    override fun onBindViewHolder(h: VH, i: Int) {
        val m = items[i]
        with(h.b) {
            tvIcono.text    = if (m.tipo == "ENTRADA") "⬆" else "⬇"
            tvIcono.setBackgroundResource(
                if (m.tipo == "ENTRADA") R.drawable.bg_chip_selected else R.color.error_light
            )
            tvMotivo.text   = m.motivo
            tvFecha.text    = DateUtils.toShow(m.fecha)
            tvLote.text     = if (m.loteNombre.isNotEmpty()) "• ${m.loteNombre}" else ""
            val signo       = if (m.tipo == "ENTRADA") "+" else "-"
            tvCantidad.text = "$signo${String.format("%.1f", m.cantidad)} ${m.unidad}"
            tvCantidad.setTextColor(root.context.resources.getColor(
                if (m.tipo == "ENTRADA") R.color.success else R.color.error, null))
            tvCosto.text    = if (m.costoTotal > 0) CurrencyUtils.format(m.costoTotal) else ""
            root.setOnLongClickListener { onLongClick(m); true }
        }
    }
}
