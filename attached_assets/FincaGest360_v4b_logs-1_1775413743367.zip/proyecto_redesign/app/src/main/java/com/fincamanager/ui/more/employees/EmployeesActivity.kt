package com.fincamanager.ui.more.employees

import com.fincamanager.ui.base.BaseActivity

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.data.model.Employee
import com.fincamanager.databinding.ActivityEmployeesBinding
import com.fincamanager.databinding.ItemEmployeeBinding
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.EmployeeViewModel

class EmployeesActivity : BaseActivity() {

    private lateinit var b: ActivityEmployeesBinding
    private val vm: EmployeeViewModel by viewModels()
    private lateinit var adapter: EmployeeAdapter

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityEmployeesBinding.inflate(layoutInflater)
        setContentView(b.root)
        applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Empleados"

        val fincaId = SessionManager.getFincaId(this)
        vm.setFinca(fincaId)

        adapter = EmployeeAdapter(
            onClick = { emp ->
                startActivity(Intent(this, AddEditEmployeeActivity::class.java).apply {
                    putExtra("employee_id", emp.id)
                })
            },
            onDelete = { emp ->
                AlertDialog.Builder(this)
                    .setTitle(emp.nombre)
                    .setItems(arrayOf("✏️ Editar", "🗑 Eliminar")) { _, which ->
                        when (which) {
                            0 -> startActivity(Intent(this, AddEditEmployeeActivity::class.java).apply { putExtra("employee_id", emp.id) })
                            1 -> AlertDialog.Builder(this).setTitle("Eliminar empleado")
                                    .setMessage("¿Eliminar a ${emp.nombre}?")
                                    .setPositiveButton("Eliminar") { _, _ -> vm.delete(emp.id) }
                                    .setNegativeButton("Cancelar", null).show()
                        }
                    }.show()
            }
        )
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter

        vm.employees.observe(this) { list ->
            adapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty()) android.view.View.VISIBLE else android.view.View.GONE
        }

        b.fab.setOnClickListener {
            startActivity(Intent(this, AddEditEmployeeActivity::class.java))
        }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class EmployeeAdapter(
    private val onClick: (Employee) -> Unit,
    private val onDelete: (Employee) -> Unit
) : ListAdapter<Employee, EmployeeAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemEmployeeBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(e: Employee) {
            b.tvNombre.text   = e.nombre
            b.tvDocumento.text = e.documento
            b.tvJornal.text   = CurrencyUtils.format(e.precioJornal)
            val parts = e.nombre.trim().split(" ")
            b.tvIniciales.text = buildString {
                append(parts.getOrNull(0)?.firstOrNull() ?: "")
                append(parts.getOrNull(1)?.firstOrNull() ?: "")
            }.uppercase()
            b.root.setOnClickListener { onClick(e) }
            b.root.setOnLongClickListener { onDelete(e); true }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemEmployeeBinding.inflate(LayoutInflater.from(p.context), p, false))

    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Employee>() {
            override fun areItemsTheSame(a: Employee, b: Employee) = a.id == b.id
            override fun areContentsTheSame(a: Employee, b: Employee) = a == b
        }
    }
}
