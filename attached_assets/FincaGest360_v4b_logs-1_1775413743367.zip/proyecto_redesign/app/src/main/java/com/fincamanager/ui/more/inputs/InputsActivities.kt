package com.fincamanager.ui.more.inputs

import com.fincamanager.ui.base.BaseActivity
import android.content.Intent
import android.os.Bundle
import android.view.*
import android.widget.*
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.DiffUtil
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.ListAdapter
import androidx.recyclerview.widget.RecyclerView
import com.fincamanager.data.model.Input
import com.fincamanager.databinding.ActivityInputsBinding
import com.fincamanager.databinding.ActivityAddInputBinding
import com.fincamanager.databinding.ItemInputBinding
import com.fincamanager.utils.Constants
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.InputViewModel
import com.fincamanager.viewmodel.LotViewModel

class InputsActivity : BaseActivity() {
    private lateinit var b: ActivityInputsBinding
    private val vm: InputViewModel by viewModels()
    private lateinit var adapter: InputAdapter

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityInputsBinding.inflate(layoutInflater)
        setContentView(b.root); applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)
        title = "Labores del Cultivo"

        vm.setFinca(SessionManager.getFincaId(this))
        adapter = InputAdapter(
            onClick  = { i -> startActivity(Intent(this, AddInputActivity::class.java).apply { putExtra("input_id", i.id) }) },
            onDelete = { i -> AlertDialog.Builder(this).setTitle("Eliminar labor")
                .setMessage("¿Eliminar '${i.nombre}'?")
                .setPositiveButton("Eliminar") { _, _ -> vm.delete(i.id) }
                .setNegativeButton("Cancelar", null).show() }
        )
        b.rv.layoutManager = LinearLayoutManager(this)
        b.rv.adapter = adapter

        vm.inputs.observe(this) { list ->
            adapter.submitList(list)
            b.tvEmpty.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
        }

        b.fab.setOnClickListener { startActivity(Intent(this, AddInputActivity::class.java)) }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}

class InputAdapter(
    private val onClick: (Input) -> Unit,
    private val onDelete: (Input) -> Unit
) : ListAdapter<Input, InputAdapter.VH>(DIFF) {

    inner class VH(private val b: ItemInputBinding) : RecyclerView.ViewHolder(b.root) {
        fun bind(i: Input) {
            b.tvNombre.text  = i.nombre
            b.tvTipo.text    = i.tipo
            b.tvStock.text   = "Lote: ${i.loteNombre.ifEmpty { "General" }} · ${DateUtils.toShow(i.fecha)}"
            b.tvCosto.text   = if (i.costoTotal > 0) CurrencyUtils.format(i.costoTotal) else ""
            b.ivAlerta.visibility = View.GONE   // no stock alerts for labores
            b.root.setOnClickListener { onClick(i) }
            b.root.setOnLongClickListener { onDelete(i); true }
        }
    }

    override fun onCreateViewHolder(p: ViewGroup, t: Int) =
        VH(ItemInputBinding.inflate(LayoutInflater.from(p.context), p, false))
    override fun onBindViewHolder(h: VH, pos: Int) = h.bind(getItem(pos))

    companion object {
        val DIFF = object : DiffUtil.ItemCallback<Input>() {
            override fun areItemsTheSame(a: Input, b: Input) = a.id == b.id
            override fun areContentsTheSame(a: Input, b: Input) = a == b
        }
    }
}

class AddInputActivity : BaseActivity() {
    private lateinit var b: ActivityAddInputBinding
    private val vm: InputViewModel by viewModels()
    private val lotVm: LotViewModel by viewModels()
    private var inputId = 0
    private var loteId = 0; private var loteNombre = ""

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        b = ActivityAddInputBinding.inflate(layoutInflater)
        setContentView(b.root); applySystemInsets(b.root)
        supportActionBar?.setDisplayHomeAsUpEnabled(true)

        val fincaId = SessionManager.getFincaId(this)
        vm.setFinca(fincaId); lotVm.setFinca(fincaId)
        inputId = intent.getIntExtra("input_id", 0)
        title = if (inputId == 0) "Nueva labor" else "Editar labor"

        // Tipo de labor spinner
        val tipoAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Constants.TIPOS_LABOR)
        tipoAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        b.spinnerTipo.adapter = tipoAdapter

        // Unidad spinner
        val unidadAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, Constants.UNIDADES)
        unidadAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
        b.spinnerUnidad.adapter = unidadAdapter

        b.etFecha.setText(DateUtils.today())

        // Load lots for lote spinner  
        lotVm.lots.observe(this) { lots ->
            val nombresLotes = listOf("Sin lote específico") + lots.map { it.nombre }
            val loteAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_item, nombresLotes)
            loteAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)
            // Use etProveedor as lot selector since layout has it - we repurpose it
            // Actually use a spinner if available, or just store in proveedor field
        }

        b.btnSave.setOnClickListener {
            val nombre = b.etNombre.text.toString().trim()
            val cant   = b.etCantidad.text.toString().trim()
            if (nombre.isEmpty()) { Toast.makeText(this, "Ingresa el nombre de la labor", Toast.LENGTH_SHORT).show(); return@setOnClickListener }
            val cantidad = cant.toDoubleOrNull() ?: 1.0
            val costoU   = b.etCostoUnitario.text.toString().toDoubleOrNull() ?: 0.0
            vm.save(Input(
                id           = inputId,
                nombre       = nombre,
                tipo         = b.spinnerTipo.selectedItem?.toString() ?: "General",
                cantidad     = cantidad,
                unidad       = b.spinnerUnidad.selectedItem?.toString() ?: "Und",
                costoUnitario = costoU,
                costoTotal   = cantidad * costoU,
                fecha        = b.etFecha.text.toString().trim(),
                proveedor    = b.etProveedor.text.toString().trim(),
                notas        = b.etNotas.text.toString().trim(),
                stockActual  = 0.0, stockMinimo = 0.0
            ))
            Toast.makeText(this, "Labor guardada ✓", Toast.LENGTH_SHORT).show()
            finish()
        }
        b.btnCancel.setOnClickListener { finish() }
    }

    override fun onSupportNavigateUp(): Boolean { finish(); return true }
}
