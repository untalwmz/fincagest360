package com.fincamanager.utils

import android.content.Context
import android.os.Build
import android.os.Environment
import android.util.Log
import java.io.File
import java.io.FileWriter
import java.io.PrintWriter
import java.text.SimpleDateFormat
import java.util.*
import java.util.concurrent.Executors

/**
 * AppLogger — Servicio central de logging para FincaGest 360
 *
 * Uso básico:
 *   AppLogger.i("TAG", "Mensaje informativo")
 *   AppLogger.e("TAG", "Error ocurrido", throwable)
 *   AppLogger.exportar(context)   ← comparte el archivo
 *   AppLogger.getRutaArchivo()    ← devuelve el path del .txt
 *
 * Se inicializa automáticamente en FincaApp (Application).
 * Escribe logs automáticamente en:
 *   Downloads/FincaGest360_YYYYMMDD.txt
 * (visible desde cualquier explorador de archivos sin permisos especiales en Android 10+)
 */
object AppLogger {

    // ── Niveles ──────────────────────────────────────────────────────────────
    const val VERBOSE = 'V'
    const val DEBUG   = 'D'
    const val INFO    = 'I'
    const val WARN    = 'W'
    const val ERROR   = 'E'

    // ── Estado interno ────────────────────────────────────────────────────────
    private var logFile: File? = null
    private var writer: PrintWriter? = null
    private val executor = Executors.newSingleThreadExecutor()
    private val dateFmt  = SimpleDateFormat("yyyy-MM-dd HH:mm:ss.SSS", Locale.getDefault())
    private val fileFmt  = SimpleDateFormat("yyyyMMdd", Locale.getDefault())
    private var initialized = false

    // ── Inicialización ────────────────────────────────────────────────────────

    /**
     * Llama esto UNA SOLA VEZ en FincaApp.onCreate()
     * Crea el archivo de log del día actual y escribe el encabezado del sistema.
     */
    fun init(ctx: Context) {
        if (initialized) return
        try {
            // Carpeta Downloads pública — visible desde cualquier explorador de archivos
            val dir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS)
            dir.mkdirs()

            val fileName = "FincaGest360_${fileFmt.format(Date())}.txt"
            logFile = File(dir, fileName)

            // Abrir en modo append para no borrar sesiones anteriores del día
            writer = PrintWriter(FileWriter(logFile!!, true), true)

            writeHeader(ctx)
            initialized = true

            i("AppLogger", "▶ Sesión iniciada — archivo: ${logFile!!.absolutePath}")

            // Captura errores no controlados (crashes)
            installCrashHandler()

        } catch (e: Exception) {
            Log.e("AppLogger", "No se pudo inicializar el logger", e)
        }
    }

    // ── API pública de logging ────────────────────────────────────────────────

    fun v(tag: String, msg: String) = log(VERBOSE, tag, msg)
    fun d(tag: String, msg: String) = log(DEBUG,   tag, msg)
    fun i(tag: String, msg: String) = log(INFO,    tag, msg)
    fun w(tag: String, msg: String, t: Throwable? = null) = log(WARN,  tag, msg, t)
    fun e(tag: String, msg: String, t: Throwable? = null) = log(ERROR, tag, msg, t)

    /** Registra también en logcat para no romper el flujo de desarrollo */
    private fun log(level: Char, tag: String, msg: String, t: Throwable? = null) {
        // Logcat
        when (level) {
            VERBOSE -> Log.v(tag, msg, t)
            DEBUG   -> Log.d(tag, msg, t)
            INFO    -> Log.i(tag, msg, t)
            WARN    -> Log.w(tag, msg, t)
            ERROR   -> Log.e(tag, msg, t)
        }

        // Archivo (hilo de fondo para no bloquear UI)
        executor.execute {
            try {
                val timestamp = dateFmt.format(Date())
                val line = "$timestamp $level/$tag: $msg"
                writer?.println(line)
                t?.let { writer?.println(stackTraceOf(it)) }
                writer?.flush()
            } catch (_: Exception) { /* silencioso */ }
        }
    }

    // ── Sección ──────────────────────────────────────────────────────────────

    /** Inserta un separador visual para agrupar eventos relacionados */
    fun seccion(titulo: String) {
        executor.execute {
            writer?.println()
            writer?.println("── $titulo ────────────────────────────────")
            writer?.flush()
        }
    }

    // ── Crash handler ─────────────────────────────────────────────────────────

    private fun installCrashHandler() {
        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                e("CRASH", "❌ EXCEPCIÓN NO CAPTURADA en hilo '${thread.name}'", throwable)
                writer?.flush()
                writer?.close()
            } catch (_: Exception) {}
            // Pasar al handler original (muestra el diálogo de Android)
            defaultHandler?.uncaughtException(thread, throwable)
        }
    }

    // ── Encabezado del archivo ────────────────────────────────────────────────

    private fun writeHeader(ctx: Context) {
        val sep = "=" .repeat(60)
        val now = SimpleDateFormat("dd/MM/yyyy HH:mm:ss", Locale.getDefault()).format(Date())
        writer?.println()
        writer?.println(sep)
        writer?.println("  FINCAGEST 360 — LOG DE APLICACIÓN")
        writer?.println("  Sesión iniciada : $now")
        writer?.println("  Dispositivo     : ${Build.MANUFACTURER} ${Build.MODEL}")
        writer?.println("  Android         : ${Build.VERSION.RELEASE} (API ${Build.VERSION.SDK_INT})")
        writer?.println("  Paquete         : ${ctx.packageName}")
        try {
            val ver = ctx.packageManager.getPackageInfo(ctx.packageName, 0).versionName
            writer?.println("  Versión app     : $ver")
        } catch (_: Exception) {}
        writer?.println(sep)
        writer?.flush()
    }

    // ── Utilidades ────────────────────────────────────────────────────────────

    private fun stackTraceOf(t: Throwable): String = buildString {
        appendLine("  Causa: ${t.javaClass.name}: ${t.message}")
        t.stackTrace.take(12).forEach { appendLine("    at $it") }
        t.cause?.let { appendLine("  Causado por: ${it.javaClass.name}: ${it.message}") }
    }

    /** Ruta absoluta del archivo de log activo (null si no está inicializado) */
    fun getRutaArchivo(): String? = logFile?.absolutePath

    /** Devuelve el File activo del log (para exportar desde LogExporter) */
    fun getLogFile(): File? = logFile

    /** Cierra el writer limpiamente (llamar en Application.onTerminate si aplica) */
    fun cerrar() {
        executor.execute {
            i("AppLogger", "◼ Sesión cerrada")
            writer?.flush()
            writer?.close()
        }
        executor.shutdown()
    }
}
