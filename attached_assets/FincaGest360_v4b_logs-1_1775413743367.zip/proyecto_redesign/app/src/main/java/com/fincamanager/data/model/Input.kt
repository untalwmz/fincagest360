package com.fincamanager.data.model

import androidx.room.Entity
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(
    tableName = "insumos",
    indices = [Index("fincaId"), Index("tipo")]
)
data class Input(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val fincaId: Int = 0,
    val nombre: String,
    val tipo: String = "Abono",    // Abono, Fumigación, Siembra, Resembrar, Poda, Riego, Control de plagas, General
    val cantidad: Double,
    val unidad: String = "Und",
    val costoUnitario: Double,
    val costoTotal: Double = 0.0,
    val loteId: Int = 0,
    val loteNombre: String = "",
    val fecha: String = "",
    val proveedor: String = "",
    val notas: String = "",
    // Inventario
    val stockActual: Double = 0.0,
    val stockMinimo: Double = 0.0,
    val pendienteSync: Boolean = false
) {
    val tieneAlertaStock: Boolean get() = stockMinimo > 0 && stockActual <= stockMinimo
}
