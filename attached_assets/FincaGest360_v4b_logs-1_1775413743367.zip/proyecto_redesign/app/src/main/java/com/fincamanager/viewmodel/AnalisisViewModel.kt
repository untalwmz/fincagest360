package com.fincamanager.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.LiveData
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.viewModelScope
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.data.model.RentabilidadLote
import com.fincamanager.utils.DateUtils
import kotlinx.coroutines.launch

data class EstadoResultados(
    val ingresos: Double = 0.0,
    val costoInsumos: Double = 0.0,
    val costoNomina: Double = 0.0,
    val costoLabores: Double = 0.0,
    val otrosEgresos: Double = 0.0,
    val utilidadBruta: Double = 0.0,  // ingresos - costoInsumos - costoNomina
    val utilidadNeta: Double = 0.0,   // utilidadBruta - otrosEgresos
    val margenPct: Double = 0.0       // utilidadNeta / ingresos * 100
)

data class FlujoCaja(
    val meses: List<String> = emptyList(),
    val ingresos: List<Double> = emptyList(),
    val egresos: List<Double> = emptyList()
)

class AnalisisViewModel(app: Application) : AndroidViewModel(app) {

    private val db = AppDatabase.getInstance(app)

    private val _estado = MutableLiveData<EstadoResultados>()
    val estadoResultados: LiveData<EstadoResultados> = _estado

    private val _rentabilidadLotes = MutableLiveData<List<RentabilidadLote>>()
    val rentabilidadLotes: LiveData<List<RentabilidadLote>> = _rentabilidadLotes

    private val _flujoCaja = MutableLiveData<FlujoCaja>()
    val flujoCaja: LiveData<FlujoCaja> = _flujoCaja

    private val _produccionPorLote = MutableLiveData<List<Pair<String, Double>>>()
    val produccionPorLote: LiveData<List<Pair<String, Double>>> = _produccionPorLote

    fun cargar(fincaId: Int, inicioPeriodo: String? = null, finPeriodo: String? = null) {
        val ini = inicioPeriodo ?: DateUtils.anioActualInicio()
        val fin = finPeriodo   ?: DateUtils.anioActualFin()

        viewModelScope.launch {
            cargarEstadoResultados(fincaId, ini, fin)
            cargarRentabilidadPorLote(fincaId, ini, fin)
            cargarFlujoCaja(fincaId)
            cargarProduccionPorLote(fincaId, ini, fin)
        }
    }

    private suspend fun cargarEstadoResultados(fincaId: Int, ini: String, fin: String) {
        val ingresos      = db.incomeDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
        val costoInsumos  = db.inputDao().getTotalCostoEnPeriodo(fincaId, ini, fin) ?: 0.0
        val costoNomina   = db.workDayDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
        val costoLabores  = db.laborHistoryDao().getCostoTotalFinca(fincaId, ini, fin) ?: 0.0
        val otrosEgresos  = db.investmentDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0

        val utilidadBruta = ingresos - costoInsumos - costoNomina - costoLabores
        val utilidadNeta  = utilidadBruta - otrosEgresos
        val margen        = if (ingresos > 0) (utilidadNeta / ingresos) * 100.0 else 0.0

        _estado.postValue(EstadoResultados(
            ingresos      = ingresos,
            costoInsumos  = costoInsumos,
            costoNomina   = costoNomina,
            costoLabores  = costoLabores,
            otrosEgresos  = otrosEgresos,
            utilidadBruta = utilidadBruta,
            utilidadNeta  = utilidadNeta,
            margenPct     = margen
        ))
    }

    private suspend fun cargarRentabilidadPorLote(fincaId: Int, ini: String, fin: String) {
        val lotes = db.lotDao().getByFincaSync(fincaId)
        val resultado = lotes.map { lote ->
            val kg      = db.productionDao().getTotalKgPorLote(lote.id, ini, fin) ?: 0.0
            val ventas  = db.productionDao().getTotalVentasPorLote(lote.id, ini, fin) ?: 0.0
            val labores = db.laborHistoryDao().getCostoTotalLote(lote.id, ini, fin) ?: 0.0
            val nomina  = db.workDayDao().getTotalPorLote(lote.id, ini, fin) ?: 0.0
            val costos  = labores + nomina

            RentabilidadLote(
                loteId       = lote.id,
                loteNombre   = lote.nombre,
                totalKg      = kg,
                totalVentas  = ventas,
                totalCostos  = costos,
                rentabilidad = ventas - costos
            )
        }.sortedByDescending { it.rentabilidad }

        _rentabilidadLotes.postValue(resultado)
    }

    private suspend fun cargarFlujoCaja(fincaId: Int) {
        val periodos = DateUtils.ultimosMeses(6)
        val meses    = mutableListOf<String>()
        val ingresos = mutableListOf<Double>()
        val egresos  = mutableListOf<Double>()

        for ((ini, fin) in periodos) {
            val ing = db.incomeDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
            val inv = db.investmentDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
            val nom = db.workDayDao().getTotalEnPeriodo(fincaId, ini, fin) ?: 0.0
            val ins = db.inputDao().getTotalCostoEnPeriodo(fincaId, ini, fin) ?: 0.0

            meses.add(DateUtils.nombreMes(fin))
            ingresos.add(ing)
            egresos.add(inv + nom + ins)
        }

        _flujoCaja.postValue(FlujoCaja(meses, ingresos, egresos))
    }

    private suspend fun cargarProduccionPorLote(fincaId: Int, ini: String, fin: String) {
        val lotes = db.lotDao().getByFincaSync(fincaId)
        val datos = lotes.mapNotNull { lote ->
            val kg = db.productionDao().getTotalKgPorLote(lote.id, ini, fin) ?: 0.0
            if (kg > 0) Pair(lote.nombre, kg) else null
        }.sortedByDescending { it.second }

        _produccionPorLote.postValue(datos)
    }
}
