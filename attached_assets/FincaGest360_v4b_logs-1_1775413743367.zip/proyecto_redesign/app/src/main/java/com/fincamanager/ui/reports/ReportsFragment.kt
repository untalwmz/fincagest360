package com.fincamanager.ui.reports

import android.os.Bundle
import android.view.*
import android.widget.Toast
import androidx.fragment.app.Fragment
import androidx.lifecycle.lifecycleScope
import com.fincamanager.R
import com.fincamanager.data.database.AppDatabase
import com.fincamanager.databinding.FragmentReportsBinding
import com.fincamanager.utils.*
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter
import kotlinx.coroutines.launch

class ReportsFragment : Fragment() {

    private var _b: FragmentReportsBinding? = null
    private val b get() = _b!!
    private var fincaId = 0
    private var periodoInicio = DateUtils.mesActualInicio()
    private var periodoFin    = DateUtils.mesActualFin()

    override fun onCreateView(i: LayoutInflater, c: ViewGroup?, s: Bundle?): View {
        _b = FragmentReportsBinding.inflate(i, c, false)
        return b.root
    }

    override fun onViewCreated(view: View, s: Bundle?) {
        super.onViewCreated(view, s)
        fincaId = SessionManager.getFincaId(requireContext())

        setupChips()
        setupChart()
        cargarDatos()

        b.btnExportPdf.setOnClickListener { exportarPdf() }
    }

    private fun setupChips() {
        fun selectChip(sel: Int) {
            val chips = listOf(b.chipMes, b.chipTrimestre, b.chipAnio)
            chips.forEachIndexed { i, chip ->
                chip.background = resources.getDrawable(
                    if (i == sel) R.drawable.bg_chip_selected else R.drawable.bg_chip_normal, null)
                chip.setTextColor(resources.getColor(
                    if (i == sel) R.color.primary else R.color.text_secondary, null))
            }
        }
        b.chipMes.setOnClickListener {
            periodoInicio = DateUtils.mesActualInicio(); periodoFin = DateUtils.mesActualFin()
            b.tvPeriodoLabel.text = "Resumen del mes"
            selectChip(0); cargarDatos()
        }
        b.chipTrimestre.setOnClickListener {
            val cal = java.util.Calendar.getInstance()
            cal.add(java.util.Calendar.MONTH, -2)
            cal.set(java.util.Calendar.DAY_OF_MONTH, 1)
            periodoInicio = java.text.SimpleDateFormat("yyyy-MM-dd", java.util.Locale.getDefault()).format(cal.time)
            periodoFin = DateUtils.mesActualFin()
            b.tvPeriodoLabel.text = "Resumen trimestral"
            selectChip(1); cargarDatos()
        }
        b.chipAnio.setOnClickListener {
            periodoInicio = DateUtils.anioActualInicio(); periodoFin = DateUtils.anioActualFin()
            b.tvPeriodoLabel.text = "Resumen anual"
            selectChip(2); cargarDatos()
        }
        selectChip(0)
    }

    private fun cargarDatos() = lifecycleScope.launch {
        val db = AppDatabase.getInstance(requireContext())
        val ing  = db.incomeDao().getTotalEnPeriodo(fincaId, periodoInicio, periodoFin) ?: 0.0
        val inv  = db.investmentDao().getTotalEnPeriodo(fincaId, periodoInicio, periodoFin) ?: 0.0
        val nom  = db.workDayDao().getTotalEnPeriodo(fincaId, periodoInicio, periodoFin) ?: 0.0
        val ins  = db.inputDao().getTotalCostoEnPeriodo(fincaId, periodoInicio, periodoFin) ?: 0.0
        val gan  = ing - inv - nom - ins

        b.tvRIngresos.text    = CurrencyUtils.format(ing)
        b.tvRNomina.text      = "- ${CurrencyUtils.format(nom)}"
        b.tvRInsumos.text     = "- ${CurrencyUtils.format(ins)}"
        b.tvRInversiones.text = "- ${CurrencyUtils.format(inv)}"
        b.tvRGanancia.text    = CurrencyUtils.format(gan)
        b.tvRGanancia.setTextColor(resources.getColor(
            if (gan >= 0) R.color.primary else R.color.error, null))

        // Gráfica tendencia mensual
        val meses = DateUtils.ultimosMeses(6)
        val ingData  = meses.map { (i, f) -> db.incomeDao().getTotalEnPeriodo(fincaId, i, f) ?: 0.0 }
        val egrData  = meses.map { (i, f) ->
            val n = db.workDayDao().getTotalEnPeriodo(fincaId, i, f) ?: 0.0
            val in2 = db.investmentDao().getTotalEnPeriodo(fincaId, i, f) ?: 0.0
            val ins2 = db.inputDao().getTotalCostoEnPeriodo(fincaId, i, f) ?: 0.0
            n + in2 + ins2
        }
        val labels = meses.map { (i, _) -> DateUtils.nombreMes(i).take(3) }
        actualizarGraficaTendencia(ingData, egrData, labels)
    }

    private fun setupChart() {
        with(b.chartTendencia) {
            description.isEnabled = false
            setDrawGridBackground(false)
            setPinchZoom(false)
            isDoubleTapToZoomEnabled = false
            xAxis.position = XAxis.XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false)
            axisLeft.axisMinimum = 0f
            axisRight.isEnabled  = false
        }
    }

    private fun actualizarGraficaTendencia(ing: List<Double>, egr: List<Double>, labels: List<String>) {
        val colorIng = resources.getColor(R.color.primary, null)
        val colorEgr = resources.getColor(R.color.error, null)

        val dsIng = LineDataSet(ing.mapIndexed { i, v -> Entry(i.toFloat(), v.toFloat()) }, "Ingresos").apply {
            color = colorIng; setCircleColor(colorIng); lineWidth = 2f; circleRadius = 3f; valueTextSize = 0f
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        val dsEgr = LineDataSet(egr.mapIndexed { i, v -> Entry(i.toFloat(), v.toFloat()) }, "Egresos").apply {
            color = colorEgr; setCircleColor(colorEgr); lineWidth = 2f; circleRadius = 3f; valueTextSize = 0f
            mode = LineDataSet.Mode.CUBIC_BEZIER
        }
        b.chartTendencia.xAxis.valueFormatter = IndexAxisValueFormatter(labels)
        b.chartTendencia.data = LineData(dsIng, dsEgr)
        b.chartTendencia.animateY(600)
        b.chartTendencia.invalidate()
    }

    private fun exportarPdf() = lifecycleScope.launch {
        val db = AppDatabase.getInstance(requireContext())
        val ing   = db.incomeDao().getEnPeriodo(fincaId, periodoInicio, periodoFin)
        val inv   = db.investmentDao().getEnPeriodo(fincaId, periodoInicio, periodoFin)
        val prod  = db.productionDao().getEnPeriodo(fincaId, periodoInicio, periodoFin)
        val nom   = db.workDayDao().getTotalEnPeriodo(fincaId, periodoInicio, periodoFin) ?: 0.0
        val ins   = db.inputDao().getTotalCostoEnPeriodo(fincaId, periodoInicio, periodoFin) ?: 0.0
        val totalIng = ing.sumOf { it.monto }
        val totalEgr = inv.sumOf { it.monto } + nom + ins

        val resumen = PdfExporter.ResumenFinanciero(
            fincaNombre    = SessionManager.getFincaNombre(requireContext()),
            periodo        = "${DateUtils.toShow(periodoInicio)} – ${DateUtils.toShow(periodoFin)}",
            totalIngresos  = totalIng,
            totalEgresos   = totalEgr,
            totalNomina    = nom,
            totalInsumos   = ins,
            gananciaNetat  = totalIng - totalEgr,
            producciones   = prod,
            ingresos       = ing,
            inversiones    = inv
        )
        try {
            val file = PdfExporter.exportarReporte(requireContext(), resumen)
            PdfExporter.compartirPdf(requireContext(), file)
        } catch (e: Exception) {
            Toast.makeText(requireContext(), "Error generando PDF: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
