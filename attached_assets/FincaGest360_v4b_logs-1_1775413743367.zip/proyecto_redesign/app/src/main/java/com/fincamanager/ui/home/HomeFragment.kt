package com.fincamanager.ui.home

import android.content.Intent
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.fragment.app.Fragment
import androidx.fragment.app.viewModels
import com.fincamanager.databinding.FragmentHomeBinding
import com.fincamanager.ui.more.employees.EmployeesActivity
import com.fincamanager.ui.more.inputs.InputsActivity
import com.fincamanager.ui.more.lots.LotsActivity
import com.fincamanager.ui.more.workdays.WorkDayActivity
import com.fincamanager.utils.CurrencyUtils
import com.fincamanager.utils.DateUtils
import com.fincamanager.utils.SessionManager
import com.fincamanager.viewmodel.HomeViewModel
import com.fincamanager.viewmodel.SyncViewModel
import com.fincamanager.viewmodel.SyncStatus
import com.fincamanager.viewmodel.ProductionViewModel
import com.github.mikephil.charting.components.XAxis
import com.github.mikephil.charting.data.*
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter

class HomeFragment : Fragment() {

    private var _b: FragmentHomeBinding? = null
    private val b get() = _b!!
    private val homeVm: HomeViewModel by viewModels()
    private val prodVm: ProductionViewModel by viewModels()
    private val syncVm: SyncViewModel by viewModels()
    private var fincaId = 0

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, saved: Bundle?): View {
        _b = FragmentHomeBinding.inflate(inflater, container, false)
        return b.root
    }

    override fun onViewCreated(view: View, saved: Bundle?) {
        super.onViewCreated(view, saved)
        fincaId = SessionManager.getFincaId(requireContext())

        b.tvFincaNombre.text = SessionManager.getFincaNombre(requireContext())
        b.tvGreeting.text    = greeting()
        b.tvPeriodo.text     = "Mes: ${DateUtils.nombreMes(DateUtils.today())}"

        setupObservers()
        setupChart()
        setupQuickAccess()

        b.btnSync.setOnClickListener {
            syncVm.sincronizarAhora(requireContext(), fincaId)
        }
        syncVm.state.observe(viewLifecycleOwner) { state ->
            b.btnSync.alpha = if (state.status == SyncStatus.SYNCING) 0.5f else 1.0f
            b.btnSync.isEnabled = state.status != SyncStatus.SYNCING
        }
        syncVm.observarSync(requireContext())
        syncVm.contarPendientes(fincaId)

        homeVm.cargar(fincaId)
        prodVm.setFinca(fincaId)
    }

    private fun setupObservers() {
        homeVm.kpis.observe(viewLifecycleOwner) { kpis ->
            b.tvGanancia.text       = CurrencyUtils.format(kpis.ganancia)
            b.tvGanancia.setTextColor(
                resources.getColor(
                    if (kpis.ganancia >= 0) com.fincamanager.R.color.primary
                    else com.fincamanager.R.color.error, null))
            b.tvIngresos.text       = CurrencyUtils.format(kpis.totalIngresos)
            b.tvEgresos.text        = CurrencyUtils.format(kpis.totalEgresos)
            b.tvProduccionKg.text   = "${String.format("%.0f", kpis.totalProduccionKg)} kg"
            b.tvEmpleados.text      = kpis.empleadosActivos.toString()
            b.tvLotes.text          = kpis.lotesActivos.toString()
            b.tvAlertas.text        = "${kpis.alertasInsumos} alertas"
            b.tvCostoKg.text         = if (kpis.costoPorKg > 0) CurrencyUtils.format(kpis.costoPorKg) else "$ 0 / kg"
            val margenColor = resources.getColor(
                if (kpis.margenPct >= 0) com.fincamanager.R.color.success
                else com.fincamanager.R.color.error, null)
            b.tvMargenMes.text       = String.format("%.1f%%", kpis.margenPct)
            b.tvMargenMes.setTextColor(margenColor)
        }

        prodVm.cargarComparativaAnual().observe(viewLifecycleOwner) { datos ->
            actualizarGrafica(datos)
        }
    }

    private fun setupChart() {
        with(b.chartProduccion) {
            description.isEnabled  = false
            legend.isEnabled       = false
            setDrawGridBackground(false)
            setDrawBarShadow(false)
            setPinchZoom(false)
            isDoubleTapToZoomEnabled = false
            xAxis.position         = XAxis.XAxisPosition.BOTTOM
            xAxis.setDrawGridLines(false)
            xAxis.granularity      = 1f
            axisLeft.setDrawGridLines(true)
            axisLeft.axisMinimum   = 0f
            axisRight.isEnabled    = false
            animateY(600)
        }
    }

    private fun actualizarGrafica(datos: List<Pair<String, Double>>) {
        val color = resources.getColor(com.fincamanager.R.color.primary, null)
        val entries = datos.mapIndexed { i, (_, kg) -> BarEntry(i.toFloat(), kg.toFloat()) }
        val dataSet = BarDataSet(entries, "kg").apply {
            this.color = color
            valueTextSize = 10f
        }
        b.chartProduccion.xAxis.valueFormatter =
            IndexAxisValueFormatter(datos.map { it.first })
        b.chartProduccion.data = BarData(dataSet)
        b.chartProduccion.invalidate()
    }

    private fun setupQuickAccess() {
        b.quickEmpleados.setOnClickListener {
            startActivity(Intent(requireContext(), EmployeesActivity::class.java))
        }
        b.quickLotes.setOnClickListener {
            startActivity(Intent(requireContext(), LotsActivity::class.java))
        }
        b.quickInsumos.setOnClickListener {
            startActivity(Intent(requireContext(), InputsActivity::class.java))
        }
        b.quickNomina.setOnClickListener {
            startActivity(Intent(requireContext(), WorkDayActivity::class.java))
        }
    }

    private fun greeting(): String {
        val hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY)
        return when {
            hour < 12 -> "Buenos días ☀️"
            hour < 18 -> "Buenas tardes 🌤"
            else      -> "Buenas noches 🌙"
        }
    }

    override fun onDestroyView() { super.onDestroyView(); _b = null }
}
