# ============================================================
# Modelos de datos Room - nunca ofuscar
# ============================================================
-keep class com.fincamanager.data.model.** { *; }
-keep class com.fincamanager.data.dao.** { *; }
-keep class com.fincamanager.data.database.** { *; }

# ============================================================
# Firebase
# ============================================================
-keep class com.google.firebase.** { *; }
-keep class com.google.android.gms.** { *; }
-dontwarn com.google.firebase.**
-dontwarn com.google.android.gms.**

# ============================================================
# iText PDF
# ============================================================
-keep class com.itextpdf.** { *; }
-dontwarn com.itextpdf.**

# ============================================================
# Room
# ============================================================
-keep class * extends androidx.room.RoomDatabase
-keep @androidx.room.Entity class *
-dontwarn androidx.room.paging.**

# ============================================================
# Kotlin Coroutines
# ============================================================
-keepnames class kotlinx.coroutines.internal.MainDispatcherFactory {}
-keepnames class kotlinx.coroutines.CoroutineExceptionHandler {}
-dontwarn kotlinx.coroutines.**

# ============================================================
# WorkManager
# ============================================================
-keep class * extends androidx.work.Worker
-keep class * extends androidx.work.ListenableWorker {
    public <init>(android.content.Context, androidx.work.WorkerParameters);
}

# ============================================================
# ViewBinding / general Android
# ============================================================
-keepclassmembers class * implements android.os.Parcelable {
    public static final android.os.Parcelable$Creator CREATOR;
}
-keepattributes Signature
-keepattributes *Annotation*

# ============================================================
# Fase 1 - Nuevas entidades y modelos
# ============================================================
-keep class com.fincamanager.data.model.LaborHistory { *; }
-keep class com.fincamanager.data.model.RentabilidadLote { *; }
-keep class com.fincamanager.viewmodel.DashboardKpis { *; }
-keep class com.fincamanager.viewmodel.EstadoResultados { *; }
-keep class com.fincamanager.viewmodel.FlujoCaja { *; }

# ============================================================
# Fase 2 - Inventario y Nómina
# ============================================================
-keep class com.fincamanager.data.model.InventarioMovimiento { *; }
-keep class com.fincamanager.data.model.NominaLiquidacion { *; }
-keep class com.fincamanager.viewmodel.ResumenEmpleado { *; }
